/**
 * data view plugin
 * gets specific/filtered/queried data from api
 * outputs that data using handlebars templates
 * 
 * pass options via:
 *      jquery call  -  $('.data-view').dataview({folder:'myfolder'});
 *      data-{prefix}  -  data-view-folder="myfolder"
 *      query string  -  /mypage?folder=myfolder
 */

(function ($) {
    'use strict';
    $.fn.dataview = function (opts, callback) {
        var $main = this,
            defs = {
                pre: 'view', // data-{prefix}
                api: '/_common/ext/dataapi/php/dataapi.php', // api url
                folder: false, // folder
                excludeFolders: false, // folders to exclude
                excludeFiles: false, // files to exclude
                url: false, // external data url (feed)
                limit: 5, // limit items returned
                query: false, // search query
                searchin: 'title,keyword,description,link,url', // search comma separated list of items to search in
                select: false, // select sub.item as data to work with
                sort: false, // sort by item.subitem:desc:time - dot.notation : [asc,desc] : [abc,num,time]
                filter: false, // filer by item.subitem==match - dot.notation [===,==,!==,!=,<=,<,>=,>,*=,*==] string
                group: false, // group by item.subitem,nested.subitem - dot.notation, multiple separated by commas
                page: false, // current page number
                onload: true, // show results on page load
                params: ['query', 'folder', 'url', 'sort', 'group', 'unique', 'filter', 'search', 'searchin', 'limit', 'page', 'select', 'excludeFolders', 'excludeFiles'], // allowed params sent to api
                qstring: false, // allow query string overwrites - true for all or array of allowed overwrites
                selected: 'selected', // class for selected item
                active: 'active', // class for showing active
                debounce: 250, // ms delay between typing and get results from api (protects api from spaming)
                out: false, // selector defining output i.e. '.output'
                template: {}, // templates - main template is always named 'main'. Sub-templates (partials) may be named anything else
                async: [], // track asynchronous ajax
                callback: typeof callback === 'function' ? callback : true, // callback that runs after first output
                handlebars: typeof Handlebars !== 'undefined' ? Handlebars : 'handlebars', // Handlebars object or 'string' for script importer
                import: typeof myuvu !== 'undefined' ? myuvu.import : typeof uvu !== 'undefined' ? uvu.import : false, // script importer for lazy loading handlebars
                //             spotcheck: typeof myuvu !== 'undefined' ? myuvu.spotcheck : typeof uvu !== 'undefined' ? uvu.spotcheck : false,// check for plugins needing to be loaded after output
                prep: false, // custom preparation function i.e. preps returned ajax data for handlebars template - recieves opts - must return opts
                func: {}, // custom interaction functions - recieves opts - run after first ouput
                helper: { // custom handlebars helpers - only widely usefull helpers here
                    eq: function (a, b, opts) { // 'a == b'
                        return a === b ? opts.fn(this) : opts.inverse(this);
                    },
                    gt: function (a, b, opts) { // 'a > b'
                        return parseFloat(a) > parseFloat(b) ? opts.fn(this) : opts.inverse(this);
                    },
                    gte: function (a, b, opts) { // 'a >= b'
                        return parseFloat(a) >= parseFloat(b) ? opts.fn(this) : opts.inverse(this);
                    },
                    lt: function (a, b, opts) { // 'a < b'
                        return parseFloat(a) < parseFloat(b) ? opts.fn(this) : opts.inverse(this);
                    },
                    lte: function (a, b, opts) { // 'a <= b'
                        return parseFloat(a) <= parseFloat(b) ? opts.fn(this) : opts.inverse(this);
                    },
                    urlparams: function (n, v, opts) {
                        var url = urlparams(),
                            p = {};
                        p[n] = v;
                        $.extend(url, p);
                        return $.param(url);
                    },
                    paginate: function (context, options) { // Allows creation of pagination, not just a next or previous button
                        var out = "",
                            data;
                        if (options.data) {
                            data = Handlebars.createFrame(options.data);
                        }
                        for (var i = 0; i < context; i++) {
                            if (data) {
                                data.index = i + 1;
                            }

                            out += options.fn(context[i], {
                                data: data
                            });
                        }
                        return out;
                    }
                },
                // set presets - overwrites of the above params based on chosen 'preset'
                preset: 'default',
                presets: {
                    default: {
                        template: {
                            main: '{{#if items}}<ul>{{#each items}}<li>{{#if link}}<a href="{{link}}">{{/if}}<span>{{title}}</span>{{#if link}}{{link}}</a>{{/if}}</li>{{/each}}</ul>{{/if}}'
                        }
                    }
                }
            };

        /*
         * interaction functions - may extend/override
         */

        // show suggestions on focus
        defs.func.focus = function (opts) {
            opts.$this.on('focus.' + opts.pre, function () {
                if (opts.$this.val().trim() !== '') opts.$out.addClass(opts.active).attr('aria-hidden', false);
            });
        };

        // de-focus hide suggestions
        defs.func.blur = function (opts) {
            $('body').on('click.' + opts.pre, function (e) {
                var $both = opts.$this.add(opts.$out);
                if (!$both.is(e.target) && !$both.find(e.target).length) {
                    opts.$out.removeClass(opts.active).attr('aria-hidden', true);
                    opts.$out.find('.' + opts.selected).removeClass(opts.selected);
                }
            });
        };

        // capture typing in search box get quick results
        defs.func.quick = function (opts) {
            if (opts.$this.is('input')) {
                opts.$this.add(opts.$out).off('keyup.' + opts.pre).on('keyup.' + opts.pre, function (e) {
                    var $items = opts.$out.find('a'),
                        $sel = $items.filter('.' + opts.selected),
                        $next, cur, idx;

                    // escape key and empty input
                    if (e.which === 27 || opts.$this.val().trim() === '') {
                        clearTimeout(opts.timer);
                        opts.$out.removeClass(opts.active);
                        // replace original html on empty input
                        if (opts.$this.val().trim() === '' && opts.outhtml !== false) {
                            opts.$out.html(opts.outhtml);
                            opts.outhtml = false;
                            opts.query = false;
                        }
                    }
                    // up, down key
                    else if (e.which === 38 || e.which === 40) {
                        $sel.removeClass(opts.selected).blur();

                        idx = e.which === 38 ? $items.index($sel) - 1 : $items.index($sel) + 1;
                        // select next/prev
                        if (-1 < idx && $items.eq(idx).length) {
                            $items.eq(idx).addClass(opts.selected).focus();
                        }
                        // select first
                        else if (e.which === 40) {
                            $sel.addClass(opts.selected).focus();
                        }
                        // focus on input
                        else {
                            opts.$this.focus();
                        }

                        // prevent standard key actions
                        e.preventDefault();
                        return false;
                    }
                    // enter key
                    else if (e.which === 13) {
                        // submit form if input is selected
                        if (opts.$this.closest('form').length > 0 && opts.$this.is(':focus') && opts.$this.val().length) {
                            opts.$this.closest('form').submit();
                        }
                        // if no form - refresh the output class
                        else {
                            opts.$out.removeClass(opts.active);
                            opts.timer = setTimeout(function () {
                                opts.$out.addClass(opts.active);
                            }, opts.debounce);
                        }
                    }
                    // anykey other key but the left, right and tab key
                    else if (e.which !== 37 && e.which !== 39 && e.which !== 9) {
                        clearTimeout(opts.timer); // clear delay
                        opts.timer = setTimeout(function () {
                            var val = opts.$this.val();
                            // only get results when input changes
                            if (val !== opts.query) {
                                opts.$out.addClass(opts.active);
                                opts.query = val;
                                get(opts); // get results
                            }
                        }, opts.debounce);
                    }

                }).on('keydown.' + opts.pre, function (e) {
                    // preventing default action of certain keypresses so we can overide with our code
                    if (e.which == 38 || e.which == 40) e.preventDefault();
                });
            }
        };


        /*
         * overwrite defaults and custom functions with passed in options
         */
        $.extend(true, defs, opts);

        /*
         * base functions
         */

        // get url params from uri or string and filter from array if needed
        function urlparams(a, b) {
            var i, e, ret = {},
                s = typeof a === 'string' ? a : typeof b === 'string' ? b : window.location.search.substring(1),
                f = typeof a === 'object' ? a : typeof b === 'object' ? b : false,
                r = /([^&=]+)=([^&]+)/g;
            // parse url string    
            while ((e = r.exec(s)) !== null) {
                i = decodeURIComponent(e[1]);
                if (f) { // filter
                    if (-1 < f.indexOf(i)) ret[i] = decodeURIComponent(e[2]);
                } else { // return all
                    ret[i] = decodeURIComponent(e[2]);
                }
            }
            return ret;
        }

        // load external template
        function loadTemplate(i, opts) {
            var t = opts.template;
            opts.async.push(false);
            // get template
            $.ajax({
                url: opts.template[i]
            }).done(function (temp) {
                if (typeof temp === 'string') { // make sure we got a template
                    opts.handlebars.registerPartial(i, temp); // make a partial
                    t[i] = opts.handlebars.compile(temp); // make template
                    opts.async[opts.async.indexOf(false)] = true; // set done getting template
                    output(opts);
                }
            }).fail(function (a, b, c) {
                console.log('error loading template - ' + opts.template[i] + ':');
                console.log(a);
                console.log(b);
                console.log(c);
            });
        }

        // get templates from either html or string
        function getTemplates(opts) {
            var t = opts.template,
                c = false,
                i;

            for (i in t) {
                c = true;
                if (t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0) { // test if selector
                    t[i] = $(t[i]).html();
                } else if (-1 < t[i].indexOf('/') && -1 < t[i].indexOf('.')) { // external template file
                    loadTemplate(i, opts);
                }
                opts.handlebars.registerPartial(i, t[i]); // all templates are also a partial
                t[i] = opts.handlebars.compile(t[i]); // make template
            }
            if (c) opts.handlebars.registerHelper(opts.helper);

            output(opts);

        }

        // getting all html5 data- attributes with matching prefix
        function getDataDash(pre, opts) {
            var dd = opts.$this[0].attributes,
                ow = {},
                val, sel, i, n,
                nest = function (sel, val) { // make nested array
                    var s = sel.shift(),
                        v = sel.length ? nest(sel, val) : val,
                        r = {};
                    r[typeof s !== 'undefined' ? s : sel] = v === 'true' ? true : v === 'false' ? false : v;
                    return r;
                };

            for (i = 0; i < dd.length; i++) {
                if (dd[i].name.indexOf('data-' + pre + '-') !== -1 && dd[i].value !== "") $.extend(true, ow, nest(dd[i].name.replace('data-' + pre + '-', '').split('-'), dd[i].value));
            }

            return ow;
        }

        // finish setting up plugin
        function finish(opts) {
            var i;
            // first time only
            if (typeof opts.once === 'undefined' || !opts.once) {
                opts.once = false;
                // run interaction functions
                for (i in opts.func) {
                    opts.func[i](opts);
                }

                // run spotcheck
                if (opts.spotcheck) opts.spotcheck();

                // run callback
                if (typeof opts.callback === 'function') callback(opts);
            }
        }

        // output to page
        function output(opts) {

            // output using handlebars
            if (typeof opts.handlebars === 'object' && typeof opts.template.main === 'function') {
                if (opts.async.indexOf(false) === -1) { // only if done getting templates asynchronously
                    // output using template
                    if (typeof opts.template.main !== 'undefined') {
                        if (typeof opts.outhtml === 'undefined' || !opts.outhtml) opts.outhtml = opts.$out.html(); // store original div html
                        if (opts.prep) opts = opts.prep(opts);
                        if (opts.$out.find(':focus').length) opts.$this.focus();
                        opts.$out.html(opts.template.main(opts.data));

                        finish(opts);
                    }

                }
            }
            // get templates if they haven't been compiled
            else if (typeof opts.handlebars === 'object' && typeof opts.template.main === 'string') {
                getTemplates(opts);
            }
            // import handlebars if missing
            else if (typeof opts.handlebars === 'string') {
                opts.import(opts.handlebars, function () {
                    opts.handlebars = Handlebars;
                    getTemplates(opts);
                });
            }

            //output to global variable for later use
            opts.data.uvu = typeof uvu !== 'undefined' && uvu ? uvu : false; // adding uvu/page params

            if (typeof uvu.dataviewOutput === 'undefined') {
                uvu.dataviewOutput = [];
            }
            uvu.dataviewOutput[opts.$this[0].id != "" ? opts.$this[0].id : opts.$this[0].classList.value] = opts.data.items;

        }

        // get data from api
        function get(opts) {
            var data = {},
                i;
            opts.async.push(false);

            // only send allowed params
            for (i = 0; i < opts.params.length; i++) {
                if (typeof opts[opts.params[i]] !== 'undefined') data[opts.params[i]] = opts[opts.params[i]];
            }
            // get data
            $.ajax({
                url: opts.api,
                dataType: 'json',
                data: data
            }).done(function (d) {
                console.log(opts.pre + ' json:');
                console.log(d);

                opts.data = d;
                opts.async[opts.async.indexOf(false)] = true; // set done getting template
                output(opts);

            }).fail(function (a, b, c) {
                console.log(opts.pre + ' error:');
                console.log(a);
                console.log(b);
                console.log(c);
            });
        }

        // initialize
        function init() {
            return $main.each(function () {
                var opts = $.extend(true, {}, defs),
                    preset = $(this).is('[data-' + opts.pre + '-preset]') ? $(this).attr('data-' + opts.pre + '-preset') : opts.preset, // check for preset
                    ow, i;

                // set instance of this
                opts.$this = $(this);
                // extend from preset
                if (preset && typeof opts.presets[preset] !== 'undefined') $.extend(true, opts, opts.presets[preset]);
                // extend opts from html data-
                $.extend(true, opts, getDataDash(opts.pre, opts));
                // extend opts from querystring
                if (opts.qstring) $.extend(true, opts, urlparams(opts.qstring));

                opts.$out = opts.out ? $(opts.out) : opts.$this;

                // get data on page load
                if (opts.onload) {
                    if (opts.query) opts.$this.val(opts.query);
                    get(opts);
                } else {
                    finish(opts);
                }
            });
        }

        // start up
        try {
            init();
        } catch (err) {
            console.log(err);
        }

    };

})(jQuery);