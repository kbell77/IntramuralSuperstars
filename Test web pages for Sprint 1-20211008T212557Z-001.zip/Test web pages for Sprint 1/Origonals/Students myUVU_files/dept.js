(function($){
	$('#lookup-form').submit(function(e){
		e.preventDefault();
		let term = ($('#manual_input_termCode').val() == '')? $('#term-update').val() : $('#manual_input_termCode').val();
		
	});
		
})(jQuery);