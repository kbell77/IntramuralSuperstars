/* ou-edit */
$(function () {
    var keys = {
        18: false,
        16: false,
        88: false
    },
        trigger = false;

    if (!$('.ou-edit').length) $('body').append('<a href="' + $('#ob a').attr('href') + '" class="ou-edit btn btn-info" target="_blank">Edit Page</a>')

    $(document).on('keydown.ou-edit', function (e) {
        var k,
            check = function () {
                var r = true;

                return r;
            };

        if (e.keyCode in keys) {
            keys[e.keyCode] = true;
            trigger = true;
            for (k in keys) {
                if (!keys[k]) {
                    trigger = false;
                }
            }
            // 			console.log(e.keyCode);
            if (trigger) {
                $('.ou-edit').addClass('show');
                $(document).one('click.ou-edit', function (e) {
                    $('.ou-edit').removeClass('show');
                });
            }
        }
    }).on('keyup.ou-edit', function (e) {
        if (e.keyCode in keys) {
            keys[e.keyCode] = false;
        }
    });
});