(function ($) {
	$.fn.mailPreview = function (opts) {
		'use strict';
		const $main = this,	// store this
			defs = {	// defaults
				pre: 'email',
				url: {
					gmail: `${myuvu.server}/_services/student/student.php`,			// gmail email url
                    outlook: `${myuvu.server}/_services/system/outlook-email.php`,  // outlook email url
					handlebars: `${myuvu.server}/_common/js/handlebars.min.js`,			// handlebars url
					moment: `${myuvu.server}/_common/js/moment.min.js`				// moment url
				},
				accountSummaryUrl: false,
				totalRetrieve: 10,					// total messages to retrieve
				totalShow: 3,						// total messages to retrieve
				cacheTime: 30,						// cache time in seconds
				flush: false,					// refresh server cache
				inboxFolder: 'INBOX',					// inbox folder name
				format: false,
				template: {
					minimal: `<div class="emails">{{>minimalOutlook}}{{>minimalGmail}}</div><p><a href="https://www.uvu.edu/transformations/email-addresses.html" target="_blank">Learn more about email.</a></p>`,
					minimalOutlook:`<div class="minimal-email-preview outlook"><h2 class="title"><a href="https://outlook.office365.com/owa/?realm=uvu.edu" target="blank" class="goto-mail"><span class="icon"></span> <span>UVU</span> Outlook Email <sup class="new">New!</sup>{{#if outlook.unreadItemCount}}<div class="unread-count"><div class="count" title="Unread Email count">{{outlook.unreadItemCount}}</div></div>{{/if}}</a></h2></div>`,
					minimalGmail:`<div class="minimal-email-preview gmail"><h2 class="title"><a {{#if gmail.mailboxURL}}href="{{gmail.mailboxURL}}"{{/if}} target="blank" class="goto-mail"><span class="icon"></span> Student my<span>UVU</span> Gmail {{#if gmail.unreadMessageCount}}<div class="unread-count"><div class="count" title="Unread Email count">{{gmail.unreadMessageCount}}</div></div>{{/if}}</a></h2></div>`,
					fullEmail: `<div class="email-data"><div class="email-header">{{>emailHeader}}</div><div class="messages-container">{{>loading}}</div></div>`,
					emailHeader: `<a href="#" id="outlook-header" class="email-select selected">Outlook <span class="icon">&nbsp;</span>{{#if outlook.unreadItemCount}}<span class="unread">{{outlook.unreadItemCount}}</span>{{/if}}</a><a href="#" id="gmail-header" class="email-select">Gmail <span class="icon">&nbsp;</span>{{#if gmail.unreadMessageCount}}<span class="unread">{{gmail.unreadMessageCount}}</span>{{/if}}</a>`,
					messages: `<div class="email-list outlook">{{>outlookMessages outlook}}</div><div class="email-list gmail hide">{{>gmailMessages gmail}}</div>`,
					loading: `<div class="email-list loader"><ul class="items loading"><li></li></ul></div>`,
					emptyMessage: '<li class="inbox-empty">Your inbox is currently empty</li>',	// empty inbox message
					outlookMessages: `<div id="gtoutlook-container" class="gt-container"><a href="https://outlook.office365.com/owa/?realm=uvu.edu">Go to Outlook <i class="fad fa-arrow-alt-circle-right"></i></a></div><ul class="items">{{#if messages}}{{>outlookItems messages}}{{else}}{{>emptyMessage}}{{/if}}</ul>`,
					outlookItems: `{{#each this}}<li><a href="{{webLink}}" target="blank" class="{{#unless isRead}}unread{{/unless}}"><span class="sender">{{from.emailAddress.name}} < {{from.emailAddress.address}} ></span><span class="subject">{{subject}}</span><span class="content">{{{bodyPreview}}}</span></a></li>{{/each}}`,
					gmailMessages: `<div id="gtgmail-container" class="gt-container"><a href="{{mailboxURL}}">Go to Gmail <i class="fad fa-arrow-alt-circle-right"></i></a></div><ul class="items">{{#if messages}}{{>gmailItems messages}}{{else}}{{>emptyMessage}}{{/if}}</ul>`,
					gmailItems: '{{#each this}}<li><a href="{{messageURL}}" target="blank" class="{{#if unread}}unread{{/if}}"><span class="sender">{{messageFromName}}</span><span class="sentDate">{{sentAgo}}</span><span class="subject">{{messageSubject}}</span><span class="content">{{{messageSnippet}}}</span></a></li>{{/each}}',
					
					
					emailFooter: '<div class="gmail-footer-links"><a class="refresh-inbox" href="#">Refresh <span class="fad fa-sync-alt" aria-hidden="true"></span></a><a class="expandMenu" href="#">Help <span class="fad fa-question-circle" aria-hidden="true"></span></a><div class="menu"><h3>Help</h3><ul><li><a class="livechat btn btn-default" href="https://support.uvu.edu/api/start_session.ns?popup=1&c2cjs=1&id=5&issue_menu=3" target="livechat">Live Chat with UVU Support Desk  <span class="fa fa-comments-o" aria-hidden="true"></span> </a></li><li><a class="btn btn-default" href="https://support.google.com/mail/answer/10957?hl=en" target="_blank" title="How to: Forwarding emails to another account">How to: Forward Emails <span class="fa fa-external-link" aria-hidden="true"></span> </a></li></ul></div></div>',
					emailAll: '<div class="gmail-data">{{> emailFooter}}</div>'
				},
				timeout: 3000,
				retry: 3,
				Handlebars: typeof Handlebars != 'undefined' ? Handlebars : false,
				moment: typeof moment != 'undefined' ? moment : false,
				func: {}
			};
		$.extend(true, defs, opts);

		defs.func.beforeUnload = function(opts, sessVar){
			window.addEventListener("beforeunload", function(e) {
				if(myuvu.session.get(sessVar) !== 'undefined' && myuvu.session.get(sessVar) !== null){
					const cache = myuvu.session.get(sessVar);
					if(cache.getting === true){
						myuvu.session.del(sessVar);
					}
				}
				delete e.returnValue;
			});
		};
		defs.func.refresh = function (opts) {
			opts.flush = true;
			run(opts); 			
		};

		// output messages
		function showMessages(opts, d) {
			if(opts.format == 'minimal'){
				opts.$this.html(opts.template.minimal(d));
			}else{
				
				for(var i= 0; i < d.gmail.messages.length; i++){
					var tags = d.gmail.messages[i].messageLabelIds.join();
					if(tags.indexOf('UNREAD') > -1){
						d.gmail.messages[i].unread = true;
					}else{
						d.gmail.messages[i].unread = false;
					}
					d.gmail.messages[i].sentAgo = opts.moment(d.gmail.messages[i].messageDate).fromNow();
				}
				opts.$this.find(".email-data .messages-container").html(opts.template.messages(d));
				opts.$this.find(".email-data .email-header").html(opts.template.emailHeader(d));
				opts.$this.find('#outlook-header').off('click').on('click', function(e){
					e.preventDefault();
					$('#gmail-header').removeClass('selected');
					$(this).addClass('selected');
					opts.$this.find('.email-list.outlook').removeClass('hide');
					opts.$this.find('.email-list.gmail').addClass('hide');
				});
				opts.$this.find('#gmail-header').off('click').on('click', function(e){
					e.preventDefault();
					$('#outlook-header').removeClass('selected');
					$(this).addClass('selected');
					opts.$this.find('.email-list.outlook').addClass('hide');
					opts.$this.find('.email-list.gmail').removeClass('hide');
				});
				// opts.$this.find('.refresh-inbox').off('click').on('click', (e)=> {
				// 	e.preventDefault();
				// 	opts.$this.find(".refresh-inbox .fa-sync-alt").addClass('fa-spin');
				// 	opts.func.refresh(opts);
				// });
				// opts.$this.find('.expandMenu').off('click').on('click', (e)=>{
				// 	e.preventDefault();
				// 	opts.$this.find('.menu').toggleClass('show');
				// });
			}
		}

		async function run(opts){
			try{
				const addOpts = {'id': myuvu.user.id};
				opts = {...opts, ...addOpts};
				const gmail = getData(opts, 'gmail', `${opts.url.gmail}?call=getGmailMessages&id=${opts.id}&limit=${opts.totalShow}`);
                const outlook = getData(opts, 'outlook', `${opts.url.outlook}`);
                Promise.all([gmail, outlook]).then(values =>{
					let data = {};
					data.gmail = values[0].content;
					data.outlook = values[1].content.data;
					showMessages(opts, data);
				});
				// showMessages(opts, messages);
				// opts.$this.find(".refresh-inbox .fa-sync-alt").removeClass('fa-spin');
			}catch(err){
				console.error('Error', err);
			}
		}
		function init() {
			// return plugin instance
			return $main.each(async function() {
				var opts = $.extend({}, defs),
					ow, i;

				opts.$this = $(this);
				// extend opts from html data-
				$.extend(true, opts, getDataDash(opts.pre, opts));
				// getting templates
				getTemplates(opts);
				if(opts.format == false){
					opts.$this.append(opts.template.fullEmail());
				}else if(opts.format == 'minimal'){
					opts.$this.html(opts.template.minimal());
				}
				run(opts);        
				opts.func.beforeUnload(opts, 'gmail');           
			});
		}
	
		// check dependencies and init
		if (defs.Handlebars && defs.moment) {
			init();
		} else {
			$.getScript(defs.url.moment, function () {
				defs.moment = moment;
			});
			$.getScript(defs.url.handlebars, function () {
				defs.Handlebars = Handlebars;
				init();
			});
		}


	};
	
})(jQuery);