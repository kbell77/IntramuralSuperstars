(function ($) {
    $.fn.tasks = function (opts, callback) {
        'use strict';
        const $main = this,
            defs = {
                pre: 'tasks',
                url: {
                    base: `${myuvu.server}/_services/student/student.php`,
                    handlebars: `${myuvu.server}/_common/js/handlebars.min.js`
                },
                term: '202120',
                cacheTime: 180,
                flush: false,
                src:'prod',
                listen : {
                    form: false,
                    uvid: false,
                    termcode: false,
                    src:false
                }, 
                template: {
                    progressBox: `<span class="progress-title">Prepare for Registration</span><div class="progress"><div class="progress-bar" role="progressbar" aria-valuenow="{{this}}" aria-valuemin="0" aria-valuemax="100" style="width:{{this}}%"></div></div><span class="percentage">{{this}}% complete</span>`,
                    taskList: `{{#if allComplete}}{{>allComplete}}{{/if}}<ul>{{#each taskList}}<li>{{>task}}</li>{{/each}}</ul>`,
                    task:   `<div id="task-{{task_id}}" class="task{{#if task_completed}} completed{{else}} {{task_urgency}}{{/if}}{{#if task_reg_required}} regRequired{{/if}}{{#if task_optout}} opted-out{{/if}}" data-taskId="{{task_id}}" data-task-group-id="{{task_group_id}}"><div class="task-header"><h4>{{#if task_reg_required}}<span class="fa fa-exclamation-circle required-task" title="Required to register." aria-hidden="true"></span>{{/if}}{{#if task_active}}{{#if task_url}}<a href="{{task_url}}" title="{{task_short_desc}}">{{task_short_desc}}</a>{{else}}<a href="#" class="show-details-title" title="{{task_short_desc}}">{{task_short_desc}}</a>{{/if}}{{else}}<span title="{{task_short_desc}}">{{task_short_desc}}</span>{{/if}}</h4>{{#if task_completed}}<span class="task-completed-check fa fa-check-circle" aria-hidden="true"></span>{{else}}{{#if task_active}}{{#ifEquals task_manual_completion_allowed_flag "Y"}}{{>taskComplete}}{{/ifEquals}}{{#ifEquals task_optout_flag "Y"}}{{>taskOptOut}}{{/ifEquals}}{{/if}}{{/if}}</div>{{#if task_message}}<p>{{{task_message}}}</p><a href="#" class="show-details"></a>{{/if}}{{#if task_optout}}{{>optedOutMessage}}{{/if}}</div>`,
                    taskComplete: `<a href="#" class="task-Complete" data-toggle="modal" data-target="#tasksModal" data-task-id="{{task_id}}" title="Complete {{task_short_desc}}."><span class="fa fa-check"></span> </a>`,
                    taskOptOut: `<a href="#" class="task-OptOut" data-toggle="modal" data-target="#tasksModal" data-task-id="{{task_id}}" title="Opt-Out of {{task_short_desc}}."><span class="fa fa-times"></span></a>`,
                    optedOutMessage: `<p class="alert alert-warning">You have opted out of this optional task, but you can still go back and complete it if you'd like.</p>`,
                    loading: `<div class="text-center"><div class="loader"><div class="bg"></div><div class="circle dark-bg"></div><div class="circle dark-bg"></div><div class="circle dark-bg"></div><div class="circle dark-bg"></div><div class="circle dark-bg"></div></div></div>`,
                    allComplete: `<div class="tasks-allComplete"><p class="all-complete-message">You have completed all tasks for the selected semester.</p><br/><span class="allCompleteIcon"><i class="fad fa-check-circle"></i></span> <br/>{{#if optedOutTotal}}<p class="optedout-message">You have {{optedOutTotal}} task{{#ifGreater optedOutTotal 1}}s{{/ifGreater}} that you opted out of that you can still complete for this term.</p>{{/if}}</div>`,
                    audienceError: `<div class="padding-10 text-white"><p>Enrollment Tasks are not applicable for your student type.</p></div>`,
                    error: `<div class="padding-10 error-message"><p>Internal Server Error, please try again in a few minutes. If the issue persists, please contact the service desk.</p><p>Error Code: {{statusCode}}</p></div>`,
                    priorityRegistration: `{{>header}}{{>body}}`,
                    header: `<h2 class="title">Registration: {{#ifEquals regStatus "available"}}Available and Open{{/ifEquals}}{{#ifEquals regStatus "pending"}}Upcoming - Ready to Register{{/ifEquals}}{{#ifEquals regStatus "unavailable"}}Complete Required Tasks{{/ifEquals}}</h2>`,
                    body: `<div class="info-body">
                                <div class="info-attribute info-credits"><span class="info-body-title">Credits Earned</span><span class="info-body-separator"><span></span></span><span class="info-body-data">{{ credits }}</span></div>
                                <div class="info-attribute info-reg-date"><span class="info-body-title">{{regTermName}} Registration Opens</span><span class="info-body-separator"><span></span></span><span class="info-body-data">{{regDateString}} at <strong>8 P.M.</strong></span></div>
                                <div class="info-body-message">
                                    {{#ifEquals regStatus "unavailable"}}{{#unless tasksComplete}}{{>tasksPending}}{{/unless}}{{/ifEquals}}
                                    {{#if available}}<p>*The amount of credits you have earned determines when your registration opens.<br/><a href="https://www.uvu.edu/registration/registration_deadlines/">See all dates and deadlines <span class="fa fa-caret-right"></span></a></p>{{/if}}
                                </div>
                            </div>`,
                    tasksPending: `<h3>Enrollment Tasks:</h3><p>You have not completed all required tasks to register.<ul>{{#each requiredRemainingTasks}}<li>{{task_short_desc}}</li>{{/each}}</ul></p><p>{{#if standalone}}View tasks on the main student page. <a href="/students/" class="btn btn-default">View Now</a>{{else}}View tasks below.{{/if}}</p>`,
                    notEligible: `<h2 class="title">Priority Registration Not Applicable</h2><div class="info-body"><div class="info-body-message"><p>Priority registration is not applicable for your student type.</p></div></div>`,
                    prError: `<h2 class="title">Internal Error</h2><div class="info-body"><div class="info-body-message"><p>{{>error}}</p></div></div>`,
                    registrationNA: `<h2 class="title">Priority Registration</h2><div class="info-body"><div class="info-body-message"><p>Priority Registration dates have not been determined for the selected term yet. Please check back later, as these dates will be updated.</p></div></div>`
                },
                out: {
                    registration: ".priority-registration",
                    tasks: {
                        main: ".tasks",
                        list: ".task_list",
                        progress: ".progress_box"
                    }
                },
                helper: {
                    ifEquals: function (arg1, arg2, options) {
                        return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
                    },
                    ifGreater: function(arg1, arg2, options){
                        return (Number(arg1) > Number(arg2)) ? options.fn(this) : options.inverse(this);
                    }
                },
                func:{},
                Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false,
                moment: typeof moment != 'undefined' ? moment : false

            };
        // check for user passed in options
        $.extend(true, defs, opts);

        defs.func.showModal = function(opts, id, func){
            let data = myuvu.session.get('enrollment-tasks');
            let task = data.content.data.taskList.filter(task => task.task_id == id)[0],
                messageTxt;
                if(func == 'OptOut'){
                    messageTxt = (task.task_optout_alert != "" && task.task_optout_alert != null) ? `<p>${task.task_optout_alert}</p>` : `<p>If you choose to opt out now, this task can be completed later.</p>`;
                }else{
                    messageTxt = `<p>Have you completed this task already?</p><br/><p>If you click 'Yes', this task will be marked as completed, and will no longer be an active 'To Do'.</p>`;
                }
            bootbox.confirm({
                title: `${func}: ${task.task_short_desc}`,
                message: messageTxt,
                buttons: {
                    confirm:{
                        label: "Yes",
                        className: "btn-primary"
                    }
                },
                callback: function(result){
                    if(result == true){
                        updateTaskAjax(opts, task.task_id, func);
                    }
                }
            });
        };
        defs.func.tasksLoaded = function(opts){
            $(".task-OptOut").off('click').on('click', function(e){
                e.preventDefault();
                opts.func.showModal(opts, $(this).attr('data-task-id'), 'OptOut');
            });
            $(".task-Complete").off('click').on('click', function (e) {
                e.preventDefault();
                opts.func.showModal(opts, $(this).attr('data-task-id'), 'Complete');
            });
            $(".show-details").off('click').on('click', function(e){
                e.preventDefault();
                $(this).closest('.task').toggleClass('expanded');
            });
            $(".show-details-title").off('click').on('click', function(e){
                e.preventDefault();
                $(this).closest('.task').toggleClass('expanded');
            });
            $('.task_confirm_contact').off('click').on('click', function(e){
                e.preventDefault();
                confirmAddress(opts, $(this));
                
            });
        };
        defs.func.viewAll = function(opts){
            $(".view_all_tasks").on('click', function(e){
                e.preventDefault();
                $('.task_list').toggleClass('show_all');
                $(this).text($(this).text() == 'View All Tasks' ? 'Hide Completed Tasks' : 'View All Tasks');
            });
        };
        defs.func.listen = function(opts){
            if (opts.listen.form !== false) {
                $(opts.listen.form).submit(function (e) {
                    e.preventDefault();
                    const res = getUser(opts).then(res=>{
                        let data = res.data,
                            id = data.id;
                        opts.term = data.term;
                        opts.src = data.src;
                        opts.flush = true;
                        if($('.tasks').length){
                            opts.$this.find(opts.out.tasks.list).html(opts.template.loading());
                        }
                        if($(opts.out.registration).length){
                            $(opts.out.registration).html(opts.template.loading());
                        }
                        getAll(opts, id);
                    });
                });
            }
        };
        defs.func.beforeUnload = function(opts, sessVar){
            window.addEventListener("beforeunload", function(e) {
                if(myuvu.session.get(sessVar) !== 'undefined' && myuvu.session.get(sessVar) !== null){
                    const cache = myuvu.session.get(sessVar);
                    if(cache.getting === true){
                        myuvu.session.del(sessVar);
                    }
                }
                delete e.returnValue;
            });
        };
       
        function out(opts, d) {
            const tasksMeta = d.tasks.metadata;
            const ncaudiences = ['S', 'N'];
            if(tasksMeta.status == "success"){
                const tasksData = d.tasks.data;  
                const completedTasks = [];
                const optedOutTasks = [];
                const incompleteTasks = [];
                tasksData.taskList.forEach(task => {
                    if(task.task_completed == true && task.task_optout == false){
                        completedTasks.push(task);
                    }else if(task.task_completed == true && task.task_optout == true){
                        optedOutTasks.push(task);
                    }else{
                        incompleteTasks.push(task);
                    }
                });
                tasksData.taskList = [...incompleteTasks, ...optedOutTasks, ...completedTasks];
                tasksData.optedOutTotal = optedOutTasks.length;
                tasksData.allComplete = (incompleteTasks.length > 0)? false: true;
                if($(".tasks").length){
                    opts.$this.find(opts.out.tasks.progress).html(opts.template.progressBox());
                    opts.$this.find(opts.out.tasks.list).html(opts.template.taskList(tasksData));
                    opts.func.tasksLoaded(opts);
                }
                if($(opts.out.registration).length){
                    opts.moment().utcOffset(-7);
                    const regData = {};
                    const incReqTasks = incompleteTasks.filter(task => task.task_reg_required === true);
                    const uniqueTasksArray = [];
                    const map = new Map();
                    for (const item of incReqTasks) {
                        if(!map.has(item.task_id)){
                            map.set(item.task_id, true);    // set any value to Map
                            if(item.task_id === "11"){
                                uniqueTasksArray.push({
                                    task_id: item.task_id,
                                    task_short_desc: "Registration Holds"
                                });
                            }else{
                                uniqueTasksArray.push({
                                    task_id: item.task_id,
                                    task_short_desc: item.task_short_desc
                                });
                            }
                        }
                    }
                    
                    if (ncaudiences.includes(d.student.studentTypeCode) === false) {
                        if(d.student.nextPriorityRegistrationDate != null){

                            if (d.student.credits.UG_O != 'undefined' && d.student.credits.UG_O != undefined) {
                                regData.credits = (d.student.credits.UG_O.hoursEarned);
                            } else {
                                regData.credits = 0;
                            }
                            

                            if (incReqTasks.length > 0 ) {
                                regData.regStatus = 'unavailable';
                                regData.available = false;
                                regData.tasksComplete = false;
                            } else if (incReqTasks.length == 0 && moment().isBefore(opts.moment.unix(d.student.nextPriorityRegistrationDateTS))) {
                                regData.regStatus = 'pending';
                                regData.available = true;
                                regData.tasksComplete = true;
                            } else {
                                regData.regStatus = 'available';
                                regData.available = true;
                                regData.tasksComplete = true;
                            }
                            regData.requiredRemainingTasks = uniqueTasksArray;
                            const ts = d.student.nextPriorityRegistrationDateTS;
                            const thisYear = new Date().getFullYear();
                            const lastYear = thisYear - 1;
                            const springRange = [opts.moment(`${thisYear}-10-20`).unix(),opts.moment(`${thisYear}-11-10`).unix()];
                            const summerRange = [opts.moment(`${thisYear}-02-10`).unix(), opts.moment(`${thisYear}-03-10`).unix()];
                            const fallRange = [opts.moment(`${thisYear}-04-01`).unix(),opts.moment(`${thisYear}-05-01`).unix()];
                            const springRangeLastYear = [opts.moment(`${lastYear}-10-20`).unix(), opts.moment(`${lastYear}-11-10`).unix()];
                            
                            regData.regDateString = opts.moment.unix(ts).format('MMMM Do, YYYY');
                            
                            let priorityRegTermName;
                            if(opts.moment(ts).isBetween(springRange[0],springRange[1]) || opts.moment(ts).isBetween(springRangeLastYear[0], springRangeLastYear[1])){
                                priorityRegTermName = 'Spring';
                            }else if(opts.moment(ts).isBetween(summerRange[0], summerRange[1])){
                                priorityRegTermName = 'Summer';
                            }else if(opts.moment(ts).isBetween(fallRange[0], fallRange[1])){
                                priorityRegTermName = 'Fall';
                            }else{
                                priorityRegTermName = 'Fall';
                            }
                            if($('.tasks').length){
                                regData.standalone = false;
                            }else{
                                regData.standalone = true;
                            }
                            regData.regTermName = priorityRegTermName;
                            $(opts.out.registration).removeClass('unavailable').removeClass('pending').removeClass('available').removeClass('na').addClass(regData.regStatus);
                            $(opts.out.registration).html(opts.template.priorityRegistration(regData));
                        }else{
                            $(opts.out.registration).html(opts.template.registrationNA());
                        }
                    }
                }
            }else if(tasksMeta.status == "error"){
                if(tasksMeta.statusCode == "08"){
                    $(opts.out.registration).removeClass('unavailable').removeClass('pending').removeClass('available').addClass('na');
                    $(opts.out.registration).html(opts.template.notEligible());
                    
                    opts.$this.find(opts.out.tasks.list).html(opts.template.audienceError());
                }else{
                    $(opts.out.registration).removeClass('unavailable').removeClass('pending').removeClass('available').addClass('na');
                    $(opts.out.registration).html(opts.template.prError(tasksMeta));
                    opts.$this.find(opts.out.tasks.list).html(opts.template.error(tasksMeta));
                }
            }
        }

        async function updateTaskAjax(opts, task_id, func){
            const data = myuvu.session.get('enrollment-tasks');
            const task = data.content.data.taskList.filter(task => task.task_id == task_id)[0];
                task.updateTo = func;
                task.termCode = data.term;
            const optedOut = func == 'OptOut' ? 'opted-out' : '';

            const userData = await getUser(opts).then((d)=>{return d.data;});
            const update = await fetch(`${opts.url.base}?call=updateTask&id=${userData.id}&src=${userData.src}&term=${userData.term}`, {
                        method: 'PUT',
                        body: JSON.stringify(task)
                    }).then((res)=>res.json());
                    
                if(update.metadata.status === 'success'){
                    opts.$this.find($("#task-" + task.task_id)).addClass(optedOut).addClass('completed');
                    new Noty({
                        type: 'success',
                        text: `Task ${task.task_id}: <strong>${task.task_short_desc}</strong> updated for the selected term.`,
                        timeout: 5000,
                        closeWith: ['click']
                    }).show();
                    opts.flush = true;
                    getAll(opts, userData.id);
                }
        }

        function confirmAddress(opts, $el){
            const type = $el.attr('data-type');
            const sequence = $el.attr('data-seq');
            const body = {'contactType': type, 'contactSequenceNumber': sequence};
            const res = getUser(opts).then(res=>{
                const person = res.data;
                opts.src = person.src;
                fetch(`${opts.url.base}?call=confirmAddress&id=${person.id}&src=${opts.src}`, {
                        method: 'PUT',
                        body: JSON.stringify(body)
                    }).then(res => res.json())
                    .then(res => {
                        if(res.metadata.status === 'success'){
                            new Noty({
                                type: 'success',
                                text: `Confirmed: your address has been confirmed.`,
                                timeout: 5000,
                                closeWith: ['click']
                            }).show();
                            opts.flush = true;
                            getAll(opts, person.id);
                        }
                    });
            });
        }
        
        function getFutureTerm(opts){
            return new Promise((resolve, reject) =>{
                
                resolve(tasksTerm);
            });
        }

        async function getAll(opts) {
            try{
                const user = await getUser(opts);
                const addOpts = {'id': user.data.id, 'term': user.data.term, 'src': user.data.src};
                opts = {...opts, ...addOpts};
    
                const student = await getData(opts, 'student-info', `${opts.url.base}?call=student&id=${opts.id}&term=${opts.term}&src=${opts.src}`);
                const tasks = await getData(opts, 'enrollment-tasks', `${opts.url.base}?call=tasks&id=${opts.id}&term=${opts.term}&src=${opts.src}`);
                const data = {
                    'student': student.content.data[0],
                    'tasks': tasks.content
                };
                opts.flush = false;
                out(opts, data);
            }catch(err){
                console.error('Error', err);
            }
        }
        // init plugin
        function init() {
            // return plugin instance
            return $main.each(function () {
                var opts = $.extend({}, defs),
                    ow, i;
                opts.$this = $(this);
                // extend opts from html data-
                $.extend(true, opts, getDataDash(opts.pre, opts));
                // getting templates
                getTemplates(opts);
                getAll(opts);
                $(opts.out.registration).html(opts.template.loading());
                $(opts.out.tasks.list).html(opts.template.loading());
                opts.func.listen(opts);
                opts.func.viewAll(opts);
                opts.$this.find(opts.out.tasks.main).fadeIn("slow", "swing");
            });
        }

        // check dependencies and init
       if (defs.Handlebars && defs.moment) {
            init();
        } else {
            $.getScript(defs.url.moment, function () {
                defs.moment = moment;
            });
            $.getScript(defs.url.handlebars, function () {
                defs.Handlebars = Handlebars;
                init();
            });
        }

    };
})(jQuery);