(function ($) {
    $.fn.completionInformation = function (opts, callback) {
        'use strict';
        const $main = this,
            defs = {
                pre: 'completionInformation',
                url: {
                    base: '/_services/student/student.php',
                    handlebars: '/_common/js/handlebars.min.js'
                },
                term: '202040',
                cacheTime: 240,
                flush: false,
                src:'qa',
                listen : {
                    form: false,
                    uvid: false,
                    termcode: false,
                    src:false
                }, 
                template: {
                    main: `{{>curriculum}}{{#if advisor}}{{>advisor}}{{else}}{{>noAdvisor}}{{/if}}`,
                    curriculum:`<div class="completion-data">
                        <ul>
                            <li><span class="labeled-content">Level:</span> {{student.levelDescription}}</li>
                            {{#if student.majorProgramDescription}}<li><span class="labeled-content">Major:</span> {{student.majorProgramDescription}}</li>{{/if}}
                            {{#if student.majorEmphasisDescription}}<li><span class="labeled-content">Focus:</span> {{student.majorEmphasisDescription}}</li>{{/if}}
                            {{#if student.minorDescription}}<li><span class="labeled-content">Minor:</span> {{student.minorDescription}}</li>{{/if}}
                        </ul>
                        <div class="btns-group">
                            <a href="https://dashboard.uvu.edu/" class="action-btn">Wolverine Track</a>
                            <a href="https://www.uvu.edu/advising/advisors/" class="action-btn">Change My Major</a>
                            <a href="https://userve.uvu.edu/UVUSelfService/ssb/gradApp/dashboard#!/" class="action-btn">Graduation Application</a>
                        </div>
                    </div>`,
                    advisor:`<div class="advisor-data">
                        <h3 class="advisor-data-title">Your Advisor's Information</h3>
                        <div class="advisor-data-content">
                            <ul>
                                <li><span class="advisor-icon fad fa-hands-helping" aria-hidden="true"></span>{{advisor.advisor_first_name}} {{advisor.advisor_last_name}}</li>
                                {{#if advisor.advisor_phone}}<li><span class="advisor-icon fad fa-phone" aria-hidden="true"></span> <a href="tel:{{advisor.advisor_phone}}">{{advisor.advisor_phone}}</a></li>{{/if}}
                                {{#if advisor.advisor_room_number}}<li><span class="advisor-icon fad fa-building" aria-hidden="true"></span> {{advisor.advisor_room_number}}</li>{{/if}}
                            </ul>
                            <div class="portrait-wrapper"><img src="{{advisor.advisor_photo_url}}" alt="Portrait of {{advisor.advisor_first_name}} {{advisor.advisor_last_name}}"/></div>
                        </div>
                        <div class="btns-group">
                            {{#if advisor.advisor_appointment_url}}<a href="{{advisor.advisor_appointment_url}}" class="action-btn">Schedule an Appointment <i class="fad fa-calendar-alt"></i></a>{{/if}}
                            <a href="/user/message?id={{advisor.advisor_directory_id}}" class="action-btn">Send Message <i class="fad fa-envelope-open-text"></i></a>
                        </div>
                    </div>`,
                    noAdvisor: `<div class="btns-group"><a href="https://www.uvu.edu/advising/" class="action-btn">Find an Advisor</a></div>`,
                    loading: `<div class="text-center">
                                <div class="loader">
                                    <div class="bg"></div>
                                    <div class="circle dark-bg"></div>
                                    <div class="circle dark-bg"></div>
                                    <div class="circle dark-bg"></div>
                                    <div class="circle dark-bg"></div>
                                    <div class="circle dark-bg"></div>
                                </div>
                            </div>`
                },
                helper: {
                    ifEquals: function (arg1, arg2, options) {
                        return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
                    }
                },
                func:{},
                Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false

            };
        // check for user passed in options
        $.extend(true, defs, opts);
        defs.func.listen = function (opts) {
            if (opts.listen.form !== false) {
                $(opts.listen.form).submit(()=> {
                    opts.flush = true;
                    run(opts); 
                });
            }
        };
        defs.func.beforeUnload = function(opts, sessVar){
            window.addEventListener("beforeunload", function(e) {
                if(myuvu.session.get(sessVar) !== 'undefined' && myuvu.session.get(sessVar) !== null){
                    const cache = myuvu.session.get(sessVar);
                    if(cache.getting === true){
                        myuvu.session.del(sessVar);
                    }
                }
                delete e.returnValue;
            });
        };
        function out(opts, d){
            const data = d.content;
            opts.$this.find('.completion-content').html(opts.template.main(data));
        }

        async function run(opts){
            try{
                const user = await getUser(opts);
                const addOpts = {'id': user.data.id, 'term': user.data.term, 'src': user.data.src};
                opts = {...opts, ...addOpts};
                const completionInfo =	await getData(opts, 'completion-information', `${opts.url.base}?call=getAdvisor&id=${opts.id}&term=${opts.term}&src=${opts.src}`);
                out(opts, completionInfo);
            }catch(err){
                console.error('Error', err);
            }
        }
        // init plugin
        function init() {
            // return plugin instance
            return $main.each(function () {
                var opts = $.extend({}, defs),
                    ow, i;


                opts.$this = $(this);
                // extend opts from html data-
                $.extend(true, opts, getDataDash(opts.pre, opts));
                // getting templates
                getTemplates(opts);
                run(opts);
                opts.$this.find('.completion-content').html(opts.template.loading());
                
                opts.func.listen(opts);
                opts.$this.fadeIn("slow", "swing");
            });
        }

        // check dependencies and init
        if (defs.Handlebars) {
            init();
        } else {
            $.getScript(defs.url.handlebars, function () {
                defs.Handlebars = Handlebars;
                init();
            });
        }

    };
})(jQuery);