(function($){
    $.fn.myCourses = function(opts, callback){
		'use strict';
		const $main = this,
		defs = {
			pre: 'courses',
			url: {
				base: `${myuvu.server}/_services/student/student.php`,
			},
			cacheTime: 180,
			term: "202140",
			src: "prod",
			flush: false,
			style: 'basic',
			listen: {
				form: false,
				uvid: false,
				termcode: false,
				src: false
			},
			out:{
				courses: '.my-courses',
				finals: '.my-courses-finals-container'
			},
			template: {
				main:`
				<div class="title-bar">
					<h2 class="title">My Classes</h2>
					
				</div>
				<div id="semesterControls" class="btn-group btn-group-justified course-controls" role="group">
					{{>semesterControls}}
				</div>
				<div class="courses">
				{{>courses}}
				</div>
				<hr/>
				<div class="color-keys">
					<div><span class="key key-enrolled"></span> - Registered</div>
					<div><span class="key key-waitlisted"></span> - Waitlisted</div>
					<div><span class="key key-pending"></span> - Ready to Register</div>
				</div>
				`,
				semesterControls: `<a class="btn btn-default {{#unless bookmatch_url}}disabled{{/unless}}" href="{{bookmatch_url}}"><i class="fad fa-books"></i> Textbooks</a>
					<a class="btn btn-default" href="/students/registration/class-calendar.html"><i class="fad fa-calendar-week"></i> Calendar</a>
					<a id="goToCanvas" class="btn btn-default" href="https://uvu.instructure.com"><img src="/_common/ext/my-courses/images/logo_canvas_horizontal_small.png" alt="Canvas CMS Logo"/></a>`,
				courses:`
						{{#if courses}}
							{{#each courses}}
								{{#ifEquals ../style 'basic'}}{{>courseBasic}}{{/ifEquals}}
								{{#ifEquals ../style 'detailed'}}{{>courseDetailed}}{{/ifEquals}}
							{{/each}}
						{{else}}
							<p class="text-center no-courses">You have not Registered in any courses for this term.</p>
						{{/if}}
				`,
				courseBasic: `<div class="course {{waitlistedClass waitlistPosition}}">
									<h3 class="course-title"><span class="code">{{subject}} {{courseNumber}}</span> - {{title}}</h3>
									{{#if waitlistPosition}}<p class="waitlist-message"><span class="fa fa-exclamation-triangle waitlist-icon"></span><span class="title">Wait List Status</span>: Position {{waitlistPosition}}, you can enroll when your position reaches 0.</p>{{/if}}
									{{#ifEquals waitlistPosition 0}}<p class="waitlist-message"><span class="fa fa-exclamation-triangle waitlist-icon"></span><span class="title">Wait List Status</span>: <strong>You can now Enroll!</strong> You have until <strong>{{formattedDeadline}}</strong> to <strong>complete enrollment</strong> for this course.</p><p class="text-center cmp-enroll"><a href="https://userve.uvu.edu/StudentRegistrationSsb/ssb/personaSelection/selectPersona" class="btn btn-default ">Complete Enrollment</a></p>{{/ifEquals}}
									{{#if canvasCourseUrl}}<a class="canvas-link" title="{{subject}} {{courseNumber}} - {{sectionNumber}} Canvas course link." href="{{canvasCourseUrl}}"></a>{{/if}}
									{{#unless waitlistPosition}}<div class="course-meetings">
										<h4>Meetings</h4>
										{{#each courseMeetings}}
											<div class="meeting">
												{{#if beginTime}}
												<div><span class="general-info-title" title="Location"><i class="fas fa-map-marker-alt"></i></span> {{buildingCode}} {{roomCode}}</div>
												<div><span class="general-info-title">Start - End Dates:</span> {{startDate}} - {{endDate}}</div>
												<div><span class="general-info-title" title="Days of week."><span class="general-info-title"><i class="fas fa-calendar-day"></i></span> {{meetingDays}}<br/><i class="fas fa-clock"></i></span> {{beginTimeFormal}} - {{endTimeFormal}}</div>
												{{else}}
												<div><span class="general-info-title" title="Location"><i class="fas fa-map-marker-alt"></i></span> {{buildingCode}}</div>
												<div><span class="general-info-title">Start - End Dates:</span> {{startDate}} - {{endDate}}</div>
												<div>There is an online element to this course.</div>
												{{/if}}
											</div>
										{{/each}}
									</div>
									{{/unless}}
								</div>`,
				courseDetailed: `<div class="course {{waitlistedClass waitlistPosition}}">
									<h3 class="course-title"><span class="code">{{subject}} {{courseNumber}}</span> - {{title}}</h3>
									{{#if waitlistPosition}}<p class="waitlist-message"><span class="fa fa-exclamation-triangle waitlist-icon"></span><span class="title">Wait List Status</span>: Position {{waitlistPosition}}, you can enroll when your position reaches 0.</p>{{/if}}
									{{#ifEquals waitlistPosition 0}}<p class="waitlist-message"><span class="fa fa-exclamation-triangle waitlist-icon"></span><span class="title">Wait List Status</span>: <strong>You can now Enroll!</strong> You have until <strong>{{formattedDeadline}}</strong> to <strong>complete enrollment</strong> for this course.</p><p class="text-center cmp-enroll"><a href="https://userve.uvu.edu/StudentRegistrationSsb/ssb/personaSelection/selectPersona" class="btn btn-default ">Complete Enrollment</a></p>{{/ifEquals}}
									{{#if canvasCourseUrl}}<a class="canvas-link" title="{{subject}} {{courseNumber}} - {{sectionNumber}} Canvas course link." href="{{canvasCourseUrl}}"></a>{{/if}}
									
									<div class="general-course-info">
										<div><span class="general-info-title">Section:</span> {{sectionNumber}}</div>
										<div><span class="general-info-title">CRN:</span> {{crn}}</div>
										<div><span class="general-info-title">Credits:</span> {{creditHours}}</div>
									</div>
									<div class="course-meetings">
										<h4>Meetings</h4>
										{{#each courseMeetings}}
											<div class="meeting">
												{{#if beginTime}}
												<div><span class="general-info-title" title="Location"><i class="fas fa-map-marker-alt"></i></span> {{buildingCode}} {{roomCode}}</div>
												<div><span class="general-info-title">Start - End Dates:</span> {{startDate}} - {{endDate}}</div>
												<div><span class="general-info-title" title="Days of week."><span class="general-info-title"><i class="fas fa-calendar-day"></i></span> {{meetingDays}}<br/><i class="fas fa-clock"></i></span> {{beginTimeFormal}} - {{endTimeFormal}}</div>
												{{else}}
												<div><span class="general-info-title" title="Location"><i class="fas fa-map-marker-alt"></i></span> {{buildingCode}}</div>
												<div><span class="general-info-title">Start - End Dates:</span> {{startDate}} - {{endDate}}</div>
												<div>There is an online element to this course.</div>
												{{/if}}
											</div>
										{{/each}}
									</div>
									<div class="course-instructors">
										<h4>Instructors</h4>
										{{#each instructors}}
											<div class="instructor">
												<div><span class="general-info-title" title="Instructor Name">{{#if primaryIndicator}}<i class="fas fa-user-alt"></i>{{else}}<i class="far fa-user-alt"></i>{{/if}}</span> {{firstName}} {{lastName}}</div>
												<div>{{#if primaryIndicator}}Primary Instructor{{/if}}</div>
												<div><span class="general-info-title" title="Email"><i class="fas fa-envelope"></i></span> <a href="mailto:{{email}}">{{email}}</a></div>
											</div>
										{{/each}}
									</div>
								</div>
								`,
				loading: `<div class="text-center">
							<div class="loader">
								<div class="bg"></div>
								<div class="circle dark-bg"></div>
								<div class="circle dark-bg"></div>
								<div class="circle dark-bg"></div>
								<div class="circle dark-bg"></div>
								<div class="circle dark-bg"></div>
							</div>
						</div>`,
				integrated:`{{#if courses}}{{#each courses}}{{#unless waitlistPosition}}<div class="finals-course"><div class="course-title"><span>{{subject}} {{courseNumber}}</span></div><div class="course-final-date">{{{finalDateTime}}}</div></div>{{/unless}}{{/each}}{{else}}<p class="alert alert-warning">Not enrolled in any courses</p>{{/if}}`,
				noCourse: '<div class="col-sm-12"><p class="alert alert-warning">You have no courses for the current term.</p></div><div class="clearfix"></div>',
				course: '<div class="col-sm-12"><ul>{{#each data.COURSES}}<li>{{CRSENUMB}}-{{SECTNUMB}}: {{CRSETITLE}}<br/><span><strong>Final Date</strong>: {{FINAL_DATE}}</span></li>{{/each}}</ul></div><div class="clearfix"></div>',
				summer: '<div class="col-sm-12" id="summer-alert">Finals are given out during the final class period for Summer Term classes. Information will be given by your instructor.</div>',
				standalone: '{{#if data.COURSES}}<h3>Finals for the {{data.TERM_NAME}} {{data.TERM_YEAR}} semester</h3>{{#ifEquals data.TERM_NAME "Summer"}}{{>summer}}{{/ifEquals}}{{>course}}<p class="alert alert-warning">All course final dates are calculated estimates based on class start times and the final schedule. However your instructor could have different plans. All students are responsible to verify the date of each final. Please review the guidelines below.</p>{{else}}{{>noCourse}}{{/if}}'
			},
			helper: {
				waitlistedClass: function(d){
				if(d != null){
						if (d > 0) {
							return 'waitlisted';
						}else{
							return 'pending';
						}
					} else {
						return 'enrolled';
					}
				},
				ifEquals: function (arg1, arg2, options) {
					return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
				}
				
			},
			parse: false, // function to parse and return data before handlebars render
			func: {}, // custom interaction functions
			handlebarsUrl: myuvu.root+'js/handlebars.js', // location of handlebars
			Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false, // handlebars function
			moment: typeof moment != 'undefined' ? moment : false,
			preset: false,	// select preset
			// presets to overwrite the above vars
			presets: {}
		};
		// check for user passed in options
		$.extend(true, defs, opts);
		defs.func.listen = function (opts) {
			if (opts.listen.form !== false) {
				$(opts.listen.form).submit(()=> {
					opts.flush = true;
					run(opts); 
				});
			}
		};
		defs.func.beforeUnload = function(opts, sessVar){
			window.addEventListener("beforeunload", function(e) {
				if(myuvu.session.get(sessVar) !== 'undefined' && myuvu.session.get(sessVar) !== null){
					const cache = myuvu.session.get(sessVar);
					if(cache.getting === true){
						myuvu.session.del(sessVar);
					}
				}
				delete e.returnValue;
			});
		};
		function out(opts, d){
			let data = d.content;
				data.style = opts.style;
				opts.moment().utcOffset(-7);
			data.courses.sort((a,b) => {
				if("waitlistPosition" in a && "waitlistPosition" in b){
					if(a.waitlistPosition > b.waitlistPosition){
						return 1;
					}else{
						return -1;
					}
				}
			});
			data.courses.forEach(course => {
				if("waitlistRegisterDeadline" in course){
					course.formattedDeadline = opts.moment(course.waitlistRegisterDeadline).format("LLL");
				}
			});

			if(opts.$this.find(opts.out.courses).length){
				opts.$this.find(opts.out.courses).find('.courses').html(opts.template.courses(data)).find('.course').each(function (index) {
					$(this).delay((index + 1) * 100).fadeIn(650);
				});
				opts.$this.find(opts.out.courses).find('#semesterControls').html(opts.template.semesterControls(data));
			}
			if(opts.$this.find(opts.out.finals).length){
				opts.$this.find(opts.out.finals).html(opts.template.integrated(data));
			}
			
		}
		async function run(opts){
			try{
				const user = await getUser(opts);
				const addOpts = {'id': user.data.id, 'term': user.data.term, 'src': user.data.src};
				opts = {...opts, ...addOpts};
				opts.$this.find(opts.out.courses).html(opts.template.main());
				const courses =	await getData(opts, 'course-info', `${opts.url.base}?call=courses&id=${opts.id}&term=${opts.term}&src=${opts.src}`);
				out(opts, courses);
				opts.$this.find(opts.out.courses).fadeIn("slow", "swing");
			}catch(err){
				console.error('Error', err);
			}
		}
		function init(){
			// instance the plugin for multiple use
			return $main.each(async function () {
				var opts = $.extend({}, defs),
					ow, i;


				opts.$this = $(this);
				// extend opts from html data-
				$.extend(true, opts, getDataDash(opts.pre, opts));
				// getting templates
				getTemplates(opts);
				run(opts);
				opts.func.listen(opts);
				
			});
		}


		// check dependencies and init
		if (defs.Handlebars && defs.moment) {
			init();
		} else {
			$.getScript(defs.url.moment, function () {
				defs.moment = moment;
			});
			$.getScript(defs.url.handlebars, function () {
				defs.Handlebars = Handlebars;
				init();
			});
		}
	};
})(jQuery);