(function($) {
    /* handles expanding with new bookmarks on old pages */
    $.fn.portletExpand = function(opts, callback) {
    
        var $main = this,
            defs = {
                el: {
                    fill: '.controls .fa-expand',
                    back: '.back',
                    cont: '.controls'
                },
                template: {
                    cont: '<div class="controls"/>',
                    back: '<div class="back" title="Back"><img src="/images/icons/v2-icons/back_arrow.png" alt="Back"/></div>',
                    expand: '<span class="fa fa-expand expand" title="maximize"></span>'
                }
            },
            qString = (function () {
                var e, ret = {}, r = /([^&=]+)=([^&]+)/g;
                while ( (e = r.exec(window.location.search.substring(1))) !== null ) ret[decodeURIComponent(e[1])] = decodeURIComponent(e[2]);
                return ret;
            })();
        
        // check for user passed in options
        $.extend(true, defs, opts);
    
        // on url change
        $(window).on('hashchange.portlet', function(){
            var id = location.hash.replace('#', ''),
                $this = $('.portlet[data-fname="'+id+'"]');
    
            if( $('.portlet.maximized').length ){
                fill( $('.portlet.maximized') );
            }
            
            if( $this.length ){
                fill($this);
            }
    
        });
    
        if( location.hash.replace('#', '') !== '' ){
            fill( $('.portlet[data-fname="'+location.hash.replace('#','')+'"]') );
        }
    
        function fill($this){
            var $cont;
            if( $this.length ){
                if( $this.hasClass('maximized') ){
                    $this.removeClass('maximized');
                    $cont = $this.detach();
                    $('.page-content.fill-overlay').remove();
                    $('.fill-placeholder').after($cont);
                    $('.fill-placeholder').remove();
                    $('.page-content').not('.fill-overlay').fadeIn();
                }else{
                    $('.page').prepend('<div class="page-content row fill-overlay"></div>');
                    $('.page-content').not('.fill-overlay').fadeOut();
                    $this.after('<div class="fill-placeholder"></div>');
                    $cont = $this.detach();
                    $cont.addClass('maximized');
                    $('.fill-overlay').html($cont);
                }
            }
        }
    
        return $main.each(function(){
            var $this = $(this);
                
            // add controls
            //if( !$this.find(defs.el.cont) ) $this.append(defs.template.cont);
            $this.append(defs.template.back);
            //$this.find(defs.el.cont).append(defs.template.expand);
            // fullscreen function
            $this.on('click.fill', defs.el.fill, function(){
                var id = $this.hasClass('maximized') ? '' : typeof $this.attr('data-fname') !== 'undefined' ? $this.attr('data-fname') : '';
                
                history.pushState('', document.title, window.location.pathname + '#'+ id + window.location.search);
                fill($this);
            });
            // back function
            $this.on('click.back', defs.el.back, function(){
                history.pushState('', document.title, window.location.pathname + window.location.search);
                fill($this);
            });
        });
    
    };
    
    })(jQuery);