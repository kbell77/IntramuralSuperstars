/* 
*	uvannounce plugin
*/

(function ($) {

	$.fn.uvannounce = function (opts) {
		'use strict';
		var $main = this,
			defs = { // configurable options - set directly through plugin call or html data-
				pre: 'uva',
				url: {
					submit: 'https://uvannounce.uvu.edu/submit',
					base: 'https://uvannounce.uvu.edu/',
					tags: 'json/tags',
					anncs: 'json/anncs',
					attach: 'attachment/',
					handlebars: '/_resources/js/handlebars.js'
				},
				update: { // update when changes are made
					list: '.cats'
				},
				template: { // handlebars template or css class/id of template on page
					main: '<div class="titlebox clearfix"><h2><strong>UV</strong>Announce</h2><a class="submit-annc" href="{{url.submit}}">Submit an Announcement</a></div><div class="acc btn btn-default uva-toggle">Filter Announcements</div><div class="toggles"><h4>Show Categories:</h4><ul>	{{#each data.out}}{{#unless filter}}<li class="cat-btn tog{{#if show}} active{{/if}}" data-uva-tag="{{short}}" data-uva-id="{{_id}}"><div class="check"></div>{{name}}</li>{{/unless}}{{/each}}</ul></div><ul class="cats row">{{> list}}</ul>',
					list: '{{#each data.out}}{{#if items}}{{#if show}}{{#unless filter}}<li><div class="cat"><h3>{{name}}</h3><ul>{{#each items}}{{> item}}{{/each}}</ul></div></li>{{/unless}}{{/if}}{{/if}}{{/each}}',
					item: '{{#if show}}{{#if headline}}<li class="item"  id="{{id}}"><h4 class="title acc">{{headline}}</h4><div class="desc">{{#each image}}{{#if @first}}{{> image}}{{/if}}{{/each}}{{#if summary}}<div class="summary">{{{formatText summary}}}{{#if details}}<span class="more">show more</span>{{/if}}</div>{{#if details}}<div class="details hide">{{{formatText details}}}<div class="more">show less</div></div>{{/if}}{{else}}{{{details}}}{{/if}}{{#each image}}{{#if @first}} {{else}}{{> image}}{{/if}}{{/each}}{{#if link}}<br>{{> link}}{{/if}}{{#if email}}<br>{{> email}}{{/if}}{{#if pdf}}<br>{{#each pdf}}{{> pdf}}{{/each}}{{/if}}</div></li>{{/if}}{{/if}}',
					image: '<a href="{{url}}"><img class="left-3rd" src="{{url}}" alt="{{headline}}" title="{{filename}}"/></a>',
					link: '<br><strong>Link: </strong><a href="{{link}}">{{link}}</a>',
					email: '<br><strong>Email: </strong><a href="mailto:{{fixMail email}}">{{fixMail email}}</a>',
					pdf: '<br><a href="{{url}}">{{filename}}</a>'
				},
				helper: { // handlebars helpers
					formatText: function (s) { return s.replace(/\r\n|\n|\r/g, '<br>'); },
					fixMail: function (s) { return s.replace(/mailto:|http:\/\//gi, ''); }
				},
				regex: {
					email: /((?!\/).)*@/,
					image: /^((?!\/).)*(\.jpg$|\.jpeg$|\.png$|\.gif$)/i,
					link: /^(http:\/\/|https:\/\/|www\.)/i,
					pdf: /((?!\/).)*\.pdf/i
				},
				tags: 'all',
				func: { /* custom page interaction functions */ },
				Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false,
				data: { tags: false, anncs: false },
			},
			qString = (function () {
				var e, ret = {}, r = /([^&=]+)=([^&]+)/g;
				while ((e = r.exec(window.location.search.substring(1))) !== null) ret[decodeURIComponent(e[1])] = decodeURIComponent(e[2]);
				return ret;
			})();

		// check for user passed in options
		$.extend(true, defs, opts);

		// custom page interaction functions - can be extended or overwritten

		defs.func.accordion = function (opts) {
			$(opts.$this).on('click.' + opts.pre, '.acc', function () {
				if ($(this).hasClass('open')) {
					$(this).removeClass('open').next().slideUp(500);
				} else {
					$(this).addClass('open').next().slideDown(500);
				}
			});
		};

		defs.func.swap = function (opts) { // swap next item after .more
			$(opts.$this).on('click.' + opts.pre, '.more', function () {
				var $el = $(this).parent();
				if ($el.next().hasClass('hide')) {
					$el.addClass('hide').next().removeClass('hide');
				} else {
					$el.addClass('hide').prev().removeClass('hide');
				}
			});
		};

		defs.func.toggle = function (opts) { // toggles tags/filters tagged with .tog
			$(opts.$this).on('click.' + opts.pre, '.tog', function () {
				var tag = opts.data.tags[$(this).attr('data-' + opts.pre + '-id')];
				tag.show = tag.show ? false : true;
				if ($(this).hasClass('active')) {
					$(this).removeClass('active');
				} else {
					$(this).addClass('active');
				}
				filter(opts);
			});
		};


		/* global functions */
		// ajax data get
		function get(sub, opts, callback) {
			// ajax feed from proxy
			$.ajax(opts.url.base + sub, {
				dataType: 'jsonp',
				cache: true,
				jsonpCallback: 'uvannounce' // won't allow async within plugin but will attempt to cache
			}).done(function (d) {
				if (typeof callback == 'function') { callback(d); }
			});
		}

		// first word only lowercase
		function short(s) {
			return s.replace(',', '').trim().split(' ')[0].trim().toLowerCase();
		}

		// filter
		function filter(opts) {
			var ann, tag, i, x;
			for (i = 0; i < opts.data.anncs.length; i++) {
				ann = opts.data.anncs[i];
				ann.show = true;
				for (x = 0; ann.tags[x]; x++) {
					tag = opts.data.tags[ann.tags[x]];
					if (tag.filter && !tag.show) ann.show = false;
				}
			}
			update(opts);
		}

		// update view
		function update(opts) {
			var i;
			for (i in opts.update) {
				if (typeof opts.update[i] !== 'undefined') $(opts.$this).find(opts.update[i]).html(opts.template[i](opts));
			}
		}

		// get templates from either html or string
		function getTemplates(opts) {
			var t = opts.template,
				i;

			for (i in t) {
				if (t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0) t[i] = $(t[i]).html(); // test if template or selector
				defs.Handlebars.registerPartial(i, t[i]); // all templates are also a partial
				t[i] = defs.Handlebars.compile(t[i]); // make template
			}
			defs.Handlebars.registerHelper(opts.helper);
		}

		// getting all html5 data- attributes with matching prefix
		function getDataDash(pre, opts) {
			var dd = opts.$this[0].attributes,
				ow = {},
				val, sel, i, n,
				nest = function (sel, val) { // make nested array
					var s = sel.shift(),
						v = sel.length ? nest(sel, val) : val,
						r = {};
					r[typeof s !== 'undefined' ? s : sel] = v;
					return r;
				};

			for (i = 0; i < dd.length; i++) {
				if (dd[i].name.indexOf('data-' + pre + '-') !== -1) $.extend(true, ow, nest(dd[i].name.replace('data-' + pre + '-', '').split('-'), dd[i].value));
			}

			return ow;
		}

		// parse announcements
		function getAnncs(opts) {
			var anncs = opts.data.anncs,
				tags = opts.data.tags,
				ann, att, offset, i, x, y, z;

			if (anncs) {
				// sort announcements by tag
				for (i = 0; i < anncs.length; i++) {
					ann = anncs[i];
					// check for more details
					if (ann.summary.slice(-3) !== '...') ann.details = false;
					// check attachment types
					for (y = 0; y < ann.attachments.length; y++) {
						att = ann.attachments[y];
						att.url = opts.url.base + opts.url.attach + att._id;
						att.headline = ann.headline;
						for (z in opts.regex) {
							if (opts.regex[z].test(att.filename)) {
								if (typeof ann[z] == 'undefined') ann[z] = [];
								ann[z].push(att);
								att = false;
								break;
							}
						}
						if (att) {
							if (typeof ann.file == 'undefined') ann.file = [];
							ann.file.push(att);
						}
					}
					// check url types
					for (y in opts.regex) {
						if (opts.regex[y].test(ann.url)) {
							ann[y] = ann.url;
							break;
						}
					}
					ann.show = true;

					// add to tags
					for (x = 0; x < anncs[i].tags.length; x++) {
						if (typeof tags[ann.tags[x]].filter !== 'undefined') ann.show = tags[ann.tags[x]].show; // filter
						tags[ann.tags[x]].items.push(ann); // add to tag
					}
				}
				// output
				if (typeof opts.template.main === 'function') opts.$this.html(opts.template.main(opts));
				// auto scroll to/open
				if (qString.anncId) {
					if ($('#' + qString.anncId).length) {
						$('body,html').stop(true, true).animate({
							'scrollTop': $('#' + qString.anncId).offset().top
						}, 1000);
						$('#' + qString.anncId).find('.acc').addClass('open').next().slideDown().find('.hide').removeClass('hide').prev('.summary').addClass('hide');
					}

				}
			} else {
				get(opts.url.anncs, opts, function (d) {
					opts.data.anncs = d;
					getAnncs(opts);
				});
			}

		}

		// add tags to data array
		function getTags(opts) {
			var tags = opts.data.tags,
				short, i, t;

			if (tags) {
				opts.data.out = [];
				// build tags
				for (i in tags) {
					t = tags[i];
					t.items = [];
					short = t.name.replace(',', '').trim().split(' ')[0].trim().toLowerCase();
					short = opts.tags == 'all' ? ['cat', true] : typeof opts.tags[short] !== 'undefined' ? opts.tags[short] : [false];
					t.show = short == 'cat' ? true : short[0] == 'cat' ? short[1] : short[0] == 'filter' ? !short[1] : false;
					t.filter = short == 'filter' ? true : short[0] == 'filter' ? true : false;
					opts.data.out.push(t);
				}
				opts.data.out.sort(function (a, b) { return a.order - b.order; }); // sort output
				getAnncs(opts);
			} else {
				get(opts.url.tags, opts, function (d) {
					opts.data.tags = d;
					getTags(opts);
				});
			}
		}

		// init plugin
		function init() {
			// return plugin instance
			return $main.each(function () {
				var opts = $.extend({}, defs),
					ow, i;

				opts.$this = $(this);

				// extend opts from html data-
				$.extend(true, opts, getDataDash(opts.pre, opts));
				// start parsing
				getTags(opts);
				// getting templates
				getTemplates(opts);
				// running custom functions for interaction etc
				for (i in opts.func) { opts.func[i](opts); }
			});
		}


		// check dependencies and init
		if (defs.Handlebars) {
			init();
		} else {
			$.getScript(defs.url.handlebars, function () { defs.Handlebars = Handlebars; init(); });
		}

	};


})(jQuery);