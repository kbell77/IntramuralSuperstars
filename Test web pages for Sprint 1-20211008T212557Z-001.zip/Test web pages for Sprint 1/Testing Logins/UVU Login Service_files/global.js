// various site wide functions, plugins and scripts

/***** initiate all needed scripts here in the document ready */
$(document).ready(function(){
	
	// make the menu touch friendly
	megaMenuTouch();
	megaMenuMobile();
	// small screen mobile menu slide reveal
	$('#container').slideRevealMenu({collapse: false});
	
	// breadcrumb
	breadCrumb();
	
	// liquid iframe
	$('.contentArea').liquidIframe();
	
	// search suggest
	$('#q').miniSearch();
	
	// accordion
	accordion('accordion');
	
	// Adaptive table
	$('.heads').tableAdapt();
});

/******* functions *********/

// makes the breadcrumb expand and contract
function breadCrumb(){
	var spd = 250, // speed of the transition
		css3d = typeof Modernizr != 'undefined' ? Modernizr.csstransforms3d ? Modernizr.csstransforms3d : false : false, // this checks for 3d transforms hardware animation on mobile devices
		cssanim = {'transition' : 'all '+spd+'ms ease-in-out'}, // transition add
		cssnone = {'transition' : ''}; // transition remove
	$('.breadBag').removeClass('native'); // this turns off native css hover
	// reset everything to a closed state
	$('.breadBag .loaf li').each(function(i){
		i++;
		if(css3d){
			$(this).css('transform','translate3d(-'+i+'00%,0,0)');
		}else{
			$(this).css({'margin-left': '-100%'}); // slide everything to the left
		}
	});
	$('.breadBag .loaf').css('display','none'); // hide the parent div
	// click function
	$('.breadTie').click(function() {
		// close
		if($(this).hasClass('open')){
			$(this).removeClass('open');
			$(' ~ .loaf li', this).each(function(i){ // animate out
				i++;
				if(css3d){ // hardware accelerated animation
					$(this).css(cssanim).css('transform','translate3d(-'+i+'00%,0,0)').dequeue().delay(spd).queue(function(){
						$(this).css(cssnone);
					});
				}else{	// fallback javascript animation
					$(this).animate({'margin-left': '-100%'},spd);
				}
			});
			$(' ~ .loaf', this).dequeue().delay(spd).queue(function(){
				$(this).css('display','none'); // hide the parent div after animation is done;
			});
			// open
		}else{
			$(this).addClass('open');
			$(' ~ .loaf', this).css('display','block'); // show the parent div
			if(css3d){ // hardware animation
				// minor 50ms delay for dom to un-hide parent
				$(' ~ .loaf li', this).css(cssanim).dequeue().delay(50).queue(function(){
					$(this).css('transform', 'translate3d(0,0,0)').dequeue().delay(spd).queue(function(){
						$(this).css(cssnone); // remove transition for no-conflict
					});
				});
			}else{	// js fallback
				$(' ~ .loaf li', this).animate({'margin-left':'0'},spd);
			}
		}
	});

}

// makes mega menu toggle on touch devices
function megaMenuTouch(){
	// mega menu
	var touch = typeof Modernizr != 'undefined' ? Modernizr.touch ? Modernizr.touch : false : false;
	if(touch){
		// add click function to dropnav buttons
		$('#schoolNav > ul > li').click(function(e){
			window.removeEventListener('touchend'); // remove de-click
			// find the drop nav div
			if($(this).hasClass('open')){
				$('#schoolNav > ul > li').removeClass('open');
			}else{
				$('#schoolNav > ul > li').removeClass('open');
				$(this).addClass('open');
				// de-click outside menu
				e.preventDefault(); // stop click event
				window.addEventListener('touchend', megaMenuDeClick, false); // add de-click
				return false;
			}
		});
	}
	// we use touch based eventlisteners for de-click due to apple's buggy click implimentation
	function megaMenuDeClick(e){
		if($(e.target).parents('#schoolNav').length === 0){ // if we're not selecting the menu de-click
			window.removeEventListener('touchend');
			$('#schoolNav > ul > li').removeClass('open');
		}
	}
}

/**** mega menu in mobile - accordion sub-menu ****/
function megaMenuMobile(){
	$(window).resize(function() {
		clearTimeout(this.testing); // reset our timer
		this.testing = setTimeout(function(){
			if ($(window).width() > 760) {
				$('#searchAndNav').css({'display':''});
				$('#universityLinks > div').css({'display':''});
				$('#collegesAndSchools > div').css({'display':''});
				$('#searchMobile').addClass('ori_mobile').css({'background-position':''});
			}	
		}, 300);
	});
	$('#searchMobile').click(function() {
		if($(window).width() < 760) {
			if ($('#searchMobile').hasClass('ori_mobile')) {
				$('#searchAndNav').slideDown();
				$('#searchMobile').removeClass('ori_mobile').css({'background-position':'-42px 0'});
			}
			else {
				$('#searchAndNav').slideUp();
				$('#searchMobile').addClass('ori_mobile').css({'background-position':''});	
			}
		}
		return false;
	});
	$('#schoolNav > ul > li').click(function() {
		if($(window).width() < 760) {
			$(' > div',this).slideToggle();
		}
	});
}

//accordion
function accordion(el){
	var elSel = '.'+el; // jquery friendly selector
	// if clicked show/hide accordion content
	$(elSel).click(function(){
		if ($(this).next().is(':visible')){
			$(this).next().slideUp(500);
		}else{
			$(this).next().slideDown(500);
		}
	});
	// hide accordion content
	$(elSel).next().hide();
	// url hash stuff
	// on page load check for url hash
	if(location.hash !== ''){
		if($(location.hash).hasClass(el)){
			$(location.hash).next().slideDown(500);
		}
	}
	// on change check for url hash - anchor tag clicked
	$(window).on('hashchange', function(){
		if($(location.hash).hasClass(el)){
			$(location.hash).next().slideDown(500);
		}
	});
}

//this script is to open the uv link little window
function little_win(alink){
	if(alink == ""){
		alink = "uv_link.html";
	}
	window.open(alink, "uv_win", "width=344,height=311,top=100,left=200");
}

// Code for an adaptive table
// Add 'class="heads"' to table tag
(function($){
$.fn.tableAdapt = function(options, callback)
{
	if ($(window).width() < 1100) {
				$('table.heads').removeAttr('style');
	}	
	$(window).resize(function() {
		clearTimeout(this.testing); // reset our timer
		this.testing = setTimeout(function(){
			if ($(window).width() < 1100) {
				$('table.heads').removeAttr('style');
			}	
		}, 300);
	});
	if (!this) return false;
	
	$(this).each(function(i){
		var $main = $(this);
		var heads = [];
		$(' tr:first > th, tr:first > td', this).each(function(x){
			heads[x] = $(this).text();
		});
		$(' tr:first', this).addClass('headsAdapt');
		$('tr', this).not(':first').after('<tr class="nohead"><td>&nbsp;</td></tr>');
		$('.headsAdapt',this).siblings('tr').not('.nohead').each(function(x){
			$(' > td', this).each(function(y){
				$(this).addClass('postTd');
				$(this).wrapInner('<div class="rightTd" />');
				$(this).prepend('<div class="preTd">'+heads[y]+'</div>');
			});
		});
	});
}
})(jQuery);

/************** plugins (minified)********************/

// Slide menu jquery plugin for smallscreen mobile devices - ryan - source: uvu.edu/wds
(function($){$.fn.slideRevealMenu=function(options){if(!this)return false;var defs={toggle:'#slideMenuButton',menu:'#slideMenu',collapse:true,collapseElement:' > ul > li ul',moreClass:'more',lessClass:'less',spd:250,width:'260',css3:typeof Modernizr!='undefined'?Modernizr.csstransitions?Modernizr.csstransitions:false:false,css3d:typeof Modernizr!='undefined'?Modernizr.csstransforms3d?Modernizr.csstransforms3d:false:false,touch:typeof Modernizr!='undefined'?Modernizr.touch?Modernizr.touch:false:false};defs=$.extend(defs,options);var $this=this;var tog=defs.toggle;var menu=defs.menu;var collEl=defs.collapseElement;var coll=defs.collapse;var more=defs.moreClass;var less=defs.lessClass;var spd=defs.spd;var width=defs.width;var css3=defs.css3;var css3d=defs.css3d;var cssTrans={'-webkit-transition':'all '+spd+'ms ease-in-out 0s','-moz-transition':'all '+spd+'ms ease-in-out 0s','transition':'all '+spd+'ms ease-in-out 0s'};var cssNone={'-webkit-transition':'','-moz-transition':'','transition':''};var cssGone={'-webkit-transition':'','-moz-transition':'','transition':'','-webkit-transform':'','-moz-transform':'','transform':''};$(menu+' a:hidden').bind('click',stopClick);touchSlide();if(coll){accordion();}$(window).resize(function(){clearTimeout(this.slideReveal);this.slideReveal=setTimeout(function(){if($(menu+':visible').length>0){if(parseInt($this.width())>768){slide('in');}}},500);});function touchSlide(){if(defs.touch&&css3){var fingers=0;function touchStart(e){e.preventDefault();if(e.targetTouches.length==1&&fingers<2){fingers++;var x=this.touchStartPositionOnXAxis=e.targetTouches[0].clientX;var y=this.touchStartPositionOnYAxis=e.targetTouches[0].clientY;var old=getCurTrans($this);$this.data('slideRevealMenu',{'down':true,'x':x,'y':y,'oldX':old[0],'oldY':old[1],'moved':false,'cur':old[0],'dir':false});return false;}}function touchMove(e){e.preventDefault();if(e.targetTouches.length==1&&fingers<2){var posX=this.touchStartPositionOnXAxis=e.targetTouches[0].clientX;var posY=this.touchStartPositionOnYAxis=e.targetTouches[0].clientY;if($this.data('slideRevealMenu').down==true){var dir='left';if(($this.data('slideRevealMenu').cur-posX)<0)dir='right';$this.data('slideRevealMenu',$.extend(true,$this.data('slideRevealMenu'),{'moved':true,'cur':posX,'dir':dir}));pan(event,[posX,posY],'x');$(menu).show();}}}function touchEnd(e){fingers--;$this.data('slideRevealMenu').down=false;var old=getCurTrans($this);if($this.data('slideRevealMenu').moved==true){if($this.data('slideRevealMenu').dir=='right'){$(menu).show();slide('out');}else{slide('in');}}else{if(old[0]==0){$(menu).show();slide('out');}else if(old[0]==width){slide('in');}}}$(tog).each(function(){this.addEventListener("touchstart",touchStart,false);this.addEventListener("touchmove",touchMove,false);this.addEventListener("touchend",touchEnd,false);});}else{$(tog).click(function(){if($(menu).is(':hidden')){$(menu).show();slide('out');}else{slide('in');}});}}function accordion(){if(css3&&defs.touch){$(menu).css('display','block');$(menu).height($(menu).height());var mData={};mData[menu]={'adjust':0,'parent':false,'children':false};$(menu).data('slideRevealMenu',mData);mData=$(menu).data('slideRevealMenu');var gId=0;function setupMenu(el,nest){var i=0;$(el).parent().each(function(){if(!nest)nest=menu;var $this=$(this);var h=$this.children('ul').height();var cH=$this.children('a').outerHeight();var mObj={'el':this,'parent':nest,'children':false,'height':h,'closed':cH,'toggle':false};var ogId=menu+gId;mData[ogId]=mObj;var obj={'id':ogId};$this.data('slideRevealMenu',obj);$this.children('ul').css(cssTrans).css({'opacity':0});if(!mData[nest].children){mData[nest].children=[];}mData[nest].children[i]=ogId;if(typeof mData[nest].height!='undefined')mData[nest].height=mData[nest].height-h;$this.prepend('<span class="'+more+'"></span>');$this.height(cH);i++;gId++;if($this.children('ul').find('ul').length){setupMenu($this.children('ul').find('ul'),ogId);}});}setupMenu(menu+' '+collEl,false);$(menu).css('display','none');$(menu).find('.'+more).click(function(){var $this=$(this).parent();var data=$this.data('slideRevealMenu');var adjust=false;function openIt(id){if(typeof mData[id]!='undefined'&&typeof mData[id].el!='undefined'){var $this=$(mData[id].el);if(!adjust){adjust=mData[id].height;}$this.children('ul').css('opacity',1);$this.nextAll().each(function(){$(this).css(cssTrans).css(getTrans({top:adjust,left:0}));});$this.dequeue().delay(spd+100).queue(function(){$this.css('height','');$this.nextAll().each(function(){$(this).css(cssGone);});});mData[id].toggle=true;$this.children('.'+more).addClass(less);if(mData[id].parent){var par=mData[id].parent;mData[par].height=mData[par].height+adjust;openIt(mData[id].parent);}}}function closeIt(id){if(typeof mData[id]!='undefined'&&typeof mData[id].el!='undefined'){var $this=$(mData[id].el);if(!adjust){adjust=$this.children('ul').height()*-1;}$this.children('ul').css('opacity',0);$this.nextAll().each(function(){$(this).css(cssTrans).css(getTrans({top:adjust,left:0}));});$this.dequeue().delay(spd+100).queue(function(){$this.css('height',mData[id].closed);$this.nextAll().each(function(){$(this).css(cssGone);});});mData[id].toggle=false;$this.children('.'+more).removeClass(less);if(mData[id].parent){var par=mData[id].parent;mData[par].height=mData[par].height+adjust;openIt(mData[id].parent);}}}if(mData[data.id].toggle){closeIt(data.id);}else{openIt(data.id);}});}else{$(menu+' '+collEl).slideUp();$(menu+' '+collEl).parent().prepend('<span class="'+more+'"></span>');$(menu+' .'+more).click(function(){if($(this).hasClass(less)){$(this).siblings('ul').slideUp(spd);$(this).removeClass(less);}else{$(this).siblings('ul').slideDown(spd);$(this).addClass(less);}});}}function getTrans(pos){var trans='';var z=css3d?', 0px':'';trans=css3d?'translate3d(':'translate(';trans+=pos.left+'px, '+pos.top+'px'+z+')';var giveTrans={'-webkit-transform':trans,'-moz-transform':trans,'transform':trans};return giveTrans;}function slide(dir){var lWidth=0;if(dir=='out'){lWidth=width;}$this.data('down',false);if(css3){$this.css(cssTrans).css(getTrans({left:lWidth,top:'0'}));$(menu).css('opacity',1);$this.delay(spd,'slideMenu').queue('slideMenu',function(){$this.css(cssNone);if(dir=='in'){$(menu+' a').bind('click',stopClick);$(menu).css('display','none');}else{$this.delay(100,'slideMenu').queue('slideMenu',function(){$(menu+' a').unbind('click',stopClick);}).dequeue('slideMenu');}}).dequeue('slideMenu');}else{$this.animate({'left':lWidth+'px'},spd,function(){if(dir=='in'){$(menu+' a').bind('click',stopClick);$(menu).hide();}else{$this.delay(100,'slideMenu').queue('slideMenu',function(){$(menu+' a').unbind('click',stopClick);}).dequeue('slideMenu');}});}return false;}function getCurTrans(el){var old=$(el).css('-webkit-transform')?$(el).css('-webkit-transform'):$(el).css('-moz-transform')?$(el).css('-moz-transform'):$(el).css('transform');old=old.substr(7,old.length-8).split(', ');var oldX=old[0]?parseInt(old[4]):0;var oldY=old[0]?parseInt(old[5]):0;return[oldX,oldY];}function pan(e,pos,dir){e.preventDefault();var dir=dir?dir:false;if(css3){if(pos[0]<=width){var x=$this.data('slideRevealMenu').oldX+($this.data('slideRevealMenu').x-pos[0])*-1;var y=$this.data('slideRevealMenu').oldY+($this.data('slideRevealMenu').y-pos[1])*-1;if(dir=='y')x=0;if(dir=='x')y=0;if(x<0)x=0;$this.css(getTrans({'left':x,'top':y}));}}else{if(pos[0]<=width&&pos[0]>0){var x=$this.data('slideRevealMenu').scrollLeft+$this.data('slideRevealMenu').x-pos[0];var y=$this.data('slideRevealMenu').scrollTop+$this.data('slideRevealMenu').y-pos[1];$this.parent().scrollLeft(x);$this.parent().scrollTop(y);}}}function stopClick(event){event.preventDefault();return false;}}})(jQuery);




// selective show hide nice fade slide css3 - ryan - source: uvu.edu/wds
(function(a){a.fn.selToggleNice=function(l){if(!this){return false}var h={elements:"",not:"",speed:250,delay:750,fadeBackground:false,css3:typeof Modernizr?Modernizr.csstransitions?Modernizr.csstransitions:false:false,padding:0},c=this,j=false,k,b,d,e,i,g;h=a.extend(h,l);if(a(h.elements).length>0){k=h.css3;b=h.elements;d=h.not;e=c.css("background-color");i=(h.fadeBackground&&k&&a(h.fadeBackground).length>0)?f(h.fadeBackground):false;g={"-webkit-transition":"all "+(h.speed/1000)+"s ease-in-out","-moz-transition":"all "+(h.speed/1000)+"s ease-in-out",transition:"all "+(h.speed/1000)+"s ease-in-out"};c.find(b).each(function(){a(this).css("display","block");var m=a(this).width()+h.padding;a(this).data("selToggleWidth",m);if(k){a(this).css(g).css({width:"1px",opacity:"0"})}else{a(this).stop().animate({width:"1px",opacity:"0"})}});if(i&&k){c.find(h.fadeBackground).css(g).css({"background-color":"rgba("+i+",0)"})}c.hover(function(){clearTimeout(j);if(i&&k){c.find(h.fadeBackground).css("background-color","rgba("+i+",1)")}c.find(b).not(d).each(function(){var m=a(this).data("selToggleWidth");if(k){a(this).css({width:m+"px"}).animate({opacity:"0"},h.speed,function(){a(this).css({opacity:"1"})})}else{a(this).stop().animate({width:m+"px"},h.speed,function(){a(this).animate({opacity:"1"},h.speed)})}})},function(){function m(){if(i&&k){c.find(h.fadeBackground).delay(h.delay).css({"background-color":"rgba("+i+",0)"})}if(k){c.find(b).not(d).stop().css({width:"1px",opacity:"0"})}else{c.find(b).not(d).stop().animate({width:"1px",opacity:"0"})}}if(h.delay){j=setTimeout(m,h.delay)}else{m()}})}function f(n){var s=a(n).css("background-color"),o,q,p,m;if(typeof s!="undefined"){s=s.replace(/#|rgb|\(|\)/g,"");if(/,/.test(s)){o=s}else{q=parseInt(s.substring(0,2),16);p=parseInt(s.substring(2,4),16);m=parseInt(s.substring(4,6),16);o=q+","+m+","+m}}else{o=false}return o}}})(jQuery);

																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																	 // iframe liquid scaling for ataptive layouts
// best practice - don't apply scale or style directly to iframes. Wrap iframe with styled div.
// If you don't want this plugin to effect your iframe add the class .noScale to your iframe
(function($){$.fn.liquidIframe=function(){return this.each(function(){$('iframe:not(.noScale)',this).each(function(){var $this=$(this);var mW=$this.attr('width')?$this.attr('width'):$this.css('width')?$this.css('width'):0;var mH=$this.attr('height')?$this.attr('height'):$this.css('height')?$this.css('height'):0;var w=mW>0?mW:$this.width();var h=mH>0?mH:$this.height();if(w>0&&h>0){var aspect=h/w;$this.removeAttr('height').removeAttr('width').css({'position':'absolute','width':'100%','height':'100%','top':'0','left':'0'});$this.wrap('<div style="max-width: '+mW+'px; max-height: '+mH+'px;"><div style="width: 100%; padding-bottom:'+(aspect*100)+'%; position: relative"></div></div>');}});});}})(jQuery);

// Search suggest
(function(){$.fn.miniSearch=function(p){var f={searchUrl:"www.uvu.edu/search",output:"#searchSuggest",formId:"#search",delay:100,showLinks:true,total:10,superSearch:true,superUrl:"www.uvu.edu/search/miniSearch.php",googleSearch:true,googleUrl:"gmini.uvu.edu/search",client:"jsonp_frontend",site:"default_collection",proxystylesheet:"jsonp_frontend",proxyreload:1,showErrors:false},j=$(this),e=/iphone|ipod|ipad \d+\.\d+/i.test(navigator.appVersion),o=f.useProtocol?document.location.protocol+"//":"http://",q=false,b=false,m=function(){this.quick=[];this.google=[];this.more=[];this.alt=[]};menu=new m();f=$.extend(f,p);if($(f.formId).length>0&&$(f.output).length>0){$(f.formId).on("keyup.miniSearch",function(r){if(r.which===27){clearTimeout(this.miniSearch);$(f.output).fadeOut();menu=new m()}else{if(r.which===38||r.which===40){var s=$(f.output+" .searchSelect").length?parseInt($(f.output+" .searchSelect").attr("rel"),10):-1;if(r.which==38){s--}else{if(r.which==40){s++}}if(s<0){$(f.output+" .searchSelect").removeClass("searchSelect");j.focus()}else{$(f.output+" .searchSelect").removeClass("searchSelect");$(f.output+' > a[rel="'+s+'"]').addClass("searchSelect")}r.preventDefault();return false}else{if(r.which===13){if($(f.output+" .searchSelect").length){window.location.href=$(f.output+" .searchSelect").attr("href")}else{$(f.formId).submit()}}else{if(r.which!==37&&r.which!==39){clearTimeout(this.miniSearch);menu=new m();this.miniSearch=setTimeout(function(){var u=false;if(j.val()){u=j.val()}$(f.output).html("");if(u&&u!==""){if(q){q.abort()}if(b){b.abort()}if(f.superSearch){q=$.ajax({type:"GET",url:o+f.superUrl,dataType:"jsonp",data:{q:u},error:function(x,v,w){if(f.showErrors){$(f.output).html("super "+x+" - "+v+" - "+w)}},success:function(v){menu=new m();i(v);if((v.quick.length<f.total&&f.googleSearch)||!v.quick&&f.googleSearch){t()}}})}}else{if(q){q.abort()}if(b){b.abort()}menu=new m();$(f.output).fadeOut()}function t(){b=$.ajax({type:"GET",url:o+f.googleUrl,dataType:"jsonp",data:{q:u,client:f.client,site:f.site,output:"xml_no_dtd",proxystylesheet:f.proxystylesheet,proxyreload:f.proxyreload},error:function(x,v,w){if(f.showErrors){$(f.output).html("google "+x+" - "+v+" - "+w)}},success:function(v){i(v)}})}},f.delay)}}}}}).on("keydown.miniSearch",function(r){if(r.which==38||r.which==40||r.which==13){r.preventDefault()}})}function i(u){var s=false,t,r=function(){if(s){$(f.output).fadeOut();if(e){j.unbind("blur")}else{$(f.formId).parent().unbind();$(document).unbind("click."+f.formId,r)}}};if((typeof u!="undefined"&&q)||(typeof u!="undefined"&&b)){if(typeof u.quick!="undefined"||(typeof u.results!="undefined"&&parseInt(u.results_nav.total_results,10))>0){t=l(u);$(f.output).html(t);$(f.output).stop().css({opacity:""}).fadeIn();if(e){s=true;j.blur(r)}else{$(f.formId).hover(function(){s=false},function(){s=true});$(document).bind("click."+f.formId,r)}}}}function l(z){var x=[],t=[],u=[],v=[],r=[],w=[],A=[],s=[],B=[],y=o+"//"+f.searchUrl+"/?q=",C=function(H){var I,D=[],F=0,E;if(typeof H.quick[0]!="undefined"){I=G(H.quick,false)}if(typeof H.google[0]!="undefined"){I=G(H.google,false)}if(typeof H.more[0]!="undefined"){I=G(H.more,true)}if(typeof H.alt[0]!="undefined"){I=G(H.alt,true)}function G(J,K){for(E=0;E<J.length;E++){if((E<f.total&&F<f.total)||K){D[F]=J[E];D[F].setAttribute("rel",F);F++}else{break}}return true}return D};if(typeof z.quick!="undefined"){t=n(z)}if(typeof z.results!="undefined"){w=a(z)}A=document.createElement("a");A.setAttribute("href",y+z.query.replace(/\s/g,"+"));A.setAttribute("class","searchAlt");A.innerHTML="<span><strong>Show more : </strong> "+z.query+"</span>";if(typeof z.alt!="undefined"&&typeof z.alt[0]!="undefined"){s=h(z)}if(typeof t[0]!="undefined"){menu.quick=t}c(u,r);c(u,w);if(typeof u[0]!="undefined"){menu.google=u}menu.more[0]=A;c(v,s);c(v,B);menu.alt=v;x=C(menu);return x}function n(v){var s=[],r,u,t;if(v.quick){$.each(v.quick,function(w,x){if(w>=f.total){return false}r=f.showLinks?x[1]?x[1]:"":"";u=x[2]?x[2]:"No Title";t=document.createElement("a");t.setAttribute("href",r);if(x[5]==="y"){t.setAttribute("class","sponsoredKeyword")}else{t.setAttribute("class","searchKeyword")}t.innerHTML="<span><b>"+u+"</b></span><br>"+r+"</a>";s.push(t)})}else{s=false}return s}function k(v){var s=[],t,r,u;$.each(v.keymatch,function(w,x){r=f.showLinks?x.url?x.url:"":"";u=x.title?x.title:"No Title",t=document.createElement("a");t.setAttribute("href",r);t.setAttribute("class","searchKeyword");t.innerHTML="<span><b>"+u+"</b></span><br>"+r+"</a>";s.push(t)});return s}function a(x){var t=[],w=[],s=[],r=[],u=[],v=x.query.split(" ");$.each(x.results,function(F,z){var D=f.showLinks?z.url?z.url:"":"",B=z.title?z.title:false,A=z.summary.replace(/<b>\.\.\.<\/b>|<b>|<\/b>|<br>|<br \/>/g,""),C=new RegExp(d(v,true),"gi"),G=new RegExp(d(v,false),"gi"),E=new RegExp("(\\b.{0,25}("+d(v,true)+"))(.{0,25}.\\b|$|\\s|.)","i"),y=document.createElement("a");y.setAttribute("href",D);if(B&&C.test(B)>0){desc=B.replace(C,"<b>$&</b>");y.innerHTML="<span>"+desc+"</span><br>"+D;if(z.mime===""){if(G.test(B)){w.push(y)}else{s.push(y)}}else{u.push(y)}}else{if(C.test(A)){desc=E.exec(A);desc=desc[0]}else{desc=/^.{0,50}.*?\b/.exec(A);desc=desc?desc[0]:B.replace(C,"<b>$&</b>")}desc=desc.replace(C,"<b>$&</b>");y.innerHTML="<span>"+desc+"</span><br>"+D+"</a>";if(z.mime===""){r.push(y)}else{u.push(y)}}});c(t,w);c(t,s);c(t,r);c(t,u);return t}function h(s){var r=[];$.each(s.alt,function(t,w){var u=document.createElement("a"),v=w[2].replace(/\s/g,"+");u.setAttribute("href",searchPage+v);u.setAttribute("class","searchAlt");u.setAttribute("rel",html.length);u.innerHTML="<span><strong>search : </strong> "+w[2]+"</span>";r.push(u)});return r}function g(s){var r=[];$.each(s.altsearch,function(t,w){var u=document.createElement("a"),v=w.title.replace(/\s/g,"+");u.setAttribute("href",searchPage+v);u.setAttribute("class","searchAlt");u.setAttribute("rel",html.length);u.innerHTML="<span><strong>search : </strong> "+w.title+"</span>";r.push(u)});return r}function d(w,v){var t="",s="|",r=w.length-1,u=0;if(v){for(u=0;u<=r;u++){if(u===0){s=""}else{s="|"}t=t+s+w[u]}}else{t="(";for(u=0;u<=r;u++){t=t+"(?=.*"+w[u]+")"}t=t+")"}return t}function c(t,r){for(var s=0;s<=r.length-1;s++){t.push(r[s])}}}})(jQuery);
