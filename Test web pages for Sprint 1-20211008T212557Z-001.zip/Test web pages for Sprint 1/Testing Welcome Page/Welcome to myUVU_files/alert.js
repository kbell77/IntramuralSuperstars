$(document).ready(function(){
	var delay = 30000,
		url = 'https://www.uvu.edu/_resources/php/jsonproxy.php?url=_alert/alert.inc';
		css = myuvu.resources+'/js/css/alert.css';

	function modal(d){
		var content,modal,banner;
				
		if( $(d).find('#emergency').length ){
			$('head').append('<link href="'+css+'" rel="stylesheet" type="text/css" />');
			content = $(d).find('#emergencywrap').html();
			modal = '<div class="modal fade alertModal" tabindex="-1" role="dialog"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-body">'+content+'</div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div>';
			banner = '<div class="alertBanner">'+content+'</div>';

			// banner for all pages
			$('.page-content').prepend(banner);

			// modal for homepage
			if( $('body').hasClass('home') ){
				$('body').append(modal);
				if( typeof $.fn.modal === 'function'){
					$('.alertModal').modal();
				}else{
					$.getScript(myuvu.root+myuvu.resources+'/js/bootstrap.min.js', function(){
						$('.alertModal').modal();
					});
				}
			}

			$('.detached iframe').css('top', 60 + parseInt($('.alertBanner').outerHeight()) +'px' );
			
		}
	}

	if( myuvu.session.get('alertTime') === null || myuvu.session.get('alertTime') === 'undefined' || ( parseInt(myuvu.session.get('alertTime')) + delay < new Date().getTime() ) ){
		$.ajax({
			url: url,
			dataType: 'jsonp'
		}).done(function(d){
			modal(d);
			try{
				myuvu.session.set('alertTime', new Date().getTime());
				myuvu.session.set('alertHtml', d);
			}catch(e){
				console.log('Warning: failed to cache alert');
			}
			
			console.log('alert checked');
		});
	}else{
		modal(myuvu.session.get('alertHtml'));
	}

});
