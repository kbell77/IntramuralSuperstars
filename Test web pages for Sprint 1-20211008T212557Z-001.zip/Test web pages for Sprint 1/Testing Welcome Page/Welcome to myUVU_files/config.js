if(typeof uvu === 'undefined') var uvu = {};
// plugin loading setup
(function () {
    var root = myuvu.server + myuvu.root,
        js = root + myuvu.common + 'js/',
        css = root + myuvu.common + 'css/',
        ext = root + myuvu.common + 'ext/',
        preset = {
            jquery: js + 'jquery-3.4.1.min.js',
            handlebars: js + 'handlebars.min.js',
            moment: js + 'moment.min.js',
			vue: js + 'vue.js',
            editpage: js + 'editpage.js',
            classy: ext + 'classy/classy.js',
			bootbox: js + 'bootbox.min.js',
			bootstrap: js + 'bootstrap.min.js',
            'data-view': ext + 'dataapi/js/dataview.js?v=1.092018.2',
            blog: ['handlebars', 'data-view', root + myuvu.common + '/blog/js/blog.js'],
            'my-page': [ext + 'mypage/sortable.min.js', 'handlebars', ext + 'mypage/mypage.js', ext + 'mypage/mypage.css'],
            include: js + 'include.js',
            search: ext + 'search/js/search.js',
            quicksearch: ext + 'search/js/quicksearch.js',
			'dept-nav': ['handlebars', js+ 'dept-nav.js'],
            injector: js + 'injector.js',
			'check-access': ['handlebars', 'bootbox', ext+'check-access/index.js?v=2021091302'],
            'provision-check': ['handlebars', ext + 'provision-check/cloud-tools.js', ext + 'provision-check/css/style.css'],
			'cloud-tools':['handlebars', ext + 'cloud-tools/index.js?v=200810', ext + 'cloud-tools/css/style.css'],
            portlet: js + 'portlet.js',
            'portlet-expand': js + 'portlet-expand.js',
            webowners: ['handlebars', ext + '/webowners/webowners.js'],
            'email-preview': ['moment', 'handlebars', ext + 'email-preview/index.js?ver=210826', ext + 'email-preview/css/styles.css?v=210826'],
            'events-cal': ['moment', 'handlebars', ext + '25live/25live-cal-plugin/clndr.min.js', ext + '25live/25live-cal-plugin/events-cal.js?v=210601', ext + '25live/25live-cal-plugin/events-cal.css'],
            'event-list': ['moment', 'handlebars', ext + '25live/25live-event-list/js/event-list.js', ext + '25live/25live-event-list/css/event-list.css'],
            'digital-signage': ['slider', ext + 'digital-signage/digital-signage.js', ext + 'digital-signage/myuvu-digitalsignage.css'],
            software: ['handlebars', ext + 'software/index.js', ext + 'software/css/style.css'],
            iframeresizer: js + 'iframeresizer.min.js',
            detached: js + 'detached.js',
            webproxy: js + 'webproxy.js',
            'my-courses': ['handlebars', ext + 'my-courses/index.js?ver=21082401', ext + 'my-courses/css/styles.css?v=210813'],
			'course-calendar': ['handlebars', ext + 'my-courses/course-calendar.js', ext + 'my-courses/css/course-calendar.css'],
            countdown: ['handlebars', ext + 'countdown/countdown.js?v=200626', ext + 'countdown/countdown.css'],
            myuvuaccordion: [ext + 'accordion/myuvuaccordion.js', ext + 'accordion/myuvuaccordion.css'],
            accordion: ext + 'accordion/accordion.js',
            slider: ['handlebars', ext + 'slick/slick.min.js', ext + 'slick/slick.css'],
            lightbox: ['slider', ext + 'lity/js/lightbox.js', ext + 'lity/js/lity.min.js', ext + '/lity/lity.min.css'],
			imitationLazyloader: [ext + 'scrollclass/scrollclass.min.js'],
            uvannounce: ['handlebars', ext + 'uvannounce/uvannounce.js?v=20200226', ext + 'uvannounce/uvannounce.css'],
			'uvannounce-2': ['handlebars', ext + 'uvannounce/index.js?v=210709', ext + 'uvannounce/css/styles.css'],
            'registration-check': ['handlebars', 'moment', ext + 'registration-check/registration-check.js?ver=201008', ext + 'registration-check/registration-check.css'],
			'priority-registration': ['handlebars', 'moment', ext + 'registration-check/reg-promise.js?ver=201008', ext + 'registration-check/css/styles.css'],
            'advisor-info': ['handlebars', ext + 'advisor-info/index.js'],
            'bi-dashboard': ['handlebars', ext + 'bi-dashboard/bi-dashboard.js'],
            directory: ['handlebars', ext + 'directory/directory.js', ext + 'directory/directory.css'],
            directoryDepartments: ['handlebars', ext + 'directory/directory-department.js'],
            'vpn-access': ['handlebars', ext + 'vpn-access/index.js'],
            pob: ['handlebars', ext + 'pob/index.js', ext + 'pob/styles.css'],
            bookmatch: ['handlebars', ext + 'bookmatch/index.js', ext + 'bookmatch/css/styles.css'],
            bookmarking: [ext + 'mypage/mypage.js'],
            dfnp: ['moment', 'handlebars', ext + 'dfnp/index.js', ext + 'dfnp/css/dfnp.css'],
            'finals-schedule': ['handlebars', ext + 'finals-schedule/index.js?ver=201008', ext+ 'finals-schedule/css/styles.css'],
            'faculty-courses': ['handlebars', ext + 'faculty-courses/index.js'],
            'profile-check': [ext + 'directory/profile-check.js'],
			highcharts: [ext + 'highcharts/highcharts.js', ext + 'highcharts/uvuhighcharts.js'],
			tasks: ['handlebars', 'moment','bootstrap', 'bootbox', ext + 'tasks/index.js?ver=210410', ext + 'tasks/css/styles.css?v=210813'],
			'completion-information': ['handlebars', ext + 'completion-information/index.js?ver=210927', ext + 'completion-information/css/styles.css'],
			'financial-status': ['handlebars','bootstrap', 'bootbox', ext+'financial-status/index.js?v=210412', ext+'financial-status/css/styles.css?v=210412'],
			'financial-aid-awards': ['handlebars', ext+'financial-aid-awards/index.js?ver=201008', ext+'financial-aid-awards/css/styles.css'],
			'assessment-test-scores': ['bootstrap', 'bootbox', ext+'assessment-test-scores/index.js?ver=201008'],
			'placement-status': [ext+'placement-status/index.js?ver=201015', ext+'placement-status/css/styles.css'],
			'dashboard-user-controls': ['handlebars', 'bootstrap', 'bootbox', ext + 'dashboard-user-controls/index.js?ver=210818', ext+ 'dashboard-user-controls/css/styles.css'],
			adobe: ext + 'adobesign/js/adobe_sign.js?v=21022502'
        };

	/**
     * myuvu.import - loadjs wrapper that simplifies dependency importing with presets and auto-page checking
     * @param {string/array} ids Name(s) of plugin(s) to load
     * The following additional params may be overloaded
     * @param {string/object} Selector/Element to check if exists on page 
     * @param {boolean} Load asyncronously
     * @param {function} callback. First param of callback function contains elements (based on selector) that have not been run yet
     */
    myuvu.import = (function (preset) {
        'use strict';

        function Import(ids) {
            var deps = typeof ids === 'string' ? ids.split(',') : typeof ids === 'object' ? ids : false,
                el = false,
                async = false,
                callback = false,
                urls = false,
                arg, $el, i;

            // check for overloaded params
            for (i = 1; i < arguments.length; i++) {
                arg = arguments[i];
                if (typeof arg === 'string' || typeof arg === 'object') {
                    el = arg;
                } else if (typeof arg === 'boolean') {
                    async = arg;
                } else if (typeof arg === 'function') {
                    callback = arg;
                }
            }
            $el = $(el).not('[data-import="false"]');

            // check if we should load the script
            if ((!el || $el.length) && deps) {
                urls = check(deps, preset); // check against presets and previously loaded

                if (urls && urls.length !== 0) {
                    loadjs(urls, {
                        async: async,
                        success: function (a) {
                            // set as already imported
                            for (i = 0; i < urls.length; i++) {
                                if (Import.done.indexOf(urls[i]) === -1) Import.done.push(urls[i]);
                            }
                            // run callback after filtering out previous elements imported
                            if (typeof callback === 'function') {
                                $el.attr('data-import', false); // tag elements to not run again
                                callback($el);
                            }
                        },
                        error: function (d) {
                            console.log('failed to load:', d);
                        }
                    });
                } else {
                    if (typeof callback === 'function') {
                        $el.attr('data-import', false); // tag elements to not run again
                        callback($el);
                    }
                }
            }
        }

        function check(dep, preset, checkedIn) {
            var checked = typeof checkedIn === 'object' ? checkedIn : Import.done.slice(),
                ret = [],
                i;

            // check string
            if (typeof dep === 'string') {
                if (checked.indexOf(dep) === -1) { // stop duplicates/infinite loop
                    checked.push(dep);
                    // check against preset
                    if (typeof preset[dep] !== 'undefined') {
                        dep = typeof preset[dep] === 'string' ? preset[dep].split(' ') : preset[dep];
                        for (i = 0; i < dep.length; i++) {
                            ret = ret.concat(check(dep[i], preset, checked));
                        }
                    } else {
                        ret.push(dep);
                    }
                }
            }
            // check array
            else {
                for (i = 0; i < dep.length; i++) {
                    ret = ret.concat(check(dep[i], preset, checked));
                }
            }

            return ret;
        }

        Import.done = [];

        return Import;
    })(preset);

    uvu.import = myuvu.import;

})();