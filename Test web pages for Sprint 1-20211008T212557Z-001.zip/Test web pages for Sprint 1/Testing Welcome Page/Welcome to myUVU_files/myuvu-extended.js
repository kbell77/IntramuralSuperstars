/* optional/additional myUVU objects */

$(function () {
	'use strict';

	/* continue as */
	if ($('.sign-in').length) {
		$('.sign-in').text('Continue as ' + myuvu.user.name);
		$('.sign-out-dialog').removeClass('hidden');
		$('.auth-username').html(myuvu.user.name);
	}

	myuvu.import('dashboard-user-controls', '.studentLookup', function ($this) {
		$this.dashboardUserControls();
	});
	/* injector */
	myuvu.import('injector', '.injector', function () {
		$('.injector').injector();
	});
	/* page controls */
	myuvu.import('bookmarking', '#myuvu-main-content', function ($this) {
		$this.mypage({
			altid: 'data-fname',
			bookmark: {
				html: '<div class="controls"><span class="myuvu-bookmark far fa-bookmark" title="add or remove from bookmarks"></span><span class="far fa-expand expand" title="maximize"></span></div>',
				class: 'portlet'
			}
		});
	});

	if ('deptnav' in myuvu) {
		myuvu.import('dept-nav', '.myuvu-nav-list', function ($this) {
			$this.deptNav();
		});
	}

	myuvu.import('portlet-expand', '.portlet', function () {
		$('.portlet').portletExpand();
	});
	/* Provision Check for cloud storage */
	myuvu.import('cloud-tools', '.cloud-tools', function () {
		$('.cloud-tools-out').cloudTools();
	});
	/* POB Data */
	myuvu.import('pob', '.pob', function () {
		$('.pob .output').pob();
	});
	myuvu.import('check-access', '.check-access', function($this){
		var listen = {
			form: "#lookup-form",
			uvid:"#uvid-update",
			termcode:"#term-update",
			src:"#data-from"
		}
		$this.checkAccess({
			listen: listen
		});
	})
	myuvu.import('tasks', '.enrollment-app', function ($this) {
		var listen = {
			form: "#lookup-form",
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.tasks({
			listen: listen
		});
	});

	myuvu.import('assessment-test-scores', '.assessmentTestScores', function ($this) {
		var listen = {
			form: "#lookup-form",
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.assessmentTestScores({
			listen: listen
		});
	});

	myuvu.import('financial-status', '.financial-status', function ($this) {
		var listen = {
			form: "#lookup-form",
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.financialStatus({
			listen: listen
		});
	});

	myuvu.import('placement-status', '.placement-status', function ($this) {
		var listen = {
			form: "#lookup-form",
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.placementStatus({
			listen: listen
		});
	});

	myuvu.import('financial-aid-awards', '.financial-aid-awards', function ($this) {
		var listen = {
			form: "#lookup-form",
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.financialAidAwards({
			listen: listen
		});
	});

	myuvu.import('completion-information', '.completion-information', function ($this) {
		var listen = {
			form: "#lookup-form",
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.completionInformation({
			listen: listen
		});
	});

	myuvu.import('finals-schedule', '.finals-container', function ($this) {
		var listen = {
			form: "#lookup-form",
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.finals({
			listen: listen
		});
	});

	myuvu.import('my-courses', '.enrollment-app', function ($this) {
		var listen = {
			form: '#lookup-form',
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.myCourses({
			listen: listen
		});
	});

	myuvu.import('course-calendar', '.course-calendar', function($this){
		var listen = {
				form: '#lookup-form',
				uvid:"#uvid-update",
				termcode:"#term-update",
				src:"#data-from"
			};
		$this.myCourseCalendar({
			listen:listen
		});
	});
	
	myuvu.import('course-calendar', '.course-calendar', function ($this) {
		var listen = {
			form: '#lookup-form',
			uvid: "#uvid-update",
			termcode: "#term-update",
			src: "#data-from"
		};
		$this.myCourseCalendar({
			listen: listen
		});
	});

	myuvu.import('registration-check', '.registration-check', function () {
		$('.registration-check .output').registrationCheck();
	});

	myuvu.import('advisor-info', '.advisor-info', function () {
		$('.advisor-info .output').advisorInfo();
	});

	myuvu.import('webowners', '.webowners', function () {
		$('.webowners .output').webowners();
	});

	myuvu.import('email-preview', '.email-container', function () {
		$('.email-container').mailPreview();
	});

	myuvu.import('dfnp', '.dfnp-container', function ($this) {
		$this.dfnp();
	});

	myuvu.import('bi-dashboard', '.biData', function ($this) {
		$this.find('.output').biData();
	});

	myuvu.import('bookmatch', '.bookmatch', function ($this) {
		$this.find('.output').bookmatch();
	});

	/*---------- Imitation Lazy Load ----------*/
	myuvu.import('imitationLazyloader', '.imLazy', function () {
		$('.imLazy').each(function () {
			$(this).attr('data-scroll-class', 'imLazy-animate' + ' ' + $(this).attr('data-scroll-class'));
			$(this).scrollClass({
				offsetTop: 60
			});
		});
	});
	/*---------- End Imitation Lazy Load ----------*/

	// Slider
	uvu.import('slider', '.slider', function () {

		$('[data-slider-pair]').each(function () {
			if ($(this).attr('data-slider-nav') == 'true') {
				if ($(this).attr('data-slider-navtype') == 'gallery') {
					var numOfSlides = $(this).find('li').length;
					$(this).find('ul').slick({
						infinite: true,
						slidesToShow: numOfSlides,
						slidesToScroll: numOfSlides,
						variableWidth: true,
						dots: false,
						arrows: false,
						centerMode: false,
						focusOnSelect: true,
						asNavFor: $(this).attr('data-slider-pair') + " ul",
						responsive: [{
							breakpoint: 480,
							settings: {
								variableWidth: false,
								infinite: true,
								slidesToShow: 3,
								slidesToScroll: 1,
								dots: false,
								arrows: false,
								centerMode: true,
								centerPadding: '5px',
								focusOnSelect: true,
							}
						}]
					});
				} else {
					$(this).find('ul').slick({
						infinite: true,
						slidesToShow: 5,
						slidesToScroll: 1,
						dots: false,
						arrows: true,
						centerMode: true,
						focusOnSelect: true,
						asNavFor: $(this).attr('data-slider-pair') + " ul",
						responsive: [{
							breakpoint: 768,
							settings: {
								slidesToShow: 3,
								arrows: false
							}
						},
						{
							breakpoint: 480,
							settings: {
								slidesToShow: 3,
								arrows: false
							}
						}
						]
					});
				}
			} else {
				$(this).find('ul').slick({
					infinite: true,
					slidesToShow: 1,
					slidesToScroll: 1,
					autoplay: true,
					autoplaySpeed: 6000,
					dots: false,
					arrows: false,
					fade: true,
					asNavFor: $(this).attr('data-slider-pair') + " ul"
				});
			}
		});

		$('.slider:not([data-slider-pair]) ul').slick({
			infinite: true,
			autoplay: true,
			autoplaySpeed: 6000,
			dots: true,
			arrows: true,
			adaptiveHeight: true,
			centerMode: false,
			slidesToShow: 1
		});
	});

	/* uvannounce */
	myuvu.import('uvannounce', '.uvannounce', function () {
		var tags = {
			home: {
				campus: 'cat',
				general: 'cat',
				academics: 'cat',
				arts: 'cat',
				conferences: 'cat',
				sports: 'cat',
				hr: 'cat',
				'other': 'cat',
				student: 'filter',
				employee: 'filter',
				faculty: 'filter'
			},
			students: {
				general: 'cat',
				academics: 'cat',
				student: ['filter', false],
				employee: 'filter',
				faculty: 'filter'
			},
			employees: {
				campus: 'cat',
				general: 'cat',
				academics: 'cat',
				arts: 'cat',
				conferences: 'cat',
				sports: 'cat',
				hr: 'cat',
				'other': 'cat'
			},
			campus_life: {
				campus: 'cat',
				arts: 'cat',
				student: ['filter', false],
				employee: 'filter',
				faculty: 'filter'
			},
			faculty: {
				general: 'cat',
				campus: 'cat',
				arts: 'cat',
				faculty: 'cat',
				employee: 'filter',
				student: 'filter'
			},
			former_students: {
				general: 'cat',
				academics: 'cat',
				student: ['filter', false],
				employee: 'filter',
				faculty: 'filter'
			}
		},
			tag = false,
			filter = false,
			preset = $('.uvannounce').attr('data-uva-set');


		if (typeof tags[preset] != 'undefined') tag = tags[preset];
		$('.uvannounce').uvannounce({
			tags: tag
		});
	});
	myuvu.import('uvannounce-2', '.uvannounce-2', function () {
		var tags = {
			home: {
				campus: 'cat',
				general: 'cat',
				academics: 'cat',
				arts: 'cat',
				conferences: 'cat',
				sports: 'cat',
				hr: 'cat',
				'other': 'cat',
				student: 'filter',
				employee: 'filter',
				faculty: 'filter'
			},
			students: {
				general: 'cat',
				academics: 'cat',
				student: ['filter', false],
				employee: 'filter',
				faculty: 'filter'
			},
			employees: {
				campus: 'cat',
				general: 'cat',
				academics: 'cat',
				arts: 'cat',
				conferences: 'cat',
				sports: 'cat',
				hr: 'cat',
				'other': 'cat'
			},
			campus_life: {
				campus: 'cat',
				arts: 'cat',
				student: ['filter', false],
				employee: 'filter',
				faculty: 'filter'
			},
			faculty: {
				general: 'cat',
				campus: 'cat',
				arts: 'cat',
				faculty: 'cat',
				employee: 'filter',
				student: 'filter'
			},
			former_students: {
				general: 'cat',
				academics: 'cat',
				student: ['filter', false],
				employee: 'filter',
				faculty: 'filter'
			}
		},
			tag = false,
			filter = false,
			preset = $('.uvannounce-2').attr('data-uva-set');


		if (typeof tags[preset] != 'undefined') tag = tags[preset];
		$('.uvannounce-2').uvannounce({
			tags: tag
		});
	});

	/* Events */
	myuvu.import('events-cal', '.events-cal', function () {
		$('.events-output').events();
	});

	/* AdobeSign API */
	myuvu.import('adobe', 'form[data-adobesign-ldid]', function () {
		$('form[data-adobesign-ldid]').adobesign();
	});

	/* Directory */
	myuvu.import('directory', '.directory', function () {
		$('.output').each(function () {
			$(this).directory();
		});
	});

	/* VPN */
	myuvu.import('vpn-access', '.vpn-access', function () {
		$('.output').vpncheck();
	});

	/* Events List */
	myuvu.import('event-list', '.eventList', function () {
		$('.eventList-output').eventList();
	});

	/* Digital signage */
	myuvu.import('digital-signage', '.digital-signage-slider', function () {
		$('.digital-signage-slider').digitalSignage();
	});

	/* Service Desk Live Chat */
	if ($('.livechat').length) {
		$.getScript('//support.uvu.edu/api/clicktochat.js');
	}

	/* Software download */
	myuvu.import('software', '.software', function () {
		$('.software').software();
	});

	/* iFrame resize*/
	myuvu.import('iframeresizer', 'iframe.iframeResizer', function () {
		var ie = navigator.userAgent.indexOf('MSIE') !== -1 ? true : false,
			ff = navigator.userAgent.toLowerCase().indexOf('firefox') !== -1 ? true : false,
			refresh = false,
			t;

		$('iframe.iframeResizer').iFrameResize({
			checkOrigin: false,
			heightCalculationMethod: ie ? 'max' : ff ? 'bodyOffset' : 'bodyOffset',
			scrolling: true,
			resizedCallback: function (d) {
				refresh = true;
			}
		});

		// reset session timeout if page changed
		t = setInterval(function () {
			if (refresh) {
				refresh = false;
				myuvu.SessionTimeout.start();
			}
		}, 5000);
	});

	/* detatched view */
	myuvu.import('detached', '.detached', function () {
		$('.detached .detached').detached();
	});

	/* web proxy */
	myuvu.import('webproxy', '.webproxy', function () {
		$('.webproxy').webproxy();
	});


	/* Countdown clock */
	myuvu.import('countdown', '.countdown', function ($this) {
		$this.countdown({}, function () {
			if ($('.countdown-copy').length) {
				$('.countdown-copy').html(!$this.find($('.countdown .countdown-title').attr('href')) ? '<a href="#">' + $('.countdown .countdown-title').html() + '</a>' : $('.countdown .countdown-title').html());
			}
		});
	});

	/* Accordion */
	myuvu.import('myuvuaccordion', '.myuvuaccordion', function () {
		$('.myuvuaccordion').myuvuaccordion();
	});
	myuvu.import('accordion', '.accordion', function () {
		$('.accordion').accordion();
	});

	/* app-link-list show/hide */
	if ($('.app-link-list').length) {
		accordion('.app-link-list > h2');
	}
	if ($('.accordion').length) {
		accordion('.accordion > h3');
	}
	if ($('.myuvu-accordion').length) {
		accordion('.myuvu-accordion > h3');
	}

	if ($('.feed').length) {
		$('.feed').on('click.feedToggle', '.feedTitle', function () {
			var $el = $(this).parent('.feedItem');
			if ($el.hasClass('open')) {
				$el.find('.feedDesc').slideUp();
				$el.removeClass('open');
			} else {
				$el.find('.feedDesc').slideDown();
				$el.addClass('open');
			}

		});
	}
	// ou-edit
	myuvu.import('editpage', '#ob');

	/* ou-edit */
	function editPage() {
		var keys = { 18: false, 16: false, 88: false },
			trigger = false;

		$(document).on('keydown.ou-edit', function (e) {
			var k;
			if (e.keyCode in keys) {
				keys[e.keyCode] = true;
				trigger = true;
				for (k in keys) {
					if (!keys[k]) {
						trigger = false;
					}
				}
				if (trigger) {
					$('.ou-edit').addClass('show');
					$(document).one('click.ou-edit', function (e) {
						$('.ou-edit').removeClass('show');
					});
				}
			}
		}).on('keyup.ou-edit', function (e) {
			if (e.keyCode in keys) {
				keys[e.keyCode] = false;
			}
		});
	}

	/* generic json view */
	myuvu.import('json-view', '.json-view', function () {
		$('.json-view').jsonView();
	});

	$('.livechat').on("click.livechat", function () {
		BG.setSite("https://support.uvu.edu");
		BG.startChatWithIssueId('3', true);
	});

	/*
	Helper Functions
	*/

	/* simple accordion */
	function accordion(elIn) {
		var el = elIn ? elIn : '.accordion';
		$(el).next().hide();
		$(el).on('click.accordion', function () {
			var $n = $(this).next();
			if ($n.hasClass('open')) {
				$(this).removeClass('open');
				$n.slideUp().removeClass('open');
			} else {
				$(this).addClass('open');
				$n.slideDown().addClass('open');
			}
		});
	}
});
// get templates from either html or string
function getTemplates(opts) {
	var t = opts.template,
		i;

	for (i in t) {
		if (t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0) t[i] = $(t[i]).html(); // test if template or selector
		opts.Handlebars.registerPartial(i, t[i]); // all templates are also a partial
		t[i] = opts.Handlebars.compile(t[i]); // make template
	}
	opts.Handlebars.registerHelper(opts.helper);
}
// getting all html5 data- attributes with matching prefix
function getDataDash(pre, opts) {
	var dd = opts.$this[0].attributes,
		ow = {},
		val, sel, i, n,
		nest = function (sel, val) { // make nested array
			var s = sel.shift(),
				v = sel.length ? nest(sel, val) : val,
				r = {};
			r[typeof s !== 'undefined' ? s : sel] = v;
			return r;
		};
	for (i = 0; i < dd.length; i++) {
		if (dd[i].name.indexOf('data-' + pre + '-') !== -1) $.extend(true, ow, nest(dd[i].name.replace('data-' + pre + '-', '').split('-'), dd[i].value));
	}

	return ow;
}
async function setSessData() {
	try {
		const data = {
			'time': new Date().getTime(),
			'getting': true
		};
		return data;
	} catch (e) {
		console.log("Error", e);
	}
}

async function fetchSetData(url) {
	try {
		const getData = await fetch(url).then((res) => res.json());
		const data = {
			'time': new Date().getTime(),
			'content': getData,
			'getting': false
		};
		return data;
	} catch (e) {
		console.log("Error", e);
	}
}

async function saveData(sessVar, data) {
	try {
		myuvu.session.set(sessVar, data);
		return data;
	} catch (e) {
		console.error('Error', e);
	}
}

async function getData(opts, sessVar, url) {
	try {
		if (myuvu.session.get(sessVar) !== 'undefined' && myuvu.session.get(sessVar) !== null) {
			const cache = myuvu.session.get(sessVar);
			if(cache !== 'undefined' && cache !== undefined){
				const dt = Math.ceil((Date.now() - (cache.time + (opts.cacheTime * 1000)))/1000);
				if(opts.flush == false && dt < opts.cacheTime){
					return cache;
				}else{
					myuvu.session.set(sessVar, await setSessData());
					myuvu.session.set(sessVar, await fetchSetData(url));
					return myuvu.session.get(sessVar);
				}
			}else{
				myuvu.session.set(sessVar, await setSessData());
				myuvu.session.set(sessVar, await fetchSetData(url));
				return myuvu.session.get(sessVar);
			}
		} else {
			myuvu.session.set(sessVar, await setSessData());
			myuvu.session.set(sessVar, await fetchSetData(url));
			return myuvu.session.get(sessVar);
		}
	} catch (e) {
		console.log('Error', e);
	}
}

async function getUser(opts) {
	try {
		const timeout = 100;
		if (myuvu.session.get('enrollment-dashboard') !== 'undefined' && myuvu.session.get('enrollment-dashboard') !== null) {
			const cache = myuvu.session.get('enrollment-dashboard');
			if (cache.getting == true) {
				setTimeout(() => {
					return getUser(opts);
				}, timeout);
			} else {
				return cache;
			}
		} else {
			setTimeout(() => {
				return getUser(opts);
			}, timeout);
		}
	} catch (e) {
		console.log('Error', e);
	}
}