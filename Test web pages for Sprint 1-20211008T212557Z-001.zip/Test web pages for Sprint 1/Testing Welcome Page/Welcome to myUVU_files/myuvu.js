/* Initialize and autowire up myuvu core */

// public myuvu var
if (typeof myuvu != 'object') var myuvu = {};
myuvu.protocol = 'https';
myuvu.server = `${myuvu.protocol}://my.uvu.edu`;
myuvu.root = '/';
myuvu.resources = '_resources/';
myuvu.common = '_common/';
myuvu.portal = `${myuvu.protocol}://my.uvu.edu`;
myuvu.getuser = 'user/lib/php/user.php';
myuvu.mquery = 'mobile';

(function () {
	'use strict';

	var root = myuvu.server + myuvu.root,
		jsUrl = root + myuvu.common + 'js/',
		extUrl = root + myuvu.common + 'ext/';

	// check for jquery and startup
	if (typeof jQuery != 'undefined') {
		myuvuCheck();
	} else {
		getScript(jsUrl + 'jquery-3.4.1.min.js', function () {
			myuvuCheck();
		});
	}
	if ('breadcrumb' in myuvu) {
		let breadcrumb = ``;

		for (let i = 0; i < myuvu.breadcrumb.length; i++) {
			breadcrumb += `<li><a class="${myuvu.breadcrumb[i].path == window.location.pathname.replace(/(index.(php|html))/, '').slice(0, -1) ? 'currentpage' : 'parentsite'}" href="${myuvu.breadcrumb[i].path}">${myuvu.breadcrumb[i].title}</a></li>`;
		}
		$("#myuvu-main-content.page .page-content").prepend(`<nav class="breadcrumbNav" id="breadcrumbNav" aria-label="breadcrumb" tabindex="0"><ul>${breadcrumb}</ul></nav>`);
		$("#breadcrumbNav .currentpage").removeAttr('href').click(e => {
			e.preventDefault();
		});
	}
	/* myuvu core functions */

	// myuvu core startup
	function myuvuCore() {
		// myuvu sessionStorage
		myuvu.session = new htmlStorage('session', 'myuvu');

		// myuvu localStorage
		myuvu.local = new htmlStorage('local', 'myuvu');

		// myuvu pub/sub
		myuvu.ps = new pubSub(myuvu.local);

		/* session */
		getScript(jsUrl + 'session-timeout.js', function () {
			if('user' in myuvu){
				if (myuvu.user.groups.indexOf('employees') !== -1) myuvu.SessionTimeout.timeout *= 2; // double session timeout for employees
					myuvu.SessionTimeout.start();
			}
			
		});

		// media query var
		if ($('#mquery').length) media_check();

		
		/* nav interaction */
		if ($('.myuvu-classy').length) {
			getScript(jsUrl + 'classy.js', function () {
				$('.myuvu-classy').classy({ on: 'myuvu-active', off: 'myuvu-inactive' });
			});
		}
		/* Settings Plugin */
		if ($('#myuvu-header').length){
			getScript(jsUrl + 'settings.js?v=210227', function() {
				$('body').myuvuSettings();
			});
		}
		/* notifications */
		if (typeof Noty === 'undefined') {
			getScript(jsUrl + 'noty.min.js', function () {
				// alert
				getScript(jsUrl + 'alert.js');
				getStyles([jsUrl + '/css/alert.css']);
			});
			getStyles([myuvu.server + myuvu.root + myuvu.common + 'js/css/noty.css']);
		}

		/* search */
		if ($('.myuvu-search').length) {
			getScript(extUrl + 'dataapi/js/dataview.js', function () {
				$('.myuvu-search-input').dataview({
					api: '/user/lib/php/myapi.php',
					out: '.myuvu-search-suggest',
					active: 'myuvu-active',
					onload: false,
					qstring: false,
					searchin: 'title,tags,id,page,description,link',
					preset: 'myuvu-search',
					presets: {
						'myuvu-search': {
							template: {
								main: `{{#if items}}
								{{#each items}}
								<li><a href="{{#if link}}{{link}}{{else}}{{page}}{{#if id}}#{{id}}{{/if}}{{/if}}" title="{{#if link}}{{link}}{{else}}https:{{page}}{{#if id}}#{{id}}{{/if}}{{/if}}"><span class="quick-search-title">{{title}}</span>{{#if description}}<span class="quick-search-description">{{description}}</span>{{/if}}<span class="quick-search-url">{{#if link}}{{link}}{{else}}https:{{page}}{{#if id}}#{{id}}{{/if}}{{/if}}</span></a></li>{{/each}}{{/if}}`
							}
						}
					}
				});
			});
		}

		/* bookmarks */
		if ($('.myuvu-bookmarks').length) {

			// new bookmarks
			getScript(extUrl + 'mypage/mypage.js', function () {
				$('.myuvu-bookmarks').mypage({
					out: '.myuvu-list-group'
				});
			});

			// old bookmarks
			/*
			getScript(jsUrl+'bookmarks.js?v=1', function(){
				$('.myuvu-bookmarks').myuvuBookmarks();
			});
			*/
		}

		/* Additional code */
		if (!$('.OUEditor').length) {
			// make element clickable
			$('.clickable').addClass('pointer').on('mouseup.clickablediv', function (e) {
				var link = $(this).find('a');

				if (e.target == link[0] || !(e.which == 1 || e.which == 2)) {
					return;
				}

				e.preventDefault();
				if (link.hasClass('anchorToggle') || link.hasClass('anchorTab')) {
					link.click();
				} else if (e.which == 2 || link.attr('target') == '_blank') {
					window.open(link.attr('href'), '_blank');
				} else {
					window.location.href = link.attr('href');
				}
			});
		}

		if ($('#departments').length) {
			getScript(extUrl + '/directory/directory-department.js', function () {
				$('#departments').directoryDepartments();
			});
		}

		/* myuvu extended */
		if ($('#myuvu-main-content').length) getScript(jsUrl + 'myuvu-extended.js?ver=2.210913');
		if ($('#statusCheck').length) getScript(jsUrl + 'status.js?v=191120', function () {
			$('#statusCheck').status();
		});
	}

	// myuvu core check
	function myuvuCheck() {
		try {
			$(function () { // document ready
				if ($('#myuvu-header .myuvu-logo').length) {
					if (typeof myuvu.user == 'undefined') {
						myuvuGetUser(false);
					} else {
						myuvuCore();
					}
				} else {
					myuvuGetHeader();
				}
			});
		} catch (err) {
			console.log(err);
		}
	}

	// myuvu get header
	function myuvuGetHeader() {
		// load base styles
		getStyles([
			'//fonts.googleapis.com/css?family=Oxygen|Rajdhani',
			myuvu.server + myuvu.root + myuvu.common + 'css/myuvu-wrapper.css?v=2'
		]);
		try {
			myuvuGetUser(true);
		} catch (err) {
			console.log(err);
		}
	}

	// myuvu get user
	function myuvuGetUser(html) {
		// get user and wrapper
		$.ajax({
			url: myuvu.server + myuvu.root + myuvu.getuser,
			data: {
				html: html,
				path: window.location.pathname
			},
			dataType: 'jsonp'
		}).done(function (d) {
			if (html) {
				// create wrapper
				$('body').prepend($('<div/>').html(d.html).text());
			} else {
				myuvu.user = d;
			}
			// startup
			myuvuCore();
		}).fail(function (a, b, c) {
			console.log(b);
			console.log(a.statusCode);
			console.log(c);
			myuvuCore();
		});
	}

	/* SIMPLE HELPER FUNCTIONS */

	// native get script with callback
	function getScript(source, callback) {
		var script = document.createElement('script');

		script.async = 1;
		document.getElementsByTagName('head')[0].appendChild(script);

		script.onload = script.onreadystatechange = function (_, isAbort) {
			if (isAbort || !script.readyState || /loaded|complete/.test(script.readyState)) {
				script.onload = script.onreadystatechange = null;
				script = undefined;

				if (!isAbort) { if (callback) callback(); }
			}
		};

		script.src = source;
	}

	// get styles
	function getStyles(styles) {
		var i, style;
		for (i = 0; i < styles.length; i++) {
			style = document.createElement('link');
			style.type = 'text/css';
			style.rel = 'stylesheet';
			style.href = styles[i];
			document.getElementsByTagName('head')[0].appendChild(style);
		}
	}

	// html5 storage shim - simplifies storage and handles safari bugs, etc...
	function htmlStorage(sessLoc, inpre) {
		var type = typeof sessLoc !== 'undefined' ? sessLoc : 'session',
			pre = typeof inpre !== 'undefined' ? inpre : '',
			Store = function () { },
			storage = (function () { // test and return html5 storage
				var t = new Date(), sto, r;
				try {
					sto = type === 'local' ? localStorage : sessionStorage;
					sto.setItem(t, t);
					r = sto.getItem(t) == t;
					sto.removeItem(t);
					return r ? sto : false;
				} catch (e) {
					console.log(type + ' storage not supported');
					return false;
				}
			})();

		// get prefix
		Store.prototype.getPre = function () {
			return pre;
		};

		// setItem - generic
		Store.prototype.setItem = function (i, val) {
			var p = typeof arguments[2] !== 'undefined' ? arguments[2] : '';
			this[i] = val; // local var as fallback
			if (storage) storage.setItem(p + i, val); // html5 if supported
		};
		// set item with auto prefixing stringify
		Store.prototype.set = function (i, val) {
			this.setItem(i, JSON.stringify(val), pre); // prefix and stringify
		};
		// getItem - generic
		Store.prototype.getItem = function (i) {
			var p = typeof arguments[1] !== 'undefined' ? arguments[1] : '';
			// html5
			if (storage) {
				try {
					return p === '' ? storage.getItem(i) : JSON.parse(storage.getItem(p + i));
				} catch (e) {
					console.log('failed to get ' + p + i + ' from ' + type + ' storage');
					return this[i];
				}
			}
			// fallback
			else {
				return this[i];
			}
		};
		// get item with auto prefixing and parsing
		Store.prototype.get = function (i) {
			return this.getItem(i, pre);
		};

		// delete - generic
		Store.prototype.removeItem = function (i) {
			var p = typeof arguments[1] !== 'undefined' ? arguments[1] : '';
			delete this[i]; // local
			if (storage) storage.removeItem(p + i); // html5
		};
		// delete item with auto prefixing
		Store.prototype.del = Store.prototype.rem = function (i) {
			this.removeItem(i, pre);
		};

		// generate new storage
		return new Store();
	}

	// basic myuvu pubsub with cross tab broadcasting (same domain)
	function pubSub(locSto) {
		var ls = typeof locSto === 'object' ? locSto : false,
			syncKey = 'myuvuPubSubSync',
			PubSub = {
				ps: $({}), // use jquery's event system for pub/sub
				// subscribe
				sub: function () {
					PubSub.ps.on.apply(PubSub.ps, arguments);
				},
				// unsubscribe
				unsub: function () {
					PubSub.ps.off.apply(PubSub.ps, arguments);
				},
				// publish
				pub: function () {
					PubSub.ps.trigger.apply(PubSub.ps, arguments);
					if (ls) {
						ls.setItem(syncKey, JSON.stringify(arguments));
					}
					console.log('pub from local');
				},
				sync: ''
			},
			// cross tab localStorage listener
			listen = function (e) {
				var val, args;
				// check our synckey changed
				if (e.key === syncKey && e.newValue && e.newValue !== PubSub.sync) {
					PubSub.sync = e.newValue;
					args = JSON.parse(e.newValue);
					val = args[0];
					args = args[1];

					PubSub.pub(val, args);
					console.log('pub from sync');
				}
			};

		// local storage sync listender
		if (ls) {
			window.addEventListener('storage', listen);
		}

		return PubSub;
	}

	/* current media query - mobile, tablet, laptop, desktop */
	function media_check() {
		function mc() {
			var media_test = $('#mquery').width(),
				ret = media_test == 1 ? 'mobile' : media_test == 2 ? 'tablet' : media_test == 3 ? 'laptop' : media_test == 4 ? 'desktop' : false;
			return ret;
		}
		var l_mquery = mc();
		/* on window resize */
		$(window).resize(function (e) {
			// get current media query
			myuvu.mquery = mc();

			// if media query has changed
			if (myuvu.mquery != l_mquery) {
				l_mquery = mc();
			}

		});
	}

})();