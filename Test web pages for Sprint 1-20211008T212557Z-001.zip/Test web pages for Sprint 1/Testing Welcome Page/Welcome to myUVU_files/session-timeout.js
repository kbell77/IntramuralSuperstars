/**
* Session timeout
*/

(function($) {
'use strict';

// Session Timeout object
myuvu.SessionTimeout = (function(opts){
	var defs = {
		timeout: 1800000, // 60 * 1000 * 30 min
		sync: 5000,
		warn: 60000,
		notification: '<h2>Session expiration</h2><p>Your session will expire in <span class="myuvu-session-timeout-remaining"></span> seconds.</p><p><strong>Do you want to stay signed in?</strong></p>',
		url: {
			logout: '/user/lib/php/user.php?logout=true'
		},
		timer: false,
		cTimer: false,
		refresh: true
	};

	// notify
	defs.notify = function(){
		if( typeof Noty == 'function' ){
			defs.noty = new Noty({
				text: defs.notification,
				modal: true,
				layout: 'center',
				buttons: [
					Noty.button('Yes', 'myuvu-btn-green', function(){
						defs.reset();
					}, {}),
					Noty.button('No', 'myuvu-btn-red', function(){
						defs.logout();
					}, {})
				]
			}).show();
		}else{
			if( confirm(notification) ){
				defs.reset();
			}else{
				defs.logout();
			}
		}
		defs.update();

		
	};

	// logout
	defs.logout = function(){
		myuvu.local.del('sessionTimeout');
		window.location = defs.url.logout;
	};

	// reset
	defs.reset = function(){
		clearTimeout(defs.cTimer);
		defs.start();
		if( typeof defs.noty != 'undefined' ) defs.noty.close();
	};

	// update countdown
	defs.update = function() {
		var now = new Date().getTime(),
			rem = 0,
			ust = myuvu.local.get('sessionTimeout');

		rem = Math.round((isNaN(parseInt(ust)) ? 0 : parseInt(ust) - now) / 1000);

		// logout
		if( rem <= 0 ) {
			myuvu.local.del('sessionTimeout');
			window.location = defs.url.logout;
			return;
		}else if( rem > (defs.warn) / 1000 ) {
			defs.reset();
			return;
		}
		// show remaining seconds
		$('.noty_layout').find('.myuvu-session-timeout-remaining').text(rem);
		// refresh remaining seconds
		if(defs.cTimer) clearTimeout(defs.cTimer);
		defs.cTimer = setTimeout(function(){
			defs.update(defs);
		}, 1000);
	};

	// start timeout
	defs.start = function(){

		if( defs.timer ) clearTimeout(defs.timer);

		defs.timer = setTimeout(function(){
			// check session timeout
			defs.check();
		}, defs.sync);

		// reset my.uvu timeout
		myuvu.local.set('sessionTimeout', new Date().getTime() + defs.timeout );
		defs.refresh = true;
	};

	// check timeout status
	defs.check = function(){
		var timeout = parseInt( myuvu.local.get('sessionTimeout') );
		if( defs.warn < timeout - new Date().getTime() ){
			clearTimeout(defs.timer);
			defs.timer = setTimeout(function(){
				defs.check();
			}, defs.sync);
		}else{
			defs.notify();
		}
	};

	// user overrides
	$.extend(true, defs, opts);

	defs.defs = defs;

	return defs;

})();

})(jQuery);