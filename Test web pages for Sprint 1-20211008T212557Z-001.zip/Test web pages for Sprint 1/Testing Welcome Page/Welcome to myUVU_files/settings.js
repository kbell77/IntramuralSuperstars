(function($) {

$.fn.myuvuSettings = function(opts) {
    'use strict';
    var $main = this,
        defs = {
            url: `${myuvu.server}/_services/system/settings.php`,
            settings: {
                showProfPic: true,
                feedbackOptIn: false,
                defaultLandingUrl: ""
            },
            func: {}
        };
    // check for passed in options
    $.extend(defs, opts);

    defs.func.getProfilePic = async function(opts){
        const res = await fetch('/_services/system/person.php');
        return res.json();
    };
    /* functions */
    defs.func.showProfPic = async function(opts){
        let pic = '';
        if(myuvu.session.get('profile-pic') !== 'undefined' && myuvu.session.get('profile-pic') !== null){
            pic = myuvu.session.get('profile-pic');
        }else{
            const profData = await opts.func.getProfilePic();
            myuvu.session.set('profile-pic', profData.profileImageUrl);
            pic = myuvu.session.get('profile-pic');
        }
        let url = opts.settings.showProfPic === true ? pic : myuvu.server + myuvu.root +'images/placeholder.png',
            checked = opts.settings.showProfPic === true ? 'checked': '',
            output = '';
            
        $('.myuvu-avatar .profile-image').prop('src', url);
        if($('#profilePicContainer').length){
            output += `<div class="row include-picture-wrapper">
                    <div class="col-xs-7"><label for="showProfPic">Show ID Picture in myUVU</label></div>
                    <div class="col-xs-5 text-right"><span>Off </span> <label class="switch"> <input id="showProfPic" type="checkbox" ${checked} /> <span class="slider round"></span> </label> <span> On</span></div>
                </div>`;
            $('#profilePicContainer').html(output);
            $('#showProfPic').on('change', function(){
                opts.settings.showProfPic = $('#showProfPic').is(':checked') ? true : false;
                api('PUT',opts.settings, opts );
            });
        }
    };
    defs.func.defaultLandingUrl = function(opts){
        const userGroups = myuvu.user.groups;
        const landingUrls = [
            {'audience': 'students', 'label': "Student", 'url': myuvu.server + myuvu.root + 'students/'},
            {'audience': 'former-students', 'label': "Former Student", 'url': myuvu.server + myuvu.root + 'former-students/'},
            {'audience': 'employees', 'label': "Employee", 'url': myuvu.server + myuvu.root +'employees/'},
            {'audience': 'former-employees', 'label': "Former Employees", 'url': myuvu.server + myuvu.root + 'former-employees/'},
            {'audience': 'advisors', 'label': "Advisor", 'url': myuvu.server + myuvu.root +'advisors/'},
            {'audience': 'faculty', 'label': "Faculty", 'url': myuvu.server + myuvu.root +'faculty/'},
            {'audience': 'administrators', 'label': "Administrator", 'url': myuvu.server + myuvu.root +'admin/'}
        ];
        const availablePages = landingUrls.filter(url => userGroups.includes(url.audience));
        let output = '<div><p>Choose your default login page when entering from the myUVU login page.</p>';
        let goTo ='';
        if($('#defaultUrlGroup').length){
            availablePages.forEach(group => {
                let selected = '';
                
                if(opts.settings.defaultLandingUrl == group.url){
                    selected = "checked";
                    goTo = `&nbsp;<a class="btn btn-default"  href="${opts.settings.defaultLandingUrl}">Continue to ${group.label} Page</a>`;
                }else{
                    selected = "";
                }
                output += `<div class="radio">
                            <label>
                                <input type="radio" name="defaultUrlRadio" id="default-${group.audience}" value="${group.url}" ${selected}>
                                ${group.label}
                            </label>
                        </div>`;
                
            });
            output += `<br/><button class="btn btn-primary" href="#" id="submitDefaultUrl">Save</button>${goTo}</div>`;
            if(availablePages.length > 1){
                $("#defaultUrlGroup").html(output);
                $("#submitDefaultUrl").off('click').on('click', function(e){
                    e.preventDefault();
                    const url = $('input[name="defaultUrlRadio"]:checked').val();
                    opts.settings.defaultLandingUrl = url;
                    api('PUT', opts.settings, opts);
                });
            }
            
        }
    };

    // api
    function api(type, p, opts){		
		$.ajax({
			url: opts.url,
			method: type,
			data: p ? JSON.stringify(p) : '',
			contentType: 'application/json', 
			processData: false
		}).done(function(d){
            let data = {};
            if(type == 'GET'){
                data.current = JSON.parse(d.current);
                data.previous = JSON.parse(d.previous);
                if( typeof data.current === 'object' ){
                    output(data.current, opts);
                }else{
                    output({}, opts);
                }
            }
            if(type == 'PUT'){
                data.current = JSON.parse(d);
                new Noty({
                    type: 'success',
                    text: `Your settings have been updated.`,
                    timeout: 5000,
                    closeWith: ['click']
                }).show();
                output(data.current, opts);
            }
		}).fail(function(a,b,c){
			if( a.status === 400 ){
                output(opts.settings, opts);
            }else{
                console.log('error:');
                console.log(a);
                console.log(b);
                console.log(c);
            }
		});
    }

    // output to page
    function output(d, opts){
        var $el,i;

        $.extend(opts.settings, d);
        myuvu.session.set('settings', opts.settings);
        
        for( i in opts.settings ){
            $el = $('#'+i);
            if( $el.is('[type=checkbox]') ){
                $el.prop('checked', opts.settings[i] === true ? true : false );
            }
            if( $el.is('[type=url]')){
                $el.val(opts.settings[i]);
            }
            
            if( typeof opts.func[i] === 'function' ) opts.func[i](opts);
        }
    }

    // init plugin
    return $main.each(function() {
        var opts = $.extend({}, defs),
            $el,sess,i;

        opts.$this = $(this);

        // check cache
        sess = myuvu.session.get('settings');
        if( typeof sess !== 'undefined' && sess !== null ){
            output( sess, opts );
        }else{
            api('GET', false, opts);
        }

    });

};

})(jQuery);