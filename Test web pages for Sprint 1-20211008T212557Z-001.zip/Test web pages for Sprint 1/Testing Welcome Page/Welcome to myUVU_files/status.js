(function ($) {

    $.fn.status = function (opts, callback) {
        'use strict';
        var $main = this,
            defs = {
                pre: 'status',
                url: {
                    base: '/_common/php/status.php',
                    handlebars: '/_common/js/handlebars.min.js'
                },
                template: {
					resting: '<h2>Use myUVU to access all your UVU resources and services in one location!</h2><ul class="services"><li>Canvas</li><li>Wolverine Track</li><li>Student Email (myUVU Gmail)</li><li>Employee Email (OWA)</li><li>Banner Online Services</li><li>TIMS</li><li>Financial Aid</li><li>Class Registration</li><li>And Many More...</li></ul>',
                    outage: '{{#each active.outages}}<div class="status_container outage"><div class="maintenanceDetails"><p>{{{name}}}</p></div></div>{{/each}}',
                    maintenance: '{{#each active.maintenance}}<div class="status_container active_maintenance"><div class="maintenanceDetails"><p>{{{name}}}</p></div></div>{{/each}}',
                    inProgress: '{{#if active}}<h2>Currently in progress</h2>{{>outage}}{{>maintenance}}{{/if}}',
                    upcoming: '{{#if upcoming}}<h2>Scheduled maintenance</h2>{{#each upcoming}}<div class="status_container scheduled_maintenance"><div class="maintenanceDetails"><p>{{{name}}}</p></div></div>{{/each}}{{/if}}',
                    out: '{{>inProgress}}{{>upcoming}}'
                },
                Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false
            };
        // check for user passed in options
        $.extend(true, defs, opts);

        function generateDetails(d, opts) {
            var data = d;
            const reg = /\bMore.../g;
            if (data.active.length == 0 && data.upcoming.length == 0) {
                opts.$this.html(opts.template.resting());
                if (opts.$this.hasClass('hasStatus') === true) {
                    opts.$this.removeClass('hasStatus');
                }
            } else {
                if (data.active.hasOwnProperty('outages') === true) {
                    for (let k = 0; k < data.active.outages.length; k++) {
                        if (data.active.outages[k].name.search(reg) > 0) {
                            let pos = data.active.outages[k].name.search(reg);
                            let substring = data.active.outages[k].name.substring(0, pos);
                            let link = '<a href="' + data.active.outages[k].shortlink + '">More…</a>';
                            data.active.outages[k].name = substring + link;
                        } else {
                            let link = '&nbsp;<a href="' + data.active.outages[k].shortlink + '">More…</a>';
                            data.active.outages[k].name += link;
                        }
                    }
                }
                if (data.active.hasOwnProperty('maintenance') === true) {
                    for (let i = 0; i < data.active.maintenance.length; i++) {
                        if (data.active.maintenance[i].name.search(reg) > 0) {
                            let pos = data.active.maintenance[i].name.search(reg);
                            let substring = data.active.maintenance[i].name.substring(0, pos);
                            let link = '<a href="' + data.active.maintenance[i].shortlink + '">More…</a>';
                            data.active.maintenance[i].name = substring + link;
                        } else {
                            let link = '&nbsp;<a href="' + data.active.maintenance[i].shortlink + '">More…</a>';
                            data.active.maintenance[i].name += link;
                        }
                    }
                }
                for (let j = 0; j < data.upcoming.length; j++) {
                    if (data.upcoming[j].name.search(reg) > 0) {
                        let posU = data.upcoming[j].name.search(reg);
                        let substringU = data.upcoming[j].name.substring(0, posU);
                        let link = '<a href="' + data.upcoming[j].shortlink + '">More…</a>';
                        data.upcoming[j].name = substringU + link;
                    } else {
                        let link = '&nbsp;<a href="' + data.upcoming[j].shortlink + '">More…</a>';
                        data.upcoming[j].name += link;
                    }
                }
                opts.$this.html(opts.template.out(data));
                if (opts.$this.hasClass('hasStatus') === false) {
                    opts.$this.addClass('hasStatus');
                }
            }
        }


        // ajax data get
        function ajax(opts) {

            $.ajax({
                url: opts.url.base,
                dataType: 'json',
            }).done(function (d) {

                generateDetails(d, opts);
                setTimeout(function () {
                    ajax(opts);
                }, 30000);
            }).fail(function (a, b, c) {

                generateDetails(false, opts);
                setTimeout(function () {
                    ajax(opts);
                }, 30000);
                console.log('Status Info failed:' + a);
                console.log('- type: ' + b);
                console.log('- description: ' + c);
            });

        }
        // get templates from either html or string
        function getTemplates(opts) {
            var t = opts.template,
                i;

            for (i in t) {
                if (t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0) t[i] = $(t[i]).html(); // test if template or selector
                defs.Handlebars.registerPartial(i, t[i]); // all templates are also a partial
                t[i] = defs.Handlebars.compile(t[i]); // make template
            }
            defs.Handlebars.registerHelper(opts.helper);
        }

        // getting all html5 data- attributes with matching prefix
        function getDataDash(pre, opts) {
            var dd = opts.$this[0].attributes,
                ow = {},
                val, sel, i, n,
                nest = function (sel, val) { // make nested array
                    var s = sel.shift(),
                        v = sel.length ? nest(sel, val) : val,
                        r = {};
                    r[typeof s !== 'undefined' ? s : sel] = v;
                    return r;
                };

            for (i = 0; i < dd.length; i++) {
                if (dd[i].name.indexOf('data-' + pre + '-') !== -1) $.extend(true, ow, nest(dd[i].name.replace('data-' + pre + '-', '').split('-'), dd[i].value));
            }

            return ow;
        }
        // init plugin
        function init() {
            // return plugin instance
            return $main.each(function () {
                var opts = $.extend({}, defs),
                    ow, i;

                opts.$this = $(this);

                // extend opts from html data-
                $.extend(true, opts, getDataDash(opts.pre, opts));
                // getting templates
                getTemplates(opts);

                ajax(opts);

            });
        }

        // check dependencies and init
        if (defs.Handlebars) {
            init();
        } else {
            $.getScript(defs.url.handlebars, function () {
                defs.Handlebars = Handlebars;
                init();
            });
        }

    };
})(jQuery);
