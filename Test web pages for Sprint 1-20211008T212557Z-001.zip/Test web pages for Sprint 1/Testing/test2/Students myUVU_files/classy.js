/**
 * Classy - jquery plugin
 * adds/removes css classes on multiple targets based on click/hover
 */

(function($) {

$.fn.classy = function(o, callback) {
'use strict';
var $main = this,
	defs = {
		pre: 'classy',	// data-prefix-
		target: false,	// selector
		hover: false,	// true/false - selector
		action: 'toggle',	// on, off, or toggle class 
		on: 'active',	// on class
		off: 'inactive',	// off class
		group:  'all',		// group name or none
		declick: 'body',	// declick element
		stopclick: 'a,button,input',	// prevent default clicks until on
		speed: 500,	// css transition animation speed
		delay: 250,	// delay before hover triggers
		// globals
		fn: {},
		t: false
	};

	defs = $.extend(true, defs, o);


	/**
	 * private functions
	 */

	// getting all html5 data- attributes with matching prefix
	function getDataDash(o){
		var dd = o.$this[0].attributes,
			ow = {},
			val,sel,i,n,
			nest = function(sel, val){ // make nested array
				var s = sel.shift(),
					v = sel.length ? nest(sel, val) : val,
					r = {};
				r[ typeof s !== 'undefined' ? s : sel ] = v;
				return r;
			};
		
		for( i=0; i < dd.length; i++ ){
			if( dd[i].name.indexOf('data-'+o.pre+'-') !== -1 ) $.extend(true, ow, nest( dd[i].name.replace('data-'+o.pre+'-', '').split('-'), dd[i].value ) );
		}

		return ow;
	}

	// set on state
	function on(o, e){
		addClass(o, true);
		o.$both.attr('aria-expanded', 'true');
		o.$others.attr('aria-expanded', 'false');

		// accessibility focus if not already focused
		if( !$(e.target).closest( o.$target ).length ) o.$target.first().focus();
					
		// declick event
		if(o.declick && o.declick !== 'false'){
			$(o.declick).off('click.'+o.pre+o.group);
			$(o.declick).on('click.'+o.pre+o.group, function(e) {
				if( !$(e.target).closest( o.$all ).length ){
					$(o.declick).off('click.'+o.pre+o.group);
					reset(o);
				}
			});
		}
	}

	// transition
	function transitionend(o,$this,func){
		var trs = {
				'transition': 'transitionend',
				'OTransition': 'oTransitionEnd',
				'MozTransition': 'transitionend',
				'WebkitTransition': 'webkitTransitionEnd'
			},
			t = (function(){
				var t;
				for(t in trs){
					if( $this[0].style[t] !== 'undefined'){
						return t;
					}
				}
				return false;
			})();
			
		if( $this.css(t+'Duration').indexOf('0s') === -1 ){
			$this.one(trs[t]+'.'+o.pre, function(){
				func();
			});
		}else{
			func();
		}
	}

	// set off state
	function off(o){
		removeClass(o, true);
		o.$both.attr('aria-expanded', 'false');
		o.$others.attr('aria-expanded', 'false');
		$(o.declick).off('click.'+o.pre);
	}

	// reset to initial state
	function reset(o){
		o.$all.each(function(){
			var $this = $(this),
				st = $this.attr(o.dd+'default') === o.on ? true : false;
			$this.attr('aria-expanded', st).attr(o.dd+'clickstopped', !st).addClass(st ? o.on : o.off).removeClass(st ? o.off : o.on);
		});
	}

	// add class to necessary elements
	function addClass(o, others){
		if( others ) o.$others.removeClass(o.on).addClass(o.off).attr(o.dd+'clickstopped', 'true');
		o.$both.removeClass(o.off).addClass(o.on);
		// wait to change stoppingclick state
		clearTimeout(o.t);
		transitionend(o, o.$target, function(){
			o.$both.attr(o.dd+'clickstopped', 'false');
		});
	}

	// remove class from necessary elements
	function removeClass(o, others){
		if( others ) o.$others.removeClass(o.on).addClass(o.off).attr(o.dd+'clickstopped', 'true');
		o.$both.removeClass(o.on).addClass(o.off).attr(o.dd+'clickstopped', 'true');
	}

	// Prevents or allow default click
	function stopClick(o){
		var ns = o.pre+'stopclick',
			pd = o.preventdefault,
			pvd = function(el, e){
				if( $(el).attr(o.dd+'clickstopped') == 'true' ){
					e.preventDefault();
				}
			};

		o.$both.on('click.'+ns, pd, function(e){ pvd(this, e); });
		if( o.$both.is(pd) ) o.$both.on('click.'+ns, function(e){ pvd(this, e); });
	}

	// Toggle the state
	function toggle(o, el, e){
		o.$all = o.group !== '' && o.group !== 'none' ? $('['+o.dd+'group="'+o.group+'"]') : $();
		o.$others = o.$all.filter(function(){
				if( !$(this).is( o.$both ) && !$(this).find(o.$both).length ) return 1;
			});
		
		if( (o.action === 'on' || o.action === 'toggle') && o.$target.attr('aria-expanded') != 'true' ){
			on(o, e);
		}else if( (o.action === 'off' || o.action === 'toggle') && $(el).is(o.$this) ){
			off(o);
		}
	}

	// Hover in/out
	function hover(o, el, over){
		$(el).attr(o.dd+'over', over);
		if( o.$target.attr('aria-expanded') != 'true' ){
			clearTimeout(o.t);
			o.t = setTimeout(function() {
				if( o.$both.filter('['+o.dd+'over="true"]').length ){
					addClass(o);
				}else{
					removeClass(o);
				}
			}, o.delay);
		}
	}


	// return instance of plugin for each item on page
	return $main.each(function() {
		var o = $.extend(true, {}, defs), // options
			st;

		o.$this = $(this);

		// extend options from html data-
		$.extend( true, o, getDataDash(o) );

		// instance vars
		o.$target = o.target ? $(o.target) : o.$this.attr('aria-controls') ? $('#'+o.$this.attr('aria-controls')) : o.$this;
		o.$both = $(this).add(o.$target);
		o.dd = 'data-'+o.pre+'-';
		o.$both.attr(o.dd+'group', o.group);

		// setup initial state
		st = o.$both.is('.'+o.on);
		o.$both.attr(o.dd+'default', st ? o.on : o.off).attr(o.dd+'clickstopped', !st).addClass(st ? o.on : o.off);
		if( o.action == 'toggle' ) o.$both.attr('aria-expanded', st);
		// accessibility
		o.$this.attr('aria-controls', o.$this.first().attr('aria-controls') || o.$target.first().attr('id') || '' ).attr('role', 'button').attr('tabindex', '0');
		o.$target.attr('tabindex', 0);
		
		// click
		o.$both.off('click.'+o.pre).on('click.'+o.pre, function(e){ toggle(o, this, e); } );
		if( o.stopclick && o.stopclick !== 'false' ) stopClick(o);
		
		// focus (accessibility)
		o.$target.off('focusin.'+o.pre+', focusout.'+o.pre).on('focusin.'+o.pre, function(){ hover(o, this, true); }).on('focusout.'+o.pre, function(){ hover(o, this, false); });
		
		// hover
		if( o.hover && o.hover !== 'false' ){
			o.hover = o.hover === 'true' ? o.target : o.hover;
			o.$both.off('mouseenter.'+o.pre+', mouseleave.'+o.pre).on('mouseenter.'+o.pre, function(){ hover(o, this, true); }).on('mouseleave.'+o.pre, function(){ hover(o, this, false); });
			// accessibility
			o.$this.attr('aria-haspopup', true);
		}
	});

};

})(jQuery);