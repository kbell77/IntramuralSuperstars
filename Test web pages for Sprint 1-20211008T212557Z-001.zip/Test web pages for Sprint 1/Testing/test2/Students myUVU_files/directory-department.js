(function ($) {

    $.fn.directoryDepartments = function (opts, callback) {
        'use strict';
        var $main = this,
            defs = {
                pre: 'directoryDepartments',
                url: {
                    base: 'https://my.uvu.edu/user/lib/php/services/secure-directory.php',
                    handlebars: 'https://my.uvu.edu/_common/js/handlebars.min.js'
                },
                template:{
                    userMenu: '<a href="/department/">Department Information</a>',
                    button:'<div class="dropdown"><button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Departments<span class="caret"></span></button><ul class="dropdown-menu">{{#each this}}<li><a href="/department/manage/?id={{DeptCode}}">{{DeptName}}</a></li>{{/each}}</ul></div>'
                },
                output: 'button'
            };        

        // check for user passed in options
        $.extend(true, defs, opts);
        // getting all html5 data- attributes with matching prefix
        function out(opts){
            var d = myuvu.session.get('directory-departments');
            if (d.length > 0 || myuvu.user.groups.includes('directoryAdmin') || myuvu.user.groups.includes('directoryViewer')){
                if(opts.output == 'button'){
                    opts.$this.html(opts.template.button(d));
                } else{
                    opts.$this.html(opts.template.userMenu());
                } 
            }      
        }
        function getDepartmentInfo(opts, d){
            var groups = d.join(),
                call= 'depsData';
            $.ajax({
                    url: opts.url.base,
                    dataType: "json",
                    data: {
                        call: call,
                        val: groups
                    }
                }).done(function (d) {
                    myuvu.session.set('directory-departments', d);
                    out(opts);
                }).fail(function (a, b, c) {
                    console.log('xhr: ' + a);
                    console.log('status: ' + b);
                    console.log('error: ' + c);
                });
        }
        function get(opts) {
            if (myuvu.session.get('directory-departments') == 'undefined' || myuvu.session.get('directory-departments') === null) {
                // ajax feed from source
                var call = 'checkResp';
                
                $.ajax({
                    url: opts.url.base,
                    dataType: "json",
                    data: {
                        call: call,
                        val: myuvu.user.id
                    }
                }).done(function (d) {
                    var groups = myuvu.user.directoryGroups;
                    groups.concat(d);
                    getDepartmentInfo(opts, groups);
                }).fail(function (a, b, c) {
                    console.log('xhr: ' + a);
                    console.log('status: ' + b);
                    console.log('error: ' + c);
                });
            }else{
                out(opts);
            }
        }

        // get templates from either html or string
        function getTemplates(opts) {
            var t = opts.template,
                i;

            for (i in t) {
                if (t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0) t[i] = $(t[i]).html(); // test if template or selector
                defs.Handlebars.registerPartial(i, t[i]); // all templates are also a partial
                t[i] = defs.Handlebars.compile(t[i]); // make template
            }
            defs.Handlebars.registerHelper(opts.helper);
        }

        // getting all html5 data- attributes with matching prefix
        function getDataDash(pre, opts) {
            var dd = opts.$this[0].attributes,
                ow = {},
                val, sel, i, n,
                nest = function (sel, val) { // make nested array
                    var s = sel.shift(),
                        v = sel.length ? nest(sel, val) : val,
                        r = {};
                    r[typeof s !== 'undefined' ? s : sel] = v;
                    return r;
                };

            for (i = 0; i < dd.length; i++) {
                if (dd[i].name.indexOf('data-' + pre + '-') !== -1) $.extend(true, ow, nest(dd[i].name.replace('data-' + pre + '-', '').split('-'), dd[i].value));
            }

            return ow;
        }

        // init plugin
        function init() {
            // return plugin instance
            return $main.each(function () {
                var opts = $.extend({}, defs),
                    output = $(this).is('[data-' + opts.pre + '-output]') ? $(this).attr('data-' + opts.pre + '-output') : opts.output, // check for preset
                    ow, i;

                opts.output = output;
                opts.$this = $(this);
                
                // extend opts from html data-
                $.extend(true, opts, getDataDash(opts.pre, opts));
                // getting templates
                getTemplates(opts);
                get(opts);

            });
        }

        // check dependencies and init
        if (defs.Handlebars) {
            init();
        } else {
            $.getScript(defs.url.handlebars, function () {
                defs.Handlebars = Handlebars;
                init();
            });
        }
    };
})(jQuery);