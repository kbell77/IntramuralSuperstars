/* jquery events plugin
	dependencies: clndr, moment, handlebars
*/
(function($) {
$.fn.events = function(opts, callback) {
	'use strict';
	
	var $main = this,
	 	date = new Date(), 
	 	y = date.getFullYear(), 
	 	m = date.getMonth(),
	 	firstDay = new Date(y, m, 1),
		lastDay = new Date(y, m + 12, 0),
		timer,
		defs = {
			pre: 'events',
			calendars: 'aca,art,hol,lif,clu,con,gen,ath',
			limit: 0,
			out: {
				calendar: $main,
				calSpud: '.cats',
				events: '.events-list',
				info: '.event-info'

			},
			click: {
				infoShow: '.events-list ul li',
				infoClose: '.events-list .event-info .close',
				today: '.clndr-today-button',
				icsDown: '.ics-btn',
				menuOpen: '#menuBtn',
				forceRefresh: '#forceCacheRefresh',
				expandBtn:'.expandBtn',
				catFilterBtn: '.cat-list-item input[type="checkbox"]',
				searchTrigger: 'triggerSearch'
			},
			template: {
				searchResults:'<div class="events-title">Search Results for "{{filters.search}}"</div><ul>{{#each events}}<li class="{{calSpud}} cat-event" data-events-event="{{@key}}">{{usDate}} - {{title}}</li>{{/each}}</ul><div class="event-info"></div>',
				search: '<div class="event-search-container"><input id="event-search" role="search" class="form-control" type="text" placeholder="Search for Events" title="Search for an event."/><a id="closeSearch" tabindex="0" title="Close Search"><span class="fa fa-times-circle"></span></a></div>',
				calendars: '<ul class="category">{{#each calendars}}<li><a data-filter="{{@key}}" data-placement="top" title="Toggle view of {{description}}" class="{{@key}} cat-list-item {{#if active}}active{{/if}}" role="button">{{description}}</a></li>{{/each}}</ul>',
				calendarH: '<div id="menuBtn" class="nav-icon1 {{#if menuOpen}}open{{/if}}" role="button" tabindex="0" title="{{#if menuOpen}}Close{{else}}Open{{/if}} calendar menu"><span></span><span></span><span></span></div><div class="cal-menu {{#if menuOpen}}open{{/if}}"><h3>Calendar</h3><div class="cal-functions"><h4>Display calendars</h4><ul class="category">{{#each calendars}}<li class="{{@key}} cat-list-item"><input type="checkbox" id="{{@key}}_toggle" data-filter="{{@key}}" data-placement="top" title="Toggle view of {{description}}" {{#if active}}checked{{/if}} class="{{@key}} "/><label for="{{@key}}_toggle">{{description}}</label></li>{{/each}}</ul>{{#if isEmployee}}<h4>More Functions</h4><ul><li><a href="https://25live.collegenet.com/uvu/mobile.html#/wizard/" id="add-event" class="calendar-action" target="_blank">Add Event</a></li><li><a href="https://25live.collegenet.com/uvu/mobile.html#/events/requestor" id="edit-event" class="calendar-action" target="_blank">Update your Events</a></li>{{#if isAdmin}}<li><a id="forceCacheRefresh" class="calendar-action" role="button">Refresh Calendar Cache <span class="fa fa-refresh" aria-hidden="true"></span></a></li>{{/if}}</ul>{{/if}}</div></div><div class="calendar col-sm-7"><div class="header clearfix"><div><h3 class="month-year"><a class="expandBtn" title="View Month Calendar" role="button">{{month}} <span class="hide-text">{{year}}</span><span class="fa fa-caret-down" aria-hidden="true"></span></a></h3></div><nav>{{> search}} <a class="triggerSearch" tabindex="0" title="Search for an Event"><span class="fa fa-search" aria-hidden="true"></span><span class="hide-text"> Search</span></a><a class="clndr-today-button" tabindex="0" title="Go to today"><span class="fa fa-calendar-o" aria-hidden="true"></span><span class="hide-text"> Today</span></a><a class="clndr-previous-button" tabindex="0" title="View the previous month"><span class="fa fa-chevron-left" aria-hidden="true"></span><span class="hide-text"> prev</span></a> <a class="clndr-next-button" tabindex="0" title="View the next month"><span class="hide-text">next </span><span class="fa fa-chevron-right" aria-hidden="true"></span></a></nav></div><div class="month-grid"><div class="week">{{#each daysOfTheWeek}}<div>{{.}}</div>{{/each}}</div><div class="days">{{#each days}}<div class="{{classes}}" id="{{@key}}" role="button"><div class="focusedDay"><div class="date">{{day}}</div><div class="cals">{{#each calSpud}} {{#if active}}<div class="{{cal}} cal-day"></div>{{/if}} {{/each}}</div></div></div>{{/each}}</div></div></div><div class="events-list col-sm-5" tabindex="0"></div>',
				calendarC: '<div id="menuBtn" class="nav-icon1 {{#if menuOpen}}open{{/if}}" role="button" tabindex="0" title="{{#if menuOpen}}Close{{else}}Open{{/if}} calendar menu"><span></span><span></span><span></span></div><div class="cal-menu {{#if menuOpen}}open{{/if}}"><h3>Calendar</h3><div class="cal-functions"><h4>Display calendars</h4><ul class="category">{{#each calendars}}<li class="{{@key}} cat-list-item"><input type="checkbox" id="{{@key}}_toggle" data-filter="{{@key}}" data-placement="top" title="Toggle view of {{description}}" {{#if active}}checked{{/if}} class="{{@key}} "/><label for="{{@key}}_toggle">{{description}}</label></li>{{/each}}</ul>{{#if isEmployee}}<h4>More Functions</h4><ul><li><a href="https://25live.collegenet.com/uvu/mobile.html#/wizard/" id="add-event" class="calendar-action" target="_blank">Add Event</a></li><li><a href="https://25live.collegenet.com/uvu/mobile.html#/events/requestor" id="edit-event" class="calendar-action" target="_blank">Update your Events</a></li>{{#if isAdmin}}<li><a id="forceCacheRefresh" class="calendar-action" role="button">Refresh Calendar Cache <span class="fa fa-refresh" aria-hidden="true"></span></a></li>{{/if}}</ul>{{/if}}</div></div><div class="calendar col-sm-12"><div class="header clearfix"><div><h3 class="month-year"><a class="expandBtn" title="View Month Calendar" role="button">{{month}} <span class="hide-text">{{year}}</span><span class="fa fa-caret-down" aria-hidden="true"></span></a></h3></div><nav>{{> search}} <a class="triggerSearch" tabindex="0" title="Search for an Event"><span class="fa fa-search" aria-hidden="true"></span><span class="hide-text"> Search</span></a><a class="clndr-today-button" tabindex="0" title="Go to today"><span class="fa fa-calendar-o" aria-hidden="true"></span><span class="hide-text"> Today</span></a><a class="clndr-previous-button" tabindex="0" title="View the previous month"><span class="fa fa-chevron-left" aria-hidden="true"></span><span class="hide-text"> prev</span></a> <a class="clndr-next-button" tabindex="0" title="View the next month"><span class="hide-text">next </span><span class="fa fa-chevron-right" aria-hidden="true"></span></a></nav></div><div class="month-grid"><div class="week">{{#each daysOfTheWeek}}<div>{{.}}</div>{{/each}}</div><div class="days">{{#each days}}<div class="{{classes}}" id="{{@key}}" role="button"><div class="focusedDay"><div class="date">{{day}}</div><div class="cals">{{#each calSpud}} {{#if active}}<div class="{{cal}} cal-day"></div>{{/if}} {{/each}}</div></div></div>{{/each}}</div></div></div><div class="events-list col-sm-12" tabindex="0"></div>',
				calendarF: '<div class="full-calendar"><div id="menuBtn" class="nav-icon1 {{#if menuOpen}}open{{/if}}" role="button" tabindex="0" title="{{#if menuOpen}}Close{{else}}Open{{/if}} calendar menu"><span></span><span></span><span></span></div><div class="col-md-3 cal-sidebar"><div class="cal-menu open"><h3>Calendar Options</h3><div class="cal-functions"><h4>Display calendars</h4><ul class="category">{{#each calendars}}<li class="{{@key}} cat-list-item"><input type="checkbox" id="{{@key}}_toggle" data-filter="{{@key}}" data-placement="top" title="Toggle view of {{description}}" {{#if active}}checked{{/if}} class="{{@key}} "/><label for="{{@key}}_toggle">{{description}}</label></li>{{/each}}</ul>{{#if isEmployee}}<h4>More Functions</h4><ul><li><a href="https://25live.collegenet.com/uvu/mobile.html#/wizard/" id="add-event" class="calendar-action" target="_blank">Add Event</a></li><li><a href="https://25live.collegenet.com/uvu/mobile.html#/events/requestor" id="edit-event" class="calendar-action" target="_blank">Update your Events</a></li>{{#if isAdmin}}<li><a id="forceCacheRefresh" class="calendar-action" role="button">Refresh Calendar Cache <span class="fa fa-refresh" aria-hidden="true"></span></a></li>{{/if}}</ul>{{/if}}</div></div></div><div class="display col-md-9"><div class="calendar col-md-12"><div class="header clearfix"><div><h3 class="month-year"><a class="expandBtn" title="View Month Calendar" role="button">{{month}} <span class="hide-text">{{year}}</span><span class="fa fa-caret-down" aria-hidden="true"></span></a></h3></div><nav>{{> search}} <a class="triggerSearch" tabindex="0" title="Search for an Event"><span class="fa fa-search" aria-hidden="true"></span><span class="hide-text"> Search</span></a><a class="clndr-today-button" tabindex="0" title="Go to today"><span class="fa fa-calendar-o" aria-hidden="true"></span><span class="hide-text"> Today</span></a><a class="clndr-previous-button" tabindex="0" title="View the previous month"><span class="fa fa-chevron-left" aria-hidden="true"></span><span class="hide-text"> prev</span></a> <a class="clndr-next-button" tabindex="0" title="View the next month"><span class="hide-text">next </span><span class="fa fa-chevron-right" aria-hidden="true"></span></a></nav></div><div class="month-grid"><div class="week">{{#each daysOfTheWeek}}<div>{{.}}</div>{{/each}}</div><div class="days">{{#each days}}<div class="{{classes}}" id="{{@key}}" role="button"><div class="focusedDay"><div class="date">{{day}}</div><div class="cals">{{#each calSpud}} {{#if active}}<div class="{{cal}} cal-day"></div>{{/if}} {{/each}}</div></div></div>{{/each}}</div></div></div><div class="events-list col-md-12" tabindex="0"></div></div></div>',
				events: '<div class="events-title">{{date.wday}}, {{date.month}} {{date.day}}</div>{{#if events}}<ul>{{#each events}} {{#if activeCal}}<li class="{{calSpud}} cat-event" data-events-event="{{@key}}">{{title}}</li>{{/if}} {{/each}}</ul>{{else}}<p class="empty">There are no events for the selected date.</p>{{/if}}<div class="event-info"></div>',
				info: '<a class="downloadEvent {{calSpud}}" title="Add event to personal Calendar" href="/_common/php/eventfeed/eventfeed-xml.php?event={{eventId}}&func=getCalFile" data-eventId="{{eventId}}" target="_blank"><span class="fa fa-calendar-plus-o" aria-hidden="true"></span></a><a class="close {{calSpud}}" title="Close Panel" role="button"><span class="fa fa-times"></span></a><h2 class="{{calSpud}} event-title" title="Event title | {{title}}">{{title}}</h2><div class="{{calSpud}} details"><div class="timeStamp "><span title="Start time - {{startTime.hour}}">{{startTime.hour}}</span> - <span title="End time - {{endTime.hour}}">{{endTime.hour}}</span></div>{{#if eventAdmissionsPrice}}<div class="eventPrice">Event Admissions Price: <span class="eventPriceAmount">${{eventAdmissionsPrice}}</span></div>{{/if}}<div class="desc-loc">{{#if description}}<div class="desc {{#if location}}col-sm-7{{else}}col-sm-12{{/if}}">{{{description}}}</div>{{/if}}{{#if location}}<div class="loc col-sm-5"><h3 >Location</h3><ul>{{#each location}}<li class="location" title="Event location | {{.}}">{{.}}</li>{{/each}}</div>{{/if}}</div>{{#if contactInfo}}<div class="contact-info"><h3>Contact Info</h3><ul>{{#if contactInfo.phone}}{{#each contactInfo.phone}}<li><a href="tel:{{.}}" class="contact-phone btn btn-default">{{.}}</a></li>{{/each}}{{/if}}{{#if contactInfo.email}}{{#each contactInfo.email}}<li><a href="mailto:{{.}}" class="contact-email btn btn-default">{{.}}</a></li>{{/each}}{{/if}}</div>{{/if}}</div>'
				
			},
			url: {
				events: '/_common/php/eventfeed/eventfeed-xml.php',
				clndr: 'clndr.min.js',
				moment: 'moment.min.js',
				handlebars: 'handlebars.min.js'
			},
			constraints:{
				start: firstDay,
				end: lastDay
			},
			dateparameter: 'start',
			forceFlush:false,
			Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false,
			moment: typeof moment !== 'undefined' ? moment : false,
			func: {}, // custom interaction functions
			data: false,
			isEmployee: false,
			isAdmin: false,
			menuOpen:false,
			preset: false,	// select preset
			// presets to overwrite the above vars
			presets: {
				campusrec:{
					calendars: 'wel,oac,int,rec',
					func:{
						calendar: function(opts,d){
							var classes,calSpud,i,x;

							for( i=0; i < d.days.length; i++) {
								calSpud = [];
								for( x=0; x < d.days[i].events.length; x++ ){	
									d.days[i].events[x].activeCal = opts.data.calendars[d.days[i].events[x].calSpud].active;
									var tmp = {cal:d.days[i].events[x].calSpud,active:opts.data.calendars[d.days[i].events[x].calSpud].active};
									calSpud.push(tmp);
								}
								d.days[i].calSpud = calSpud;
							}
							d.calendars = opts.data.calendars;
							d.menuOpen = opts.menuOpen;
							if (opts.layout == 'column') {
								return opts.template.calendarC(d);
							} else if (opts.layout == 'full') {
								return opts.template.calendarF(d);
							} else {
								return opts.template.calendarH(d);
							}
						}
					}
				},
				myuvu:{
					
					func:{
						isAdmin: function(){
							if(typeof (myuvu) != 'undefined'){
								return myuvu.user.groups.indexOf('administrators') !== -1 ? true : false;
							}else{
								return false;
							}
						},
						isEmployee: function(){
							if(typeof (myuvu) != 'undefined'){
								if(myuvu.user.groups.indexOf('employees') > -1 || myuvu.user.groups.indexOf('administrators') > -1){
									return true;
								}else{
									return false;
								}
							}else{
								return false;
							}
						},
						menu: function(opts,d){
							opts.$this.find(opts.click.menuOpen).off('click').on('click', function(){
								opts.menuOpen = opts.$this.find('#menuBtn').hasClass('open') === true ? false:true;
								opts.$this.find('#menuBtn').toggleClass('open');
								opts.$this.find('.cal-menu').toggleClass('open');

							});
							opts.$this.find(opts.click.menuOpen).on('keyup', function (e) {
								if (e.keyCode == 32) {
									opts.menuOpen = opts.$this.find('#menuBtn').hasClass('open') === true ? false : true;
									opts.$this.find('#menuBtn').toggleClass('open');
									opts.$this.find('.cal-menu').toggleClass('open');
								}

							});
							opts.$this.find(opts.click.forceRefresh).off('click').on('click', function(){
								opts.$this.find(opts.click.forceRefresh).children('i').addClass('fa-spin');
								opts.forceFlush = true;
								
								getEvents(opts, 'update');
							});
							opts.$this.find(opts.click.catFilterBtn).off('click').on('click', function(){
								var clickedClass = $(this).attr('data-filter');
								var currentSelection = opts.$this.find('.selected').attr('id');
								opts.data.calendars[clickedClass].active = opts.data.calendars[clickedClass].active == true? false:true;

								setEvents(opts,d);
								opts.$this.find('#'+currentSelection).trigger('click');
							});
							opts.func.expand(opts,d);	
						},
						calendar: function(opts,d){
							var classes,calSpud,i,x;

							for( i=0; i < d.days.length; i++) {
								calSpud = [];
								for( x=0; x < d.days[i].events.length; x++ ){	
								
									d.days[i].events[x].activeCal = opts.data.calendars[d.days[i].events[x].calSpud].active;
									var tmp = {cal:d.days[i].events[x].calSpud,active:opts.data.calendars[d.days[i].events[x].calSpud].active};
									
									calSpud.push(tmp);
									
								}
								
								d.days[i].calSpud = calSpud;
								
							}
							d.calendars = opts.data.calendars;
							d.isEmployee = opts.func.isEmployee();
							d.isAdmin = opts.func.isAdmin();
							d.menuOpen = opts.menuOpen;
							if (opts.layout == 'column') {
								return opts.template.calendarC(d);
							} else if(opts.layout == 'full') {
								return opts.template.calendarF(d);
							}else{
								return opts.template.calendarH(d);
							}
						}
					}
					
				}
				
			},
			helper:{
				
			}
		};

	/* interaction functions */

	// list day's events
	defs.func.list = function(opts,d,type){
		if(type != 'search'){
			d.date = {
				day : opts.moment(d.date).format('Do'),
				wday : opts.moment(d.date).format('dddd'),
				month : opts.moment(d.date).format('MMMM'),
				year : opts.moment(d.date).format('YYYY')
			};
			// output list
			$(opts.out.events).html(opts.template.events(d));
		}else{
			$(opts.out.events).html(opts.template.searchResults(d));
		}
		// show info
		opts.$this.find(opts.click.infoShow).off('click').on('click', function(){
			var id = $(this).attr('data-events-event');
			opts.$this.find('.events-list .event-info').html(opts.template.info(d.events[id])).addClass('open');
			opts.$this.find('.events-list .event-info').focus();

			opts.$this.find('.contact-info h3').off('click').on('click', function(){
				opts.$this.find('.contact-info').toggleClass('show');
			});
			// hide info
			opts.$this.find(opts.click.infoClose).off('click').on('click', function(){
				opts.$this.find('.events-list .event-info').removeClass('open');
			});
		});
		if (type != 'search') {
			opts.$this.find(opts.click.expandBtn).trigger('click');
		}

	};
	defs.func.menu = function(opts,d){
			opts.$this.find(opts.click.menuOpen).off('click').on('click', function(){
				opts.menuOpen = opts.$this.find('#menuBtn').hasClass('open') === true ? false:true;
				opts.$this.find('#menuBtn').toggleClass('open');
				opts.$this.find('.cal-menu').toggleClass('open');

			});
			opts.$this.find(opts.click.menuOpen).on('keyup', function (e) {
				if(e.keyCode == 32){
					opts.menuOpen = opts.$this.find('#menuBtn').hasClass('open') === true ? false : true;
					opts.$this.find('#menuBtn').toggleClass('open');
					opts.$this.find('.cal-menu').toggleClass('open');
				}

			});
			opts.$this.find(opts.click.forceRefresh).off('click').on('click', function(){
				opts.$this.find(opts.click.forceRefresh).children('i').addClass('fa-spin');
				opts.forceFlush = true;
				
				getEvents(opts, 'update');
			});
			opts.$this.find(opts.click.catFilterBtn).off('click').on('click', function(){
				var clickedClass = $(this).attr('data-filter');
				var currentSelection = opts.$this.find('.selected').attr('id');
				opts.data.calendars[clickedClass].active = opts.data.calendars[clickedClass].active == true? false:true;

				setEvents(opts,d);
				opts.$this.find('#'+currentSelection).trigger('click');
			});
			opts.func.expand(opts,d);	
	};
	defs.func.today = function(opts,d){
		opts.$this.find(opts.click.today).off('click').on('click', function(){
			opts.$this.find('.today').trigger('click');
		});
		opts.$this.find(opts.click.today).on('keyup', function (e) {
			if(e.keyCode == 32){
				opts.$this.find('.today').trigger('click');
			}
		});
	};
	defs.func.searchModule = function(opts,d){
		opts.$this.find($(".triggerSearch").off('click').on('click', function(){
			opts.$this.find($('.event-search-container')).fadeIn();
			opts.$this.find($('#event-search')).focus();
		}));
		opts.$this.find($(".triggerSearch").on('keyup', function (e) {
			if(e.keyCode == 32){
				opts.$this.find($('.event-search-container')).fadeIn();
				opts.$this.find($('#event-search')).focus();
			}
		}));
		opts.$this.find($("#closeSearch").off('click').on('click', function(){
			opts.$this.find($('.event-search-container')).fadeOut();
			opts.$this.find($('#event-search').val(""));
			opts.$this.find('.today').trigger('click');
		}));
		opts.$this.find($("#closeSearch").on('keyup', function (e) {
			if(e.keyCode == 32){
				opts.$this.find($('.event-search-container')).fadeOut();
				opts.$this.find($('#event-search').val(""));
				opts.$this.find('.today').trigger('click');
			}
		}));
		
		opts.$this.find($("#event-search").on('keyup', function(){
			opts.$this.find($("#closeSearch .fa")).removeClass('fa-times-circle').addClass('fa-spin fa-spinner');
			clearTimeout(opts.$this.timer);
			opts.$this.timer = setTimeout(function() {
				
				searchEvents(opts, opts.$this.find($("#event-search")).val());
			}, 1000);
			
		}));
	};
	// render calendar
	defs.func.calendar = function(opts,d){
		var classes,calSpud,i,x;

		for( i=0; i < d.days.length; i++) {
			calSpud = [];
			for( x=0; x < d.days[i].events.length; x++ ){	
			
				d.days[i].events[x].activeCal = opts.data.calendars[d.days[i].events[x].calSpud].active;
				var tmp = {cal:d.days[i].events[x].calSpud,active:opts.data.calendars[d.days[i].events[x].calSpud].active};
				
				calSpud.push(tmp);
				
			}
			
			d.days[i].calSpud = calSpud;
			
		}
		d.calendars = opts.data.calendars;
		d.menuOpen = opts.menuOpen;
		if(opts.layout== 'column'){
			return opts.template.calendarC(d);
		}else if(opts.layout == 'full'){
			return opts.template.calendarF(d);
		}else{
			return opts.template.calendarH(d);
		}
	};
	
	defs.func.expand = function(opts, d){
		opts.$this.find(opts.click.expandBtn).off('click').on('click', function(){
			$(this).toggleClass('rotate');
			opts.$this.find('.calendar').toggleClass('expanded');
		});
	};
	// calendar ready
	defs.func.ready = function(opts,d){
		opts.$this.find('.today').trigger('click'); // load today's events
	};
	defs.func.setFirstDay = function(opts,d){
		var date = {
			day : opts.moment(d._d).format('DD'),
			month : opts.moment(d._d).format('MM'),
			year : opts.moment(d._d).format('YYYY')
		};

		opts.$this.find('.calendar-day-'+date.year+'-'+date.month+'-'+date.day).trigger('click');
	};
	// check for user passed in options
	$.extend(true, defs, opts);

	// make calendar
	function calendar(opts){
		
		
		// clndr plugin setup
		opts.$this.clndr({
			events: typeof opts.data.events !== 'undefined' ? opts.data.events : [],
			multiDayEvents: {
				endDate: 'end',
				singleDay: 'date',
				startDate: 'start'
			},
			dateParameter: opts.dateparameter,
			forceSixRows: true,
			trackSelectedDate: true,
			
			// render calendar
			render: function(d) {
				return opts.func.calendar(opts,d);
			},
			
			// add click event
			clickEvents: {
				click: function(d){
					opts.func.list(opts,d,"standard");
					opts.func.menu(opts,d);
					opts.func.searchModule(opts, d);
				},
				onMonthChange: function(d){
					opts.func.menu(opts,d);
					opts.func.setFirstDay(opts,d);
					opts.func.searchModule(opts,d);
				},
				today: function(d){
					opts.func.today(opts,d);
				},
			},
			ignoreInactiveDaysInSelection:true,
			constraints: {
		        startDate: opts.constraints.start,
		        endDate: opts.constraints.end
		    },

			// ready
			ready: function(d){
				opts.func.ready(opts,d);
			}
		});
		
	}
	function setEvents(opts){
		opts.$this.clndr().setEvents(opts.data.events);
	}

	// get templates from either html or string
	function getTemplates(opts){
		var t = opts.template,
			i;
		
		for( i in t ){
			if( t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0 ) t[i] = $(t[i]).html(); // test if template or selector
			defs.Handlebars.registerPartial( i, t[i] ); // all templates are also a partial
			t[i] = defs.Handlebars.compile(t[i]); // make template
		}
		defs.Handlebars.registerHelper(opts.helper);
	}

	// getting all html5 data- attributes with matching prefix
	function getDataDash(opts){
		var dd = opts.$this[0].attributes,
			ow = {},
			val,sel,i,n,
			nest = function(sel, val){ // make nested array
				var s = sel.shift(),
					v = sel.length ? nest(sel, val) : val,
					r = {};
				r[ typeof s !== 'undefined' ? s : sel ] = v;
				return r;
			};
		
		for( i=0; i < dd.length; i++ ){
			if( dd[i].name.indexOf('data-'+opts.pre+'-') !== -1 ) $.extend(true, ow, nest( dd[i].name.replace('data-'+opts.pre+'-', '').split('-'), dd[i].value ) );
		}

		return ow;
	}
	function searchEvents(opts, searchTerm){
		if(searchTerm.length > 0){
			return $.ajax({
				url: opts.url.events,
				data: {
					cal: opts.calendars,
					search: searchTerm
				}
			}).done(function(s){
				var results = s;
				opts.func.list(opts, results, 'search');
				opts.$this.find($("#closeSearch .fa")).removeClass('fa-spinner fa-spin').addClass('fa-times-circle');
			});
		}
	}
	function getEvents(opts, createUpdate){
		
		return	$.ajax({
			url: opts.url.events,
			data: {
				cal: opts.calendars,
				forceFlush: opts.forceFlush,
				limit: opts.limit
			}
		}).done(function(d){

			opts.data = d;
			$.each(opts.data.calendars, function(key, val){
				var newData ={description:val, active: true};
				opts.data.calendars[key] = newData;
			});
			if(createUpdate == 'create'){
				setEvents(opts);
				opts.func.ready(opts, d);
			}else if (createUpdate == 'update' ){
				setEvents(opts);
				opts.$this.find(opts.click.forceRefresh).children('i').removeClass('fa-spin');
			}else{
				calendar(opts);
			}
			
		}).fail(function(a,b,c){
			console.log(a+b+c);
			calendar(opts);
			opts.$this.find(opts.click.forceRefresh).children('i').removeClass('fa-spin');
		});
	}
	// init
	function init(){
		// return plugin instances
		return $main.each(function() {
			var opts = $.extend(true, {}, defs),
				preset = $(this).is('[data-'+opts.pre+'-preset]') ? $(this).attr('data-'+opts.pre+'-preset') : opts.preset,  // check for preset
				calendars = $(this).is('[data-'+opts.pre+'-cal]') ? $(this).attr('data-'+opts.pre+'-cal') : opts.calendars,
				limit = $(this).is('[data-'+opts.pre+'-limit]') ? $(this).attr('data-'+opts.pre+'-limit') : opts.limit,
				layout = $(this).is('[data-' + opts.pre + '-layout]') ? $(this).attr('data-' + opts.pre + '-layout') : opts.layout,
				ow,i;

			opts.$this = $(this);
			
			if( preset  && typeof opts.presets[preset] !== 'undefined' ){
				$.extend( true, opts, opts.presets[preset] );	// get preset values
			}else if( calendars !== 'undefined' ){
				opts.calendars = calendars; // get preset values
			}else{}

			// extend opts from html data-
			$.extend( true, opts, getDataDash(opts) );
			// getting templates
			getTemplates(opts);
			// get events
			calendar(opts);
			getEvents(opts, 'create');
		});
	}

	// basic dependency check
	if( typeof $.fn.clndr == 'function' && defs.Handlebars && defs.moment ){
		init();
	}else{
		$.getScript(defs.url.clndr);
		$.getScript(defs.url.moment, function(){ defs.moment = moment; });
		$.getScript(defs.url.handlebars, function(){
			defs.Handlebars = Handlebars;
			init();
		});
	}
};

})(jQuery);