(function ($) {
    $.fn.checkAccess = function (opts, callback) {
        'use strict';
        const $main = this,
            defs = {
                pre: 'checkAccess',
                url: {
                    base: `${myuvu.server}/_services/student/student.php`,
                    person: `${myuvu.server}/_services/system/person.php`,
                    handlebars: `${myuvu.server}${myuvu.common}js/handlebars.min.js`
                },
                term: '202140',
                cacheTime: 6000,
                flush: false,
                wasDismissid: false,
                src: 'prod',
                listen : {
                    form: false,
                    uvid: false,
                    termcode: false,
                    src:false
                }, 
                template: {
                    main: ``
                },
                helper: {
                    ifEquals: function (arg1, arg2, options) {
                        return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
                    }
                },
                func:{},
                Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false

            };
        // check for user passed in options
        $.extend(true, defs, opts);
        defs.func.listen = function (opts) {
            if (opts.listen.form !== false) {
                $(opts.listen.form).submit(()=> {
                    opts.flush = true;
                    run(opts); 
                });
            }
        };
        defs.func.beforeUnload = function(opts, sessVar){
            window.addEventListener("beforeunload", function(e) {
                if(myuvu.session.get(sessVar) !== 'undefined' && myuvu.session.get(sessVar) !== null){
                    const cache = myuvu.session.get(sessVar);
                    if(cache.getting === true){
                        myuvu.session.del(sessVar);
                    }
                }
                delete e.returnValue;
            });
        };
        defs.func.showCovidModal = function(opts, data){
            let vaxData = data.vaxData;
            let sfra = data.sfra;
            let storage = myuvu.session.get('covid-information');
            bootbox.dialog({
                title: `UVU COVID-19 Immunization Status Check`,
                message: `<p class="text-center">Starting Spring 2022, UVU will be requiring a vaccine status to help combat COVID-19. Please answer this short survey to update your status.</p>`,
                closeButton: false,
                buttons: {
                    doLater:{
                        label: 'Dismiss for now',
                        className: 'btn-secondary',
                        callback: function(){
                            storage.dismissed = true;
                            myuvu.session.set('covid-information', storage);
                            if(sfra.content.currentStartDate == ""){
                                opts.wasDismissid = true;
                                opts.func.showSFRAModal(opts, sfra);
                            }
                        }
                    },
                    goTo:{
                        label: 'Update status',
                        className: 'btn-primary',
                        callback: function(){
                            storage.dismissed = true;
                            myuvu.session.set('covid-information', storage);
                            let ref = window.location.href;
                            window.open(`https://qualtrics.uvu.edu/student/SV_8v5WAhFKijl8DCm?referringURL=${ref}`,'_self').focus();
                            if(sfra.content.currentStartDate == ""){
                                opts.wasDismissid = true;
                                opts.func.showSFRAModal(opts, sfra);
                            }
                        }
                    },
                    
                }
            });
        };
        defs.func.showSFRAModal = function(opts, data){
            bootbox.dialog({
                title: `Student Financial Responsibility Agreement Notice`,
                message: `<p class="text-center">You are required to sign a Student Financial Responsibility Agreement (SFRA) once per year. Please do so now!</p>`,
                closeButton: false,
                buttons:{
                    refreshData:{
                        label: `Refresh Data <i class="fad fa-sync"></i>`,
                        className: 'btn-secondary',
                        callback: function(){
                            opts.flush = true;
                            run(opts);
                        }
                    },
                    goTo:{
                        label:'Go to Agreement',
                        className:'btn-primary',
                        callback: function(){
                            window.open(`${data.content.agreementURL}`,'_self').focus();
                            return false;
                        }
                    }
                }
            });
        };
        function out(opts, data){
            let sfra = data.sfra;
            let vaxContent = data.vaxData.content.data;
            data.vaxData.dismissid = opts.wasDismissid == true? true : false;
            opts.flush = false;
            if(vaxContent.length == 0 || (vaxContent[0].immunizationStatusCode == "P1" && vaxContent[0].immunizationLastActivityDaysAgo >= 30) || (vaxContent[0].immunizationStatusCode == "P2" && vaxContent[0].immunizationLastActivityDaysAgo >= 30)){
                if(!data.vaxData.hasOwnProperty("dismissed")){
                    opts.func.showCovidModal(opts, data);
                }else if(sfra.content.currentStartDate == ""){
                    opts.func.showSFRAModal(opts, sfra);
                }
            }else if(sfra.content.currentStartDate == ""){
                opts.func.showSFRAModal(opts, sfra);
            }
            
            console.log(data);
        }

        async function run(opts){
            try{
                const user = await getUser(opts);
                const addOpts = {'id': user.data.id, 'term': user.data.term, 'src': user.data.src};
                opts = {...opts, ...addOpts};
                const sfraData = await getData(opts, 'sfra-information', `${opts.url.base}?call=sfra&id=${opts.id}&src=${opts.src}`);
                const vaxData = await getData(opts, 'covid-information', `${opts.url.person}?call=covid&id=${opts.id}&src=${opts.src}`);
                let data = {};
                    data.sfra = sfraData;
                    data.vaxData = vaxData;
                out(opts, data);
            }catch(err){
                console.error('Error', err);
            }
        }
        // init plugin
        function init() {
            // return plugin instance
            return $main.each(function () {
                var opts = $.extend({}, defs),
                    ow, i;


                opts.$this = $(this);
                // extend opts from html data-
                $.extend(true, opts, getDataDash(opts.pre, opts));
                // getting templates
                getTemplates(opts);
                run(opts);
                opts.func.listen(opts);
            });
        }

        // check dependencies and init
        if (defs.Handlebars) {
            init();
        } else {
            $.getScript(defs.url.handlebars, function () {
                defs.Handlebars = Handlebars;
                init();
            });
        }

    };
})(jQuery);