(function ($) {
    $.fn.dashboardUserControls = function (opts, callback) {
        'use strict';
        var $main = this,
            defs = {
                pre: 'dashboardUserControls',
                url: {
                    base: '/_services/student/student.php',
                    handlebars: '/_common/js/handlebars.min.js'
                },
                term: '202140',
                cacheTime: 3600,
                flush: false,
                src: 'prod',
                template:{
                    main: `<div class="emulate-container"><div class="student-profile-image-wrapper"><img src="{{profileImageUrl}}"/></div><div class="basic-info"><span>{{firstName}} {{lastName}}</span><br /><span>{{id}}</span></div><div class="stop-emulation-container"><a href="#" class="stop-emulation-btn"><i class="fa fa-window-close"></i></a></div></div>`
                },
                helper: {
                    ifEquals: function (arg1, arg2, options) {
                        return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
                    }
                },
                func: {},
                Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false

            };
            // check for user passed in options
            $.extend(true, defs, opts);
            defs.func.lookupModal = function(opts){
                $('#openLookupData').off('click').on('click', function (e) {
                    e.preventDefault();
                    bootbox.confirm({
                        title: `Lookup Information`,
                        message: `<div class="form-group">
                                            <label for="uvid">UV ID</label>
                                            <input id="uvid" type="text" class="form-control" placeholder="10000000"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="data-from-select">Source</label>
                                            <select id="data-from-select" class="form-control">
                                                
                                                <option value="prod" selected>Production Data</option>
                                            </select>
                                        </div>`,
                        callback: function (result) {
                            if (result == true) {
                                let id = ($('#uvid').val() == '') ? myuvu.user.id : $('#uvid').val().trim();
                                
                                opts.src = $('#data-from-select').val();
                                $('.termCodeSelector').removeClass('active');
                                ajax(opts, id);
                            }
                        }
                    });
                });
            };
            defs.func.updateTerm = function(opts){
                $('.termCodeSelector').off('click').on('click', function(e){
                    e.preventDefault();
                    if (myuvu.session.get('enrollment-dashboard') !== 'undefined' && myuvu.session.get('enrollment-dashboard') !== null) {
                        let cache = myuvu.session.get('enrollment-dashboard'),
                            selectedTerm = $(this).attr('data-term-select');
                            myuvu.session.del('enrollment-dashboard');
                        cache.data.term = selectedTerm;
                        $('#term-update').val(selectedTerm);
                        myuvu.session.set('enrollment-dashboard', cache);
                        $('.termCodeSelector').removeClass('active');
                        $(this).addClass('active');
                        $('#lookup-form').submit(function () {
                            e.preventDefault();
                        }).trigger('submit');
                    }
                });
            };
            function out(opts, d){
                let data = d.data;
                if("firstName" in data){
                    if(data.id != myuvu.user.id){
                        opts.$this.html(opts.template.main(data));
                        opts.$this.find('.stop-emulation-btn').off('click').on('click', function(e){
                            e.preventDefault();
                            opts.$this.html('');
                            $('.termCodeSelector').removeClass('active');
                            let id = myuvu.user.id;
                            ajax(opts, id);
                        });
                    }else{
                        opts.$this.html('');
                    }
                    $(`#term-${data.term}`).addClass('active');
                    $('#uvid-update').val(data.id);
                    $('#data-from').val(opts.src);
                    $('#lookup-form').submit();

                }
                
            }
            function get(opts) {
                
                if (myuvu.session.get('enrollment-dashboard') !== 'undefined' && myuvu.session.get('enrollment-dashboard') !== null) {
                    let cache = myuvu.session.get('enrollment-dashboard');
                    if (cache.length != 0) {
                        if (cache.getting === true) {
                            setTimeout(function () {
                                get(opts, id);
                            }, 100);
                        } else {
                            if (opts.flush === true) {
                                let id = cache.data.id;
                                myuvu.session.del('enrollment-dashboard');
                                ajax(opts, id);
                                opts.flush = false;
                            } else {
                                let dt = Math.ceil((Date.now() - (cache.time + (opts.cacheTime * 1000))) / 1000),
                                id = cache.data.id;
                                if (typeof cache.time !== 'undefined' && dt < opts.cacheTime) {
                                    out(opts, cache);
                                } else {
                                    myuvu.session.del('enrollment-dashboard');
                                    ajax(opts, id);
                                    opts.flush = false;
                                }
                            }
                        }
                    }
                } else {
                    ajax(opts, myuvu.user.id);
                }
            }
            // ajax data get
            function ajax(opts, id) {
                
                $.ajax({
                    url: opts.url.base,
                    dataType: 'json',
                    data: {
                        call: "basic",
                        id: id,
                        src: opts.src
                    }
                }).done(function (d) {
                    d.id = id;
                    d.term = opts.term;
                    d.src = opts.src;
                    myuvu.session.set('enrollment-dashboard', {
                        time: new Date().getTime(),
                        data: d,
                        getting: false
                    });
                    out(opts, myuvu.session.get('enrollment-dashboard'));

                }).fail(function (a, b, c) {
                    myuvu.session.set('enrollment-dashboard', {
                        time: new Date().getTime(),
                        getting: false
                    });
                    out(opts, false);

                    console.log('Enrollment lookup failed:' + a);
                    console.log('- type: ' + b);
                    console.log('- description: ' + c);
                });
            }
            // get templates from either html or string
            function getTemplates(opts) {
                var t = opts.template,
                    i;

                for (i in t) {
                    if (t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0) t[i] = $(t[i]).html(); // test if template or selector
                    defs.Handlebars.registerPartial(i, t[i]); // all templates are also a partial
                    t[i] = defs.Handlebars.compile(t[i]); // make template
                }
                defs.Handlebars.registerHelper(opts.helper);
            }

            // getting all html5 data- attributes with matching prefix
            function getDataDash(pre, opts) {
                var dd = opts.$this[0].attributes,
                    ow = {},
                    val, sel, i, n,
                    nest = function (sel, val) { // make nested array
                        var s = sel.shift(),
                            v = sel.length ? nest(sel, val) : val,
                            r = {};
                        r[typeof s !== 'undefined' ? s : sel] = v;
                        return r;
                    };

                for (i = 0; i < dd.length; i++) {
                    if (dd[i].name.indexOf('data-' + pre + '-') !== -1) $.extend(true, ow, nest(dd[i].name.replace('data-' + pre + '-', '').split('-'), dd[i].value));
                }

                return ow;
            }
            // init plugin
            function init() {
                // return plugin instance
                return $main.each(function () {
                    var opts = $.extend({}, defs),
                        ow, i;


                    opts.$this = $(this);
                    // extend opts from html data-
                    $.extend(true, opts, getDataDash(opts.pre, opts));
                    // getting templates
                    getTemplates(opts);
        
                    get(opts);
                    opts.func.lookupModal(opts);
                    opts.func.updateTerm(opts);
                });
            }

            // check dependencies and init
            if (defs.Handlebars) {
                init();
            } else {
                $.getScript(defs.url.handlebars, function () {
                    defs.Handlebars = Handlebars;
                    init();
                });
            }
    };
})(jQuery);