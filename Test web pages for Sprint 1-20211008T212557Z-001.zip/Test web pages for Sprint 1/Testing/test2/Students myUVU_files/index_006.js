(function ($) {
    $.fn.financialStatus = function (opts, callback) {
        'use strict';
        const $main = this,
            defs = {
                pre: 'financialStatus',
                url: {
                    base: `${myuvu.server}/_services/student/student.php`,
                    handlebars: '/_common/js/handlebars.min.js'
                },
                term: '202120',
                cacheTime: 240,
                flush: false,
                src: 'prod',
                listen: {
                    form: false,
                    uvid: false,
                    termcode: false,
                    src: false
                },
                template: {
                    main: `<div class="financial-status-card-container">{{#each this}}{{>termCard}}{{/each}}</div>`,
                    termCard: `<div class="financial-status-card {{term_status}} widget" data-financial-modal-termcode="{{term_code}}" tabindex="0" title="Click to view {{term_desc}} details.">
                                    <h2 class="title">{{#unless in_collections}}{{term_desc}}{{else}}Payment Information{{/unless}}</h2>
                                    <div class="financial-status-content">
                                    {{#if in_collections}}
                                    {{>collections}}
                                    {{else}}
                                        {{#if owes_past_term_balance}}{{>pastBalance}}{{else}}
                                            {{#ifGreater term_balance "0"}}{{>termBalance}}{{{getDatePhrase this}}}{{>vetsEligible}}{{else}}{{>goodStanding}}{{/ifGreater}}
                                        {{/if}}
                                    {{/if}}
                                    {{#if in_collections}}{{>collectionsBtnBar}}{{else}}{{#if owes_past_term_balance}}{{>pastBalanceBtnBar}}{{else}}{{#ifGreater term_balance "0"}}{{#ifGreater term_estimated_financial_aid term_balance}}{{>erefundEnrollment}}{{else}}{{>balanceBtnBar}}{{/ifGreater}}{{/ifGreater}}{{/if}}{{/if}}
                                    </div>
                                </div>
                            `,
                    pastBalance: `<h3>You have a past semester balance:</h3><p><span class="fs-balance">\${{getBalance past_term_balance_amount term_balance}}</span>{{{getDatePhrase this}}}</p>{{#if veterans_benefit_eligible}}{{/if}}`,
                    collections: `<h3>Your Account Status:</h3><p><span class="fs-balance">In Collection</span></p>`,
                    termBalance: `<p>{{#ifGreater term_estimated_financial_aid term_balance}}You have an estimated credit of: <span class="fs-balance">\${{getBalance term_estimated_financial_aid term_balance}}</span>{{else}}You owe: <span class="fs-balance">\${{getBalance term_estimated_financial_aid term_balance}}</span>{{/ifGreater}}</p>`,
                    goodStanding:`<i class="fad fa-thumbs-up"></i><p>Your account is paid in full and in good standing.</p>`,
                    erefundEnrollment: `<div class="btn-footer"><a href="https://userve.uvu.edu/ssomanager/saml/login?relayState=/c/auth/SSB?pkg=bwykxdrd.P_DirdAuth" title="Link opens in this tab">{{#if erefund_enrollment}}Verify your Direct Deposit Information{{else}}Enroll in Direct Deposit?{{/if}}</a></div>`,
                    balanceBtnBar: `<div class="btn-footer"><a href="https://shib.uvu.edu/idp/profile/SAML2/Unsolicited/SSO?providerId=touchnet-prod-tbp&shire=https://secure.touchnet.com/C20242_tsa/web/caslogin.jsp?REDIRECT_PARAMETER=PAYMENTS" target="touchnet" title="Link opens in a new tab">Pay Now</a>{{#getPPenrollment this}}<a href="https://shib.uvu.edu/idp/profile/SAML2/Unsolicited/SSO?providerId=touchnet-prod-tbp&shire=https://secure.touchnet.com/C20242_tsa/web/caslogin.jsp?REDIRECT_PARAMETER=PAYMENT_PLANS" target="touchnet" title="Link opens in a new tab">Set up a Payment Plan</a>{{/getPPenrollment}}</div>`,
                    pastBalanceBtnBar: `<div class="btn-footer"><a href="https://shib.uvu.edu/idp/profile/SAML2/Unsolicited/SSO?providerId=touchnet-prod-tbp&shire=https://secure.touchnet.com/C20242_tsa/web/caslogin.jsp?REDIRECT_PARAMETER=PAYMENTS" target="touchnet" title="Link opens in a new tab">Pay Now</a></div>`,
                    collectionsBtnBar: `<div class="btn-footer"><a href="https://cwa.uvu.edu/cwa_wotu/Login.aspx" target="crcSystem" title="Link opens in a new tab">Pay Now</a><a href="#" class="collectionsMore" data-financial-modal-termcode="{{term_code}}">More Information</a></div>`,
                    vetsEligible: `{{#if veterans_benefit_eligible}}<p>*You are eligible for GI Bill benefits, please contact the Veteran Success Center for details on benefits.</p>{{/if}}`,
                    modalMessage: `<div class="modal-line-items-table">
                                        <div class="modal-line-item"><span>{{term_desc}} term balance</span><span class="text-right">\${{getToFixed term_balance}}</span></div>
                                        <div class="modal-line-item"><span>Estimated financial aid for {{term_desc}}*</span><span class="text-right">\${{getToFixed term_estimated_financial_aid}}</span></div>
                                        {{#if owes_past_term_balance}}<div class="modal-line-item"><span>Past term balances owed</span><span class="text-right">\${{getToFixed past_term_balance_amount}}</span></div>{{/if}}
                                        <div class="modal-line-item"><span>{{balancePhrase}}</span><span class="text-right">{{#ifGreater absBalance 0}}<a href="https://shib.uvu.edu/idp/profile/SAML2/Unsolicited/SSO?providerId=touchnet-prod-tbp&shire=https://secure.touchnet.com/C20242_tsa/web/caslogin.jsp?REDIRECT_PARAMETER=PAYMENTS" target="touchnet" title="Link opens in a new tab">Pay Now</a> {{/ifGreater}}\${{getToFixed absBalance}}</span></div>

                                    </div>
                                <div class="modal-fs-deadline">{{{courseSafe}}}</div>
                                <div class="modal-fs-other">
                                    <div id="financial-enrollments-panel" class="panel panel-default">
                                        <div class="panel-heading">
                                            <div class="panel-title">Financial Enrollments</div>
                                        </div>
                                        <ul class="list-group">
                                            {{{payment_plan_enrollment_phrase}}}
                                            {{{erefund_enrollment_phrase}}}
                                            {{#if veterans_benefit_eligible}}<li class="list-group-item">*You are eligible for GI Bill benefits, please contact the Veteran Success Center for details on benefits.</li>{{/if}}
                                        </ul>
                                    </div>
                                    
                                </div>
                                <p style="font-size: 12px;">
                                <small>*Generally speaking, financial aid is only applied to the semester for which it was awarded; it does not apply to past or future semesters.<br/>
								Aid eligibility and account balance are subject to change. If you adjust your schedule or no longer qualify for part or all of your estimated aid, your balance or credit may change.</small></p>
                                
                    `
                },                  
                helper: {
                    ifEquals: function (arg1, arg2, options) {
                        return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
                    },
                    ifGreater: function(arg1, arg2, options){
                        return (parseFloat(arg1) > parseFloat(arg2)) ? options.fn(this) : options.inverse(this);
                    },
                    getBalance: function(arg1, arg2, options){
                        return Math.abs(parseFloat(arg1) - parseFloat(arg2)).toFixed(2);
                    },
                    getPPenrollment: function(args, options){
                        let data = args,
                        balance = parseFloat(data.term_estimated_financial_aid).toFixed(2) - parseFloat(data.term_balance).toFixed(2),
                        eligible;
                        if(data.payment_plan_enrollment === false && balance < 0 && Math.abs(balance) > 125){
                            eligible = true;
                        }else{
                            eligible = false;
                        }
                        return eligible ? options.fn(this) : options.inverse(this);
                    },
                    getToFixed: function(arg1, options){
                        return parseFloat(arg1).toFixed(2);
                    },
                    getDatePhrase: function(data, options ){
                        let phrase;
                        if(data.owes_past_term_balance === false && data.in_collections === false){
                            if (data.term_balance - data.term_estimated_financial_aid > 0) {
                                if (data.purge_date_days >= 0 && data.purge_eligible === true) {
                                    phrase = `Your classes are at risk of being dropped!\nPayment must be made by ${data.purge_date}`;
                                }else if(data.purge_date_days >= 0 && data.purge_eligible === false){
                                    phrase = `Your classes are safe through the drop deadline.`;
                                }else if( data.payment_plan_enrollment === true){
                                    phrase = `You are enrolled in a payment plan.`;
                                }else if (data.purge_date_days < 0 && data.late_deadline_days >= 0) {
                                    phrase = `The payment deadline begins ${data.late_deadline}.`;
                                }else{
                                    phrase = `The payment deadline begins ${data.late_deadline}.`;
                                }
                            }else{
                                phrase = `*Financial aid is typically disbursed on the first day of classes.`;
                            }
                        }else{
                            phrase = `Your account must be brought to good standing before being able to continue registration.`;
                        }
                        
                        return `<p>${phrase}</p>`;
                    }
                },
                func: {},
                Handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false
            };
            // check for user passed in options
            $.extend(true, defs, opts);
            defs.func.listen = async function (opts) {
                if (opts.listen.form !== false) {
                    $(opts.listen.form).submit(()=> {
                        opts.flush = true;
                        run(opts); 
                    });
                }
            };
            defs.func.beforeUnload = function(opts, sessVar){
                window.addEventListener("beforeunload", function(e) {
                    if(myuvu.session.get(sessVar) !== 'undefined' && myuvu.session.get(sessVar) !== null){
                        const cache = myuvu.session.get(sessVar);
                        if(cache.getting === true)myuvu.session.del(sessVar);
                    }
                    delete e.returnValue;
                });
            };
            defs.func.checkStatus = function(data){
                    let status;
                    if (data.owes_past_term_balance === true || data.in_collections === true || (data.purge_eligible === true && data.purge_date_days >= 0)) {
                        status = "danger";
                    } else if (data.term_estimated_financial_aid - data.term_balance < 0 && data.owes_past_term_balance === false) {
                        status = "warning";
                    } else if (data.term_estimated_financial_aid - data.term_balance >= 0 && data.in_collections === false) {
                        status = "good";
                    } else {
                        status = "good";
                    }
                return status;
            };
            function showModal(opts, selectedTerm){
                bootbox.dialog({
                    className: 'financialStatusModal',
                    title: 'More Information',
                    container: 'body',
                    message: `<div id="modal-message-container">Loading, please wait...</div>`,
                    closeButton: true,
                    onShown: async function(e){
                        const message = await generateDetailMessage(opts, selectedTerm);
                        $(this).find('#modal-message-container').html(message);
                    },
                    buttons: {
                        close:{
                            label: 'Close',
                            className: 'btn-default',
                            callback: function(){
                                this.modal('hide');
                            }
                        }
                    }
                });

            }
            async function generateDetailMessage(opts, selectedTerm){
                try{
                    const data = myuvu.session.get('financial-status');
                    const termData = data.content.filter(term => term.term_code == selectedTerm)[0];
                    let message;
                    if(termData.in_collections != true){
                        termData.term_desc = fixTermDesc(termData.term_desc);
                        termData.balance = termData.term_estimated_financial_aid - termData.term_balance;
                        termData.past_term_balance_amount = Math.abs(termData.past_term_balance_amount);
                        termData.absBalance = Math.abs(termData.balance) + termData.past_term_balance_amount;
                        termData.balancePhrase = (termData.absBalance >= 0)? 'Remaining Balance Due': 'Credit';
                        if (termData.purge_date_days >= 0 && termData.purge_eligible === true) {
                            termData.courseSafe = `<p>Classes will be dropped due to non-payment on ${termData.purge_date} 11:59 P.M.</p>`;
                        }else if(termData.purge_date_days >= 0 && termData.purge_eligible === false){
                            termData.courseSafe = `<p>Your classes are safe through the drop deadline.</p>`;
                        }else if(termData.payment_plan_enrollment === true){
                            termData.courseSafe = `<p>You are enrolled in a payment plan.</p>`;
                        }else{
                            termData.courseSafe = `<p>The payment deadline begins ${termData.late_deadline} 11:59 P.M.</p>`;
                        }
                        
                        termData.payment_plan_enrollment_phrase = (termData.payment_plan_enrollment === true)? `<li class="list-group-item">Payment Plan Enrollment for ${termData.term_desc}: Enrolled <span class="fad fa-check-circle" style="color:#275d38;"></span></li>`: `<li class="list-group-item">Payment Plan Enrollment for ${termData.term_desc}: Not enrolled, <a href="https://shib.uvu.edu/idp/profile/SAML2/Unsolicited/SSO?providerId=touchnet-prod-tbp&shire=https://secure.touchnet.com/C20242_tsa/web/caslogin.jsp?REDIRECT_PARAMETER=PAYMENT_PLANS" target="touchnet" title="Link opens in a new tab">sign up now</a>!</li>`;
                        termData.erefund_enrollment_phrase = (termData.erefund_enrollment == true)? `<li class="list-group-item">eRefund Enrollment (Direct Deposit): Enrolled <span class="fad fa-check-circle" style="color:#275d38;"></span></li>`: `<li class="list-group-item">eRefund Enrollment (Direct Deposit): Not Enrolled, <a href="https://userve.uvu.edu/ssomanager/saml/login?relayState=/c/auth/SSB?pkg=bwykxdrd.P_DirdAuth" title="Link opens in this tab">enroll now</a>!</li>`;
                        message = opts.template.modalMessage(termData);
                    }else{
                        message = `<p>Your past due balance has been transferred to the Utah Valley University Collections office.<p/>
                        <p>Our goal is to assist you in paying this balance off so you may continue you educational goals. For questions or to set up repayment arrangements please contact our office at <a href="tel:8018638611">801-863-8611</a> or email us <a href="mailto:collect@uvu.edu">collect@uvu.edu</a></p>
                        <br/>
                        <p>We are also available for live chat Monday thru Friday 8am to 5pm MST</p>
                        <p class="text-center"><a href="https://support.uvu.edu/api/start_session.ns?popup=1&c2cjs=1&codeName=issue_33&issue_menu=33" target="collectionsLiveChat" class="btn btn-primary">Start Live Chat</a></p>
                        `;
                    }
                    return message;

                }catch(err){
                    console.error('Error', err);
                }
            }
            function showDetails(opts){
                opts.$this.find('.financial-status-card').off('click').on('click', function(){
                    const selectedTerm = $(this).attr('data-financial-modal-termcode');
                    showModal(opts, selectedTerm);
                });

                opts.$this.find('.financial-status-card').on('keyup', (e)=>{
                    if(e.key == 'Enter'){
                        const selectedTerm = $(e.target).attr('data-financial-modal-termcode');
                        showModal(opts, selectedTerm);
                    }
                });
                opts.$this.find('.financial-status-card a').off('click').on('click', (e)=> {
                    if(e.currentTarget.className != 'collectionsMore'){ 
                        e.stopPropagation();
                    }else{
                        e.preventDefault();
                    }
                });
               
            }

            function fixTermDesc(term){
                const termDescArray = term.split(" ");
                const termDesc = `${termDescArray[1].charAt(0).toUpperCase() + termDescArray[1].slice(1).toLowerCase()} ${termDescArray[0]}`;
                return termDesc;
            }

            function out(opts){
                const data = myuvu.session.get('financial-status');
                let root = document.documentElement;
                if(data.content[0].in_collections !== true){
                    opts.$this.html(opts.template.main(data.content));
                }else{
                    let tempArray = [];
                    tempArray.push(data.content[0]);
                    opts.$this.html(opts.template.main(tempArray));
                }
                
                showDetails(opts);
            }
            
            async function run(opts){
                try{
                    const user = await getUser(opts);
                    const addOpts = {'id': user.data.id, 'term': user.data.term, 'src': user.data.src};
                    opts = {...opts, ...addOpts};
                    let origCachetime = opts.cacheTime;
                    opts.cacheTime = 3600;
                    const terms = await getData(opts, 'available-terms', `${myuvu.server}/_services/student/terms.php`);
                    opts.cacheTime = origCachetime;
                    const termCodes = [];
                    terms.content.forEach(term=>{
                        termCodes.push(term.termCode);
                    });
                    opts.term = termCodes.join(',');
                    const data = await getData(opts, 'financial-status', `${opts.url.base}?call=financialStatus&id=${opts.id}&term=${opts.term}&src=${opts.src}`);
                    let iter = 0;
                    data.content.forEach(term => {
                        if(iter > 0 && term.owes_past_term_balance){
                            term.past_term_balance_amount = 0;
                        }
                        term.term_status = opts.func.checkStatus(term);
                        term.term_desc = fixTermDesc(term.term_desc);
                        iter++;
                        return term;
                    });
                    saveData('financial-status', data);
                    out(opts, data);
                } catch(e){
                    console.error('Error', e);
                }
            }
             // init plugin
            function init() {
                // return plugin instance
                return $main.each(function () {
                    var opts = $.extend({}, defs),
                        ow, i;

                    opts.$this = $(this);
                    // extend opts from html data-
                    $.extend(true, opts, getDataDash(opts.pre, opts));
                    // getting templates
                    getTemplates(opts);
                    opts.func.beforeUnload(opts, 'financial-status');
                    opts.func.beforeUnload(opts, 'available-terms');
                    run(opts);                   
                    opts.func.listen(opts);
                });
            }

            // check dependencies and init
            if (defs.Handlebars) {
                init();
            } else {
                $.getScript(defs.url.handlebars, function () {
                    defs.Handlebars = Handlebars;
                    init();
                });
            }
    };
})(jQuery);