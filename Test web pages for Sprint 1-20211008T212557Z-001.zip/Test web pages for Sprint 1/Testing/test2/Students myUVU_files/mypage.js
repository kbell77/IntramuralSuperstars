/**
 * mypage - bookmarked content and custom page
 */

(function($){
    $.fn.mypage = function(opts, callback) {
        'use strict';
        var $main = this,
            defs = {
                pre: 'my',
                altid: 'data-my-id',    // alt id other than css id
                bookmark: { // bookmark options
                    class: 'my', // class for bookmarks
                    html: '<i class="myuvu-bookmark" title="Bookmark/add to your custom page">add</i>', // code for bookmark trigger
                    add: 'myuvu-bookmark', // class for bookmark trigger
                    remove: 'myuvu-remove', // class for removing trigger
                    api: '/aisapi/apicall.php?api_url=idm/myuvu/bookmarks/1.0.0/uvid', // bookmarks api
                },
                out: false, // output bookmarks true/selector
                api: '/user/lib/php/myapi.php', // data api
                sortable: false, // sortable selector true/selector
                sort: { // Sortable params
                    animation: 150,
                    draggable: '.widget',
                    handle: '.widget-grab',
                    group: 'all',
                    dataIdAttr: 'data-sort-id'
                },
                Sortable: typeof Sortable !== 'undefined' ? Sortable : false,
                handlebars: typeof Handlebars !== 'undefined' ? Handlebars : false,
                template: {
                    // use function instead of handlebars template so wrapper doesn't require handlebars
                    main: function(bm){
                        var html = '',i;
						
						if( bm.length ){
							bm.sort(function(a,b){ return a.id > b.id; }); // sort alphabetically like old bookmarks - could be remove to match sorting of mypage
							
							for(i=0; i < bm.length; i++){
                                if( bm[i].id ) html += '<li class="my" data-my-id="'+bm[i].id+'"><a href="'+ (bm[i].link ? bm[i].link : bm[i].page+'#'+bm[i].id)+'" title="'+bm[i].title+'">'+bm[i].title+'</a><span class="myuvu-remove" role="button" title="Delete '+bm[i].title+' bookmark."></span></li>';
                            }
                        }else{
                            html = '<li><a href="javascript;">You have no bookmarks</a></li>';
                        }
                        return html;
                    }
                },
                ps: typeof myuvu !== 'undefined' ? myuvu.ps : false, // pub sub
                session: typeof myuvu !== 'undefined' ? myuvu.session : false, // session storage
                spotcheck: typeof myuvu !== 'undefined' ? myuvu.spotcheck : false, // spotcheck function
                helper: {},
                async: [],
                once: true
            };

        // check for passed in options
        $.extend(true, defs, opts);

        // message out
        function message(type, msg, pars){
            var p = {
                type: type,
                text: msg,
                timeout: 5000,
                closeWith: ['click','button']
            };
            if( typeof pars === 'object' ) p = $.extend(p, pars);
            if( typeof Noty !== 'undefined' ) new Noty(p).show();
        }

        // waiting
        function waiting(show, id, opts){
            if(show){
                $('['+opts.altid+'="'+id+'"] .'+opts.bookmark.add).addClass('myuvu-wait');
            }else{
                $('.'+opts.bookmark.add).removeClass('myuvu-wait');
            }
        }

        // getting all html5 data- attributes with matching prefix
        function getDataDash(opts){
            var pre = opts.pre,
                dd = opts.$this[0].attributes,
                ow = {},
                i,
                nest = function(sel, val){ // make nested array
                    var s = sel.shift(),
                        v = sel.length ? nest(sel, val) : val,
                        r = {};
                    r[ typeof s !== 'undefined' ? s : sel ] = v;
                    return r;
                };
            
            for( i=0; i < dd.length; i++ ){
                if( dd[i].name.indexOf('data-'+pre+'-') !== -1 ) $.extend(true, ow, nest( dd[i].name.replace('data-'+pre+'-', '').split('-'), dd[i].value ) );
            }
    
            return ow;
        }

        // load external template
        function loadTemplate(i, opts){
            var t = opts.template;
            opts.async.push(false);
            // get template
            $.ajax({
                url: opts.template[i]
            }).done(function(temp){
                if( typeof temp === 'string' ){ // make sure we got a template
                    opts.handlebars.registerPartial( i, temp ); // make a partial
                    t[i] = opts.handlebars.compile(temp); // make template
                    opts.async[opts.async.indexOf(false)] = true; // set done getting template
                    output(opts);
                }
            }).fail(function(a,b,c){
                console.log('error loading template - '+opts.template[i]+':');
                console.log(a); console.log(b); console.log(c);
            });
        }

        // get templates from either html or string
        function getTemplates(opts){
            var t = opts.template,
                c = false,
                i;

            for( i in t ){
                if( typeof t[i] !== 'function' ){
                    c = true;
                    if( t[i].indexOf('.') === 0 || t[i].indexOf('#') === 0 ){ // test if selector
                        t[i] = $(t[i]).html();
                    } else if( -1 < t[i].indexOf('/') && -1 < t[i].indexOf('.') ){ // external template file
                        loadTemplate(i, opts);
                    } 
                    opts.handlebars.registerPartial( i, t[i] ); // all templates are also a partial
                    t[i] = opts.handlebars.compile(t[i]); // make template
                }
            }
            if( c ) opts.handlebars.registerHelper(opts.helper);

            output(opts);

        }

        // sortable plugin
        function sort(opts){
            var sort, $sort;

            if( opts.sortable ){
                // store functions
                if( typeof opts.sort.store === 'undefined' ){
                    opts.sort.store = {
                        get: function(sort){
                            return opts.bookmarks;
                        },
                        set: function(sort){
                            console.log(sort.toArray());
                            bookmark( sort.toArray(), opts );
                        }
                    };
                }
                // setup sortable
                $sort = opts.sortable === 'true' ? opts.$this : opts.$this.find(opts.sortable)[0];
                sort = opts.Sortable.create($sort, opts.sort);
            }
            
        }

        // create update function
        function createUpdateFunc(opts){
            return function(_, bookmarks){
                
                if( bookmarks !== opts.bookmarks ){
                    opts.bookmarks = bookmarks;
                    opts.session.set('mypage', bookmarks);
                    if( opts.out ){
                        output(opts);
                    }else{
                        check(opts);
                    }
                }
            };
        }

        // output using handlebars/function
        function output(opts){
            if( typeof opts.template.main === 'function' ){
                opts.$out.html( opts.template.main(opts.bookmarks) );
                check(opts);
                if( opts.sortable ) sort(opts);
                if( opts.spotcheck ) opts.spotcheck();
				if( opts.once ){
					opts.once = false;
					if( typeof callback === 'function' ) callback(opts);
				}
            }else{
                if( typeof opts.handlebars === 'object' ){
                    getTemplates(opts);
                }
            }
        }

        // check bookmarks
        function check(opts){
            var $bookmarks = opts.$this.find('.'+opts.bookmark.class).length ? opts.$this.find('.'+opts.bookmark.class) : opts.$this.closest('.'+opts.bookmark.class).length ? opts.$this.closest('.'+opts.bookmark.class) : false,
                bookmarks = [],i;

            // remove any waiting animation
            waiting(false, false, opts);
            
            // build quick index of bookmarks
            for(i=0; i< opts.bookmarks.length; i++){
                bookmarks.push(opts.bookmarks[i].id);
            }
            // check bookmarks on page
            if( $bookmarks ){
                $bookmarks.each(function(){
                    
                    var $this = $(this),
                        id = typeof $this.attr(opts.altid) !== 'undefined' ? $this.attr(opts.altid) : typeof $this.attr('id') !== 'undefined' ? $this.attr('id') : false,
                        $addRem = id ? $this.find('.'+opts.bookmark.add+', .'+opts.bookmark.remove) : [];

                    // add trigger if hasn't been added
                    if( id && $addRem.length === 0 ){
                        $this.append(opts.bookmark.html);
                        $addRem = $this.find('.'+opts.bookmark.add+', .'+opts.bookmark.remove);
                    }

                    // toggle trigger class to correct state
                    if( $addRem.length !== 0 ){
                        if( bookmarks.indexOf(id) !== -1 ){
                            $addRem.addClass(opts.bookmark.remove);
                            $addRem.removeClass('far fa-bookmark').addClass('fas fa-bookmark');
                            $addRem.find('.fa-bookmark').attr('data-prefix','fas');
                        }else{
                            $addRem.removeClass(opts.bookmark.remove);
                            $addRem.removeClass('fas fa-bookmark').addClass('far fa-bookmark');
                            $addRem.find('.fa-bookmark').attr('data-prefix','far');
                        }
                    }
                    
                });
            }
        }

        // add/remove bookmark
        function bookmark(bookmark, opts){
            var add = false;
            // add waiting animation
            if( typeof bookmark === 'string' ) waiting(true, bookmark, opts);
            // pull from server to get very latest before adding
            api('GET', opts, true, function(bm){
                
                if( typeof bm === 'object' ){ // we got a good response from the api
                    // multiple bookmark change i.e. page re-sorted
                    if( typeof bookmark === 'object' ){
                        // check that object only changed by one
                        if( bookmark.length === bm.length || bookmark.length-1 === bm.length || bookmark.length+1 === bm.length ){
                            bm = bookmark;
                        }
                        // probably should be more robust check to avoid bookmark corruption or at server level
                    }
                    // add/removed single bookmark
                    else if( typeof bookmark === 'string' ){
                        // remove from existing bookmarks
                        if( bm.indexOf(bookmark) !== -1 ){
                            add = false;
                            bm.splice( bm.indexOf(bookmark), 1 );
                        }
                        // add to existing bookmarks
                        else{
                            add = true;
                            bm.push(bookmark);
                        }
                        // probably should be more robust - i.e. add/remove at server level
                    }
                    // send updated bookmarks to server
                    api( {data: JSON.stringify( bm )}, opts, function( bm ){
                        // check success
                        if( typeof bm === 'object' && typeof bookmark === 'string' ){
                            if( add && bm.indexOf(bookmark) !== -1 ){
                                // added
                                message('success', bookmark+' bookmark added');
                                dataApi(bm, opts);
                            }else if( !add && bm.indexOf(bookmark) === -1 ){
                                // removed
                                message('success', bookmark+' bookmark removed');
                                dataApi(bm, opts);
                            }else{
                                // failed add
                                message('error', 'Failed to '+ (add ? 'add' : 'remove') +' bookmark. Please try again in a few minutes');
                            }
                        }else{
                            // failed
                            message('error', 'Failed to '+ (add ? 'add' : 'remove') +' bookmark. Please try again in a few minutes');
                        }
                    });
                }
                // we didn't get a good response
                else{
                    // message ?
                }
            });

        }

        // watch for click
        function watch(opts){
            // add click event
            opts.$this.off('click.'+opts.pre).on('click.'+opts.pre, '.'+opts.bookmark.add+', .'+opts.bookmark.remove, function(e){
                var $this = $(this).closest('.'+opts.bookmark.class),
                    id = typeof $this.attr(opts.altid) !== 'undefined' ? $this.attr(opts.altid) : typeof $this.attr('id') !== 'undefined' ? $this.attr('id') : false;
    
                if( id ){
                    e.stopPropagation();
                    e.preventDefault();
                    bookmark(id, opts);
                }
            });
        }
        
        // bookmarks api connection
        function api(params, opts){
            var method = params === 'GET' ? 'GET' : 'PUT',
                pars = {
                    url: opts.bookmark.api,
                    method: method,
                    dataType: method === 'GET' ? 'json' : 'text',
					cache: false
                },
                cache = opts.session ? opts.session.get('mypage') : false,
                force = false,
                bookmarks = false,
                callback,arg,i;
            
			if( !cache ) opts.session.set('mypage', []);
			
            // check for overloaded args
            for( i=2; i < arguments.length; i++ ){
                arg = arguments[i];
                if( typeof arg === 'function' ) callback = arg;
                if( typeof arg === 'boolean' ) force = arg;
            }
            if( typeof params === 'object' ) $.extend(true, pars, params);

            if( method === 'PUT' || force || !cache ){
                $.ajax(pars).done(function(d){
                    // get updated bookmarks after put
                    if( method === 'PUT' ){
                        api('GET', opts, true, callback); // force refresh from server
                    }else{
                        if( typeof d.results.bookmarks_current !== 'undefined' ){
                            bookmarks = typeof d.results.bookmarks_current === 'object' ? d.results.bookmarks_current : JSON.parse(d.results.bookmarks_current);
                        
                            if( typeof callback === 'function' ){
                                callback( bookmarks, opts );
                            }else{
                                dataApi( bookmarks, opts );
                            }
                        }
                    }
                }).fail(function(a,b,c){
                    console.log(a,b,c);
                });
            }else{
                bookmarks = cache;
                if( typeof callback === 'function' ){
                    callback(cache, opts);
                }else{
                    opts.ps.pub(opts.pre, [bookmarks]);
                }
            }
        }

        // data api
        function dataApi(bookmarks, opts){
            // get bookmarks data
            $.ajax({
                url: opts.api,
                data: {
                    filter: 'id=='+bookmarks.join(','),
					limit: 0
                }
            }).done(function(d){
                var bm = d.items,
                    i;
                if( bm ){
                    for( i=0; i < bm.length; i++ ){
                        if( bookmarks.indexOf(bm[i].id ) !== -1 ){
                            bookmarks[bookmarks.indexOf(bm[i].id)] = bm[i];
                        }
                    }
                    bookmarks = bookmarks.filter(function(v){ return v; }); // re-index
                    opts.ps.pub(opts.pre, [bookmarks]);
                }
            }).fail(function(a,b,c){
                console.log(a,b,c);
            });
        }
        
        // init plugin
        return $main.each(function(){
            var opts = $.extend(true, {}, defs);

            opts.$this = $(this);
            $.extend(true, opts, getDataDash(opts));
            opts.$out = opts.out === 'true' ? opts.$this : opts.$this.find(opts.out);

            // add click events
            watch(opts);
            

            // add update on change function
            opts.ps.sub( opts.pre, createUpdateFunc(opts) );

            // get bookmarks and output to page
            api('GET', opts);

        });

    };

})(jQuery);